"""Optional, experimental recursive-effective-law probe for frozen DNO.

No event taxonomy, historical log, fixed relation labels or dimension expansion.
This is an explicit *test adapter*, NOT a proof of autonomous law discovery.
"""
from dataclasses import dataclass, replace
import torch
from torch import Tensor
from dno import DNO, State


@dataclass(frozen=True)
class Discovery:
    direction: Tensor
    effect: Tensor
    effective_change: Tensor
    next_state: State


def perspective(s: State, index: int) -> Tensor:
    """State-dependent view, not a fixed coordinate or predefined relation type."""
    v = s.value[index] + s.law[index] + s.boundary[index] + s.observer
    # A zero view means no warranted perturbation; no arbitrary fallback axis.
    return v / torch.linalg.vector_norm(v).clamp_min(torch.finfo(v.dtype).eps)


def counterfactual_effect(core: DNO, s: State, index: int, dt: float = 0.1,
                          probe: float = 0.05) -> tuple[Tensor, Tensor]:
    """Symmetric finite difference of the SAME autonomous generator.

    Observation uses the entire resulting current carrier state, not a target
    equation or external labels. No forced event is committed by probing.
    """
    if dt <= 0 or probe <= 0:
        raise ValueError('dt and probe must be positive')
    direction = perspective(s, index)
    uid = s.ids[index]
    plus = core.evolve(s, dt, local={uid: probe * direction})
    minus = core.evolve(s, dt, local={uid: -probe * direction})
    if plus.ids != minus.ids or uid not in plus.ids:
        raise RuntimeError('intervention changed support; compare matching carriers only')
    i = plus.ids.index(uid)
    # Effective outcome includes content, boundary, local law; no event name.
    effect = torch.cat((plus.value[i]-minus.value[i],
                        plus.boundary[i]-minus.boundary[i],
                        plus.law[i]-minus.law[i])) / (2 * probe)
    return direction, effect


def recursive_step(core: DNO, s: State, index: int, *, dt: float = 0.1,
                   probe: float = 0.05, feedback: float = 0.1) -> Discovery:
    """Explore -> evaluate -> minimally commit to *current* law/observer.

    A zero measured effect leads to no discovery update. Feedback is an
    experimental control, not an alleged universal optimality rule.
    """
    if feedback < 0:
        raise ValueError('feedback must be nonnegative')
    direction, effect = counterfactual_effect(core, s, index, dt, probe)
    d = core.d
    # Projection back into the current D-dimensional representation.
    # No extra dimension and no externally named law type.
    evidence = effect[:d] + effect[d:2*d] + effect[2*d:]
    effective_change = feedback * evidence
    law = s.law.clone()
    law[index] = law[index] + effective_change
    observer = s.observer + effective_change
    # The original frozen kernel still performs the actual state evolution.
    # The discovery update becomes part of the next *current state*.
    updated = replace(s, law=law, observer=observer)
    next_state = core.evolve(updated, dt)
    return Discovery(direction, effect, effective_change, next_state)
