import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
import pytest
from dno import DNO
from recursive_law import perspective, counterfactual_effect, recursive_step

@pytest.fixture
def setup():
    torch.manual_seed(11)
    core=DNO(d=4,hidden=16)
    s=core.introduce(core.blank(),torch.tensor([.3,-.2,.5,.4]))
    return core,s

def test_state_valid(setup):
    core,s=setup
    out=recursive_step(core,s,0)
    out.next_state.validate()
    assert out.effect.shape==(12,)

def test_frozen_core_unmodified(setup):
    core,s=setup
    before={k:v.detach().clone() for k,v in core.state_dict().items()}
    recursive_step(core,s,0)
    assert all(torch.equal(v,core.state_dict()[k]) for k,v in before.items())

def test_zero_feedback_equals_base_evolution(setup):
    core,s=setup
    actual=recursive_step(core,s,0,feedback=0).next_state
    baseline=core.evolve(s,.1)
    assert torch.allclose(actual.law,baseline.law)
    assert torch.allclose(actual.value,baseline.value)

def test_evidence_committed_and_changes_next_view(setup):
    core,s=setup
    out=recursive_step(core,s,0,feedback=4.0)
    base=core.evolve(s,.1)
    assert torch.linalg.vector_norm(out.effective_change).item()>0
    assert not torch.allclose(out.next_state.law,base.law,atol=1e-8)
    assert not torch.allclose(perspective(out.next_state,0),perspective(base,0),atol=1e-8)

def test_two_round_recursion(setup):
    core,s=setup
    a=recursive_step(core,s,0,feedback=4.0)
    b=recursive_step(core,a.next_state,0,feedback=4.0)
    baseline=recursive_step(core,core.evolve(s,.1),0,feedback=4.0)
    assert not torch.allclose(b.direction,baseline.direction,atol=1e-8)
    b.next_state.validate()

def test_probe_symmetric(setup):
    core,s=setup
    direction,effect=counterfactual_effect(core,s,0)
    assert torch.isfinite(effect).all()
    assert torch.allclose(direction,perspective(s,0))

def test_no_historical_archive(setup):
    core,s=setup
    out=recursive_step(core,s,0)
    assert set(vars(out.next_state))==set(vars(s))

def test_invalid_inputs(setup):
    core,s=setup
    with pytest.raises(ValueError): recursive_step(core,s,0,probe=0)
    with pytest.raises(ValueError): recursive_step(core,s,0,feedback=-1)
