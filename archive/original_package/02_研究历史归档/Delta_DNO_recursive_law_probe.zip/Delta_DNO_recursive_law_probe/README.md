# Delta DNO — recursive effective law probe

Research adapter over an unchanged frozen `dno.py`.

```bash
pip install torch pytest
python -m pytest -q tests/test_recursive.py
```

See `REPORT_ZH.md` for mathematical meaning, evidence and limitations.
