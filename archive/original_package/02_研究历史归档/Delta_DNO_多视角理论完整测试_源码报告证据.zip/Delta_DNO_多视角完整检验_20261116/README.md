# Delta/DNO 多视角理论完整审计（2026-11-16）

独立、只读测试工程。原始 `frozen/dno.py` 仅复制、未修改，SHA-256: `fea8d9ea81c94dbf926b984b3c158f301afc71782f989c73b3c9bd02fac767b1`。

## 如何执行

需要 Python、PyTorch、NumPy、pytest：

```bash
PYTHONPATH=.:frozen python -m pytest -q tests
PYTHONPATH=.:frozen python stress_audit.py --seeds 160 --output evidence/stress_retest.json
```

完整说明：`REPORT_ZH.md`。

## 文件

- `frozen/dno.py` 原封版核心，只读副本
- `multiview_observer.py` 上次研究的只读坐标观察器，逐字节保持
- `extended_readonly_views.py` **仅外部测量工具**，补足身份/时间/主动寻址的研究视角
- `tests/test_frozen.py` 原 32 项封版测试
- `tests/test_prior_multiview.py` 前次16项观察测试
- `tests/test_deep_multiview.py` 本次新的反例与边界测试
- `tests/test_extended_readonly.py` 身份、时间、主动与被动观察测试
- `tests/test_metamathematical_properties.py` 置换不变量、时间尺度与被动作用元测试
- `stress_audit.py` 160种随机初始化的正负对照与浮点陷阱研究
- `evidence/` 原始测试日志、数值数据和完整性清单

**警告：** 观察程序的通过不等于模型语义泛化、因果正确或多模态精度；没有进行企业级规模训练。
