# Delta / DNO — Composition and Individuation Alignment

This is a **concept-alignment change**, not a claim about discovering abiogenesis, artificial life, general intelligence, or training improvements.

The preceding source is preserved byte-for-byte in:

- `reference/DNO_current_state_evolution_UNMODIFIED.py`

The organized implementation is:

- `dno_compositional.py`

### Changes

- Adds `unit_assemble` to the **existing learned event hazard mechanism**, so a new effective unit may form from the joint current context of **two existing units** (not solely from branching/copying one unit).
- Adds `EvolvingDNO.introduce_component(state, external)` as an optional environment input interface to expose separate preexisting constituents, not as autonomous reproduction.
- Does **not** impose a fixed number of contacts per unit or fixed numerical thresholds for assembly.
- Retains the current-state semantics, local evolving rules, local times, relation-on-relation effects, external resource boundaries, and existing training interface.
- Does **not** define increasing freedom/mobility as a reward or goal. Possible future actions may increase, decrease, or change qualitatively.

### Minimal API

```python
import torch
from dno_compositional import EvolvingDNO, ResourceBoundary

model = EvolvingDNO(vocab_size=32, d_model=12, d_boundary=4,
                    d_law=4, d_relation=4, d_operator=4, d_hidden=24)
state = model.initial_state()
a = torch.randn(12)
b = torch.randn(12)
state = model.introduce_component(state, a)
state = model.introduce_component(state, b)
result = model.advance(state, external=torch.randn(12), duration=0.01,
                       resources=ResourceBoundary(max_events_per_advance=3))
print(result.state.counts)
```

The stochastic transition may perform zero structural events; this is valid. `max_events_per_advance=3` is an **example external compute budget** rather than an internal rule of generation.

### Materials

- `DELTA_DNO_论述与数学对照.md` — cross-domain premise, mathematical formalization, explicit boundaries, code mapping, sourced biology comparisons.
- `CODE_DIFF.patch` — exact code differences relative to the unchanged previous source.
- `tests/test_smoke.py` — engineering sanity checks only, not a scientific test of emergence.

### Requirements

Python 3.10+ and PyTorch (the exact compatibility range has not been exhaustively verified).

```bash
python -m unittest discover -s tests -v
```

### Important limitations

There is no preallocated contact degree. However, all ordered unit-pairs are enumerated to generate contact and composition proposals: this **remains quadratic** in the number of live units. This reference implementation does not solve scalable relation discovery, emergent semantics, or universal self-assembly. Its event waiting-time simulation uses approximate rate freezing. The event type vocabulary remains finite. No claim is made that its default random neural weights already express useful assembly dynamics.
