"""How to supply independent constituents without defining a reproduction chain."""
import torch
from dno_compositional import EvolvingDNO, ResourceBoundary


def main():
    model = EvolvingDNO(vocab_size=32, d_model=12, d_boundary=4,
                        d_law=4, d_relation=4, d_operator=4, d_hidden=24)
    state = model.initial_state()
    state = model.introduce_component(state, torch.randn(model.d))
    state = model.introduce_component(state, torch.randn(model.d))
    print('Present constituents:', state.counts)
    # Event count is not a requested target. None may occur within this window.
    result = model.advance(state, duration=0.01, external=torch.randn(model.d),
                           resources=ResourceBoundary(max_events_per_advance=3))
    print('Current effective configuration:', result.state.counts)
    print('Current directed contact degrees:', result.state.degree())


if __name__ == '__main__':
    main()
