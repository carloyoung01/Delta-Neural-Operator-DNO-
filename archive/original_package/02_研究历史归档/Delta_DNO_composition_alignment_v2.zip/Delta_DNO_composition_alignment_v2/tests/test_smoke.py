"""Engineering sanity checks only. NOT tests of biological emergence or language understanding."""
import unittest
import torch
from dno_compositional import EvolvingDNO, ResourceBoundary, _Proposal


class TestStructuralIntegrity(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = EvolvingDNO(vocab_size=16, d_model=12, d_boundary=4,
                                 d_law=4, d_relation=4, d_operator=4,
                                 d_hidden=24)
        self.s = self.model.initial_state()
        self.s = self.model.introduce_component(self.s, torch.randn(12))
        self.s = self.model.introduce_component(self.s, torch.randn(12))

    def test_independent_external_components(self):
        self.assertEqual(self.s.counts, (2, 0, 4))
        self.assertEqual(self.s.degree(), ((0, 0), (0, 0)))

    def test_assembly_possible_without_prior_edge(self):
        rb = ResourceBoundary(max_units=5)
        proposals = self.model._proposals(self.s, rb)
        self.assertTrue(any(p.kind == 6 and p.source == 0 and p.target == 1
                            for p in proposals))
        later, logp = self.model._apply_event(
            self.s, _Proposal(6, source=0, target=1),
            torch.randn(12), stochastic=True)
        self.assertEqual(later.counts[0], 3)
        self.assertEqual(later.counts[1], 0)
        self.assertTrue(torch.isfinite(later.units).all())
        self.assertTrue(torch.isfinite(logp).all())
        self.assertEqual(later.degree(), ((0, 0), (0, 0), (0, 0)))

    def test_assembly_rule_can_receive_gradient(self):
        state, _ = self.model._apply_event(
            self.s, _Proposal(6, source=0, target=1),
            torch.randn(12), stochastic=True)
        state.units[-1].square().sum().backward()
        grads = [p.grad for p in self.model.assembly_rule.parameters()]
        self.assertTrue(any(g is not None and torch.isfinite(g).all()
                            and g.abs().sum().item() > 0 for g in grads))

    def test_event_budget_does_not_predetermine_structure(self):
        result = self.model.advance(
            self.s, external=torch.randn(12), duration=0.02,
            resources=ResourceBoundary(max_events_per_advance=2))
        self.assertTrue(0 <= result.events_executed <= 2)
        self.assertTrue(torch.isfinite(result.logits).all())


if __name__ == '__main__':
    unittest.main()
