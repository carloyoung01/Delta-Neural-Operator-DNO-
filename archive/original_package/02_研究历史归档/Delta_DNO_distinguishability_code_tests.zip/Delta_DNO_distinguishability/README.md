# Delta DNO — operational distinguishability

Requires Python, PyTorch and pytest.

```bash
pytest -q tests
python train_probe.py
```

This is an independent experimental layer on top of an unmodified frozen DNO reference. See REPORT_ZH.md for the exact math, counterexamples, and limitations.
