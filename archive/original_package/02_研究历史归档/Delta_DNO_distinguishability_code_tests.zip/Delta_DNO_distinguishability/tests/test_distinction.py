import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
import torch
from delta_distinction import Experiment, distinguish, partition, DeltaDistinction, update_effective_law

def ex(name, act, obs): return Experiment(name, act, obs)

def test_initial_equivalence_later_refinement_without_lost_state():
    x = torch.tensor([[1.,0.],[1.,1.],[2.,0.]])
    before = distinguish(x,[ex('view-first',lambda z:z,lambda z:z[:,:1])])
    assert partition(before)==((0,1),(2,))
    after = distinguish(x,[ex('view-first',lambda z:z,lambda z:z[:,:1]),
                           ex('intervene-and-view',lambda z:z[:,[1,0]],lambda z:z[:,:1])])
    assert partition(after)==((0,),(1,),(2,))
    assert after.squared_distances[0,1]>0

def test_collapse_cannot_restore_destroyed_information():
    x=torch.tensor([[1.,0.],[1.,1.]])
    collapsed=x[:,:1].repeat(1,2)
    probes=[ex('probe',lambda z:z[:,[1,0]],lambda z:z[:,:1])]
    assert partition(distinguish(collapsed,probes))==((0,1),)
    assert partition(distinguish(x,probes))==((0,),(1,))

def test_interaction_changes_future_equivalence_not_just_readout():
    x=torch.tensor([[0.,0.],[0.,0.]])
    law=torch.zeros_like(x)
    def causal_act(z): return z + law
    before=distinguish(x,[ex('law-effect',causal_act,lambda z:z)])
    assert partition(before)==((0,1),)
    law=update_effective_law(law,torch.tensor([[0.,0.],[1.,0.]]))
    after=distinguish(x,[ex('law-effect',causal_act,lambda z:z)])
    assert partition(after)==((0,),(1,))
    assert torch.equal(x,torch.zeros_like(x))

def test_equivalence_is_relative_to_experiment_family():
    x=torch.tensor([[0.,0.],[0.,1.]])
    a=distinguish(x,[ex('first',lambda z:z,lambda z:z[:,:1])])
    b=distinguish(x,[ex('second',lambda z:z,lambda z:z[:,1:])])
    assert a.equivalent(0,1) and not b.equivalent(0,1)

def test_no_forced_change():
    x=torch.tensor([[1.,2.],[3.,4.]])
    y=update_effective_law(x,torch.zeros_like(x))
    assert torch.equal(x,y)

def test_complete_link_no_transitive_tolerance_chaining():
    x=torch.tensor([[0.],[.09],[.18]])
    d=distinguish(x,[ex('id',lambda z:z,lambda z:z)])
    assert partition(d,atol=.1)==((0,1),(2,))

def test_gradients_to_shared_generator_and_local_law():
    torch.manual_seed(11)
    m=DeltaDistinction(2)
    x=torch.randn(3,2)
    law=torch.randn(3,2,requires_grad=True)
    probes=torch.eye(2)
    target=torch.zeros(3,3)
    loss=m.loss_for_distinction(x,law,probes,lambda z:z[:,:1],target)
    loss.backward()
    assert any(p.grad is not None and p.grad.abs().sum()>0 for p in m.parameters())
    assert law.grad is not None and law.grad.abs().sum()>0

def test_invalid_inputs():
    m=DeltaDistinction(2)
    with pytest.raises(ValueError): m.act(torch.zeros(2,2),torch.zeros(3,2),torch.zeros(2))
    with pytest.raises(ValueError): distinguish(torch.zeros(2,2),[])
    with pytest.raises(ValueError): distinguish(torch.zeros(2,2),[ex('bad',lambda z:z,lambda z:z[:1,:])])
    with pytest.raises(ValueError): update_effective_law(torch.zeros(2,2),torch.zeros(2,3))

def test_frozen_dno_observation_and_intervention_integration():
    from frozen_dno import DNO
    torch.manual_seed(123)
    model=DNO(d=2,hidden=12)
    s=model.introduce(model.blank(),torch.tensor([[.2,.3],[.2,.3]]))
    assert s.ids==(0,1)
    base=model.observe(s)
    # Current local law is causal in the same frozen generator; no changes to core.
    from dataclasses import replace
    law=s.law.clone(); law[1]=law[1]+torch.tensor([.8,-.6])
    altered=replace(s,law=law)
    next_base=model.evolve(s,.2)
    next_alt=model.evolve(altered,.2)
    assert not torch.allclose(next_base.value[1],next_alt.value[1])
    assert torch.allclose(next_base.value[0],next_alt.value[0])
    assert base.shape==(2,)


def test_distinction_is_not_recovered_by_relabeling_only():
    x=torch.tensor([[1.,2.],[1.,2.]])
    exps=[ex('identity',lambda z:z,lambda z:z)]
    assert partition(distinguish(x,exps))==((0,1),)
