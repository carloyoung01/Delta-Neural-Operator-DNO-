"""Finite learning test: same visible contents, different effective laws, future consequences."""
import json
from pathlib import Path
import torch
from delta_distinction import DeltaDistinction

def run():
    out=[]
    for seed in [3,17,29]:
        torch.manual_seed(seed)
        m=DeltaDistinction(2,32)
        opt=torch.optim.Adam(m.parameters(),lr=.018)
        # Contents are indistinguishable; law is the only causal differentiator.
        x=torch.zeros(4,2)
        laws=torch.tensor([[0.,0.],[0.,1.],[1.,0.],[1.,1.]])
        interventions=torch.tensor([[0.,0.],[1.,0.],[0.,1.]])
        # Distinct law pairs must have different consequences; identical laws match.
        # Supervised *effects* not labels of candidate event kinds.
        def target(law, u): return law[:,0:1]*u[0]+law[:,1:2]*u[1]
        target_signature=torch.stack([target(laws,u) for u in interventions],1)
        for step in range(700):
            train_probes=torch.rand(16,2)*2-0.5
            train_targets=torch.stack([target(laws,u) for u in train_probes],1)
            pred=m.signature(x,laws,train_probes,lambda z:z[:,:1])
            loss=(pred-train_targets).square().mean()
            opt.zero_grad(); loss.backward(); opt.step()
        with torch.no_grad():
            pred=m.signature(x,laws,interventions,lambda z:z[:,:1])
            err=(pred-target_signature).abs().max().item()
            zero=pred[:,0,0]
            effects=pred[:,1:,0]-zero[:,None]
            target_effects=target_signature[:,1:,0]
            effect_err=(effects-target_effects).abs().max().item()
            # A held-out intervention probes compositional generalization.
            novel=torch.tensor([[.5,.5]])
            pred_new=m.signature(x,laws,novel,lambda z:z[:,:1])[:,0,0]-zero
            novel_err=(pred_new-(laws[:,0]+laws[:,1])*.5).abs().max().item()
        out.append(dict(seed=seed,train_max_error=err,effect_max_error=effect_err,
                        unseen_intervention_effect_max_error=novel_err))
    path=Path(__file__).parent/'evidence'/'training.json'
    path.write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
if __name__=='__main__': run()
