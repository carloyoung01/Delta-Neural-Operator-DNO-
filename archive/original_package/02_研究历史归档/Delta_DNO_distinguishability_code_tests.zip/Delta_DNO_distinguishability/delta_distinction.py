"""Delta: operational equivalence is relative to future interventions and observations.

Do not confuse a quotient of *descriptions* with destructive state merging.
This is a finite experimental semantics, not a proof about all possible futures.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import torch
from torch import Tensor, nn


@dataclass(frozen=True)
class Experiment:
    name: str
    act: Callable[[Tensor], Tensor]
    observe: Callable[[Tensor], Tensor]


@dataclass(frozen=True)
class Distinction:
    signatures: Tensor  # [states, experiments, features]
    squared_distances: Tensor  # [states, states]
    experiments: tuple[str, ...]

    def equivalent(self, i: int, j: int, atol: float = 0.0) -> bool:
        """Numerical observational equivalence; atol=0 is exact float equality."""
        return bool(torch.all(torch.abs(self.signatures[i] - self.signatures[j]) <= atol))


def distinguish(states: Tensor, experiments: Sequence[Experiment]) -> Distinction:
    """Measure effects of actually specified interventions, never enumerate futures."""
    if states.ndim != 2 or not experiments:
        raise ValueError('expect [N,D] states and at least one experiment')
    rows = []
    for e in experiments:
        y = e.observe(e.act(states))
        if y.ndim == 1:
            y = y[:, None]
        if y.ndim != 2 or y.shape[0] != states.shape[0]:
            raise ValueError('experiment must return [N,F]')
        rows.append(y)
    if len({r.shape[1] for r in rows}) != 1:
        raise ValueError('observation widths must agree')
    signatures = torch.stack(rows, dim=1)
    flat = signatures.flatten(1)
    dist = ((flat[:, None] - flat[None, :]) ** 2).sum(-1)
    return Distinction(signatures, dist, tuple(e.name for e in experiments))


def partition(d: Distinction, atol: float = 0.0) -> tuple[tuple[int, ...], ...]:
    """Complete-link classes to avoid tolerance non-transitivity via chaining."""
    classes: list[list[int]] = []
    for i in range(d.signatures.shape[0]):
        for group in classes:
            if all(d.equivalent(i, j, atol) for j in group):
                group.append(i)
                break
        else:
            classes.append([i])
    return tuple(tuple(g) for g in classes)


class DeltaDistinction(nn.Module):
    """Shared mutable effective law produces different future action signatures.

    The *same* intervention family can acquire new distinctions when law changes.
    No categorical event labels, pair catalogue, history buffer or irreversible
    merging are required. Probe families are finite and supplied by the experiment.
    """
    def __init__(self, d: int, hidden: int = 32):
        super().__init__()
        self.d = d
        self.shared = nn.Sequential(nn.Linear(3 * d, hidden), nn.Tanh(),
                                    nn.Linear(hidden, d))

    def act(self, content: Tensor, law: Tensor, intervention: Tensor) -> Tensor:
        if content.shape != law.shape or content.shape[-1] != self.d:
            raise ValueError('content and law must share [N,D]')
        if intervention.shape == (self.d,):
            intervention = intervention.expand_as(content)
        if intervention.shape != content.shape:
            raise ValueError('intervention shape mismatch')
        return content + self.shared(torch.cat((content, law, intervention), -1))

    def signature(self, content: Tensor, law: Tensor, interventions: Tensor,
                  observer: Callable[[Tensor], Tensor]) -> Tensor:
        if interventions.ndim != 2 or interventions.shape[1] != self.d:
            raise ValueError('interventions must be [K,D]')
        outputs = [observer(self.act(content, law, u)) for u in interventions]
        return torch.stack(outputs, 1)

    def loss_for_distinction(self, content: Tensor, law: Tensor,
                             interventions: Tensor, observer: Callable[[Tensor], Tensor],
                             target_distances: Tensor) -> Tensor:
        sig = self.signature(content, law, interventions, observer).flatten(1)
        distances = torch.cdist(sig, sig).square()
        return (distances - target_distances).square().mean()


def update_effective_law(law: Tensor, encounter: Tensor) -> Tensor:
    """Illustrative current-state update; not an added event kind or history log."""
    if law.shape != encounter.shape:
        raise ValueError('law and encounter must match')
    return law + encounter
