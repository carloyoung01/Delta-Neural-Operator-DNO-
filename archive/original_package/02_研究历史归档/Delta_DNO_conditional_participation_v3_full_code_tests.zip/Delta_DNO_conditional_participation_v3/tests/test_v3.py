"""Executable checks for DNO v3: no hand-written sleep or activation condition.

These are engineering/counterfactual tests, not proof of learned memory,
biological analogy, generalization, or a universal Delta law.
"""
import unittest
from dataclasses import replace
import math
import torch
import torch.nn.functional as F
from dno_conditional import EvolvingDNO, ResourceBoundary, EVENT_KINDS, _Proposal


torch.set_num_threads(1)


def make(seed=17, n=3, edges=((0,1),), budget=None):
    torch.manual_seed(seed)
    rb = budget or ResourceBoundary(max_units=6, max_relations=10,
                                    max_operators=10,max_events_per_advance=10)
    m = EvolvingDNO(16,d_model=8,d_boundary=4,d_law=4,d_relation=4,
                    d_operator=4,d_hidden=24,resources=rb)
    s=m.initial_state()
    for _ in range(n):
        s=m.introduce_component(s,torch.randn(8))
    for src,dst in edges:
        s,_=m._apply_event(s,_Proposal(2,source=src,target=dst),torch.zeros(8),False)
    return m,s


def remove_edges(s):
    return replace(s,edges=(),edge_operators=(),
        relations=s.relations[:0], relation_laws=s.relation_laws[:0],
        relation_times=s.relation_times[:0],relation_tempos=s.relation_tempos[:0])


class TestConditionalParticipation(unittest.TestCase):
    def setUp(self):
        self.m,self.s=make()
        self.zero=torch.zeros(self.m.d)

    def assertFiniteState(self,s):
        for key in ('units','boundaries','unit_laws','unit_times','unit_tempos',
            'relations','relation_laws','relation_times','relation_tempos',
            'op_states','op_laws','op_times','op_tempos'):
            self.assertTrue(torch.isfinite(getattr(s,key)).all(),key)

    def test_v2_composition_still_possible(self):
        z,_=self.m._apply_event(self.s,_Proposal(6,source=0,target=2),self.zero,False)
        self.assertEqual(z.units.shape[0],4)
        self.assertEqual(z.edges,self.s.edges)
        self.assertEqual(z.unit_ids, (0,1,2,3))

    def test_nonparticipation_causal_isolation_without_event(self):
        """Simply EXISTING edge does not continuously transmit to units."""
        with torch.no_grad():
            a=self.m._flow(self.s,self.zero,.2)
            b=self.m._flow(remove_edges(self.s),self.zero,.2)
        for key in ('units','boundaries','unit_laws','unit_times','unit_tempos',
                    'op_states','op_laws'):
            self.assertTrue(torch.equal(getattr(a,key),getattr(b,key)),key)
        self.assertEqual(a.edges,((0,1),))
        self.assertGreater(float((a.relations-self.s.relations).norm()),0)
        self.assertGreater(float((a.relation_laws-self.s.relation_laws).norm()),0)

    def test_repeated_nonparticipation_can_retains_current_structure(self):
        a,b=self.s,remove_edges(self.s)
        with torch.no_grad():
            for k in range(80):
                a=self.m._flow(a,self.zero,.06)
                b=self.m._flow(b,self.zero,.06)
                self.assertTrue(torch.allclose(a.units,b.units,atol=0,rtol=0))
        self.assertEqual(a.edges,((0,1),))
        self.assertGreater(float((a.relations-self.s.relations).norm()),1e-6)
        self.assertGreater(a.physical_time,4.7)
        self.assertFiniteState(a)

    def test_actual_contact_changes_subsequent_evolution(self):
        with torch.no_grad():
            active,_=self.m._apply_event(self.s,_Proposal(7,edge=0),self.zero,False)
            passive=self.s.clone()
            self.assertGreater(float((active.units-passive.units).norm()),1e-7)
            self.assertGreater(float((active.relations-passive.relations).norm()),1e-7)
            self.assertGreater(float((active.unit_laws-passive.unit_laws).norm()),1e-9)
            active=self.m._flow(active,self.zero,.4)
            passive=self.m._flow(passive,self.zero,.4)
            self.assertGreater(float((active.units-passive.units).norm()),1e-7)
            self.assertGreater(float((self.m._readout(active,self.zero)-
                                      self.m._readout(passive,self.zero)).norm()),1e-8)

    def test_local_cue_changes_only_addressed_autonomy_without_contact(self):
        cue={self.s.unit_ids[0]:torch.randn(self.m.d)}
        with torch.no_grad():
            a=self.m._flow(self.s,self.zero,.1,local_cues=cue)
            b=self.m._flow(self.s,self.zero,.1)
        self.assertGreater(float((a.units[0]-b.units[0]).norm()),1e-7)
        self.assertTrue(torch.equal(a.units[1:],b.units[1:]))
        self.assertTrue(torch.equal(a.relations,b.relations))

    def test_cue_conditions_existing_relation_intensity(self):
        p=_Proposal(7,edge=0)
        base=self.m._event_rates(self.s,self.zero,[p])[0]
        local={self.s.unit_ids[0]:torch.randn(self.m.d)}
        changed=self.m._event_rates(self.s,self.zero,[p],local)[0]
        unrelated={self.s.unit_ids[2]:local[self.s.unit_ids[0]]}
        other=self.m._event_rates(self.s,self.zero,[p],unrelated)[0]
        self.assertGreater(abs(float((changed-base).detach())),1e-8)
        self.assertTrue(torch.equal(base,other))

    def test_per_call_diagnostics_not_part_of_current_state(self):
        r=self.m.advance(self.s,duration=.01,stochastic=True)
        self.assertEqual(len(r.event_kinds),r.events_executed)
        self.assertEqual(r.interaction_events,
                         sum(1 for k in r.event_kinds if k=='relation_interact'))
        self.assertFalse(hasattr(r.state,'event_kinds'))
        self.assertFalse(hasattr(r.state,'history_log'))

    def test_no_event_interval_still_has_relational_intrinsic_evolution(self):
        torch.manual_seed(100)
        r=self.m.advance(self.s,duration=1e-6,stochastic=True)
        self.assertEqual(r.events_executed,0)
        self.assertEqual(r.state.edges,self.s.edges)
        with torch.no_grad():
            expected=self.m._flow(self.s,self.zero,1e-6)
        self.assertTrue(torch.equal(r.state.units,expected.units))
        self.assertTrue(torch.equal(r.state.relations,expected.relations))

    def test_nonuniform_directed_contacts_without_fixed_ports(self):
        s=self.s
        s,_=self.m._apply_event(s,_Proposal(2,source=0,target=2),self.zero,False)
        s,_=self.m._apply_event(s,_Proposal(2,source=2,target=0),self.zero,False)
        self.assertEqual(s.degree(),((2,1),(0,1),(1,1)))
        self.assertEqual(len(s.edges),3)

    def test_local_cues_retain_stable_identity_across_release(self):
        s=self.s
        s,_=self.m._apply_event(s,_Proposal(1,source=1),self.zero,False)
        self.assertEqual(s.unit_ids,(0,2))
        cue={2:torch.randn(self.m.d)}
        a=self.m._flow(s,self.zero,.08,local_cues=cue)
        b=self.m._flow(s,self.zero,.08)
        self.assertTrue(torch.equal(a.units[0],b.units[0]))
        self.assertGreater(float((a.units[1]-b.units[1]).norm()),1e-8)
        n=self.m.introduce_component(s,torch.randn(self.m.d))
        self.assertEqual(n.unit_ids,(0,2,3))

    def test_operator_composition_and_rebinding_regression(self):
        s,_=self.m._apply_event(self.s,_Proposal(4,edge=0),self.zero,False)
        self.assertEqual(len(s.operators),5)
        self.assertTrue(torch.isfinite(s.op_states).all())
        self.assertEqual(s.edge_operators,(4,))
        s,_=self.m._apply_event(s,_Proposal(5,edge=0),self.zero,False)
        self.assertFiniteState(s)

    def test_continuous_contact_gradient_is_real(self):
        m,s=make(23)
        out,_=m._apply_event(s,_Proposal(7,edge=0),torch.randn(m.d),False)
        loss=(out.units-s.units).square().sum()+out.relations.square().sum()
        loss.backward()
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum()>0
                            for p in m.edge_message.parameters()))
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum()>0
                            for p in m.relation_meta.parameters()))

    def test_no_event_logprob_trains_shared_hazard(self):
        r=self.m.advance(self.s,duration=.001,stochastic=True)
        r.event_log_probability.backward()
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum()>0
                            for p in self.m.hazard.parameters()))

    def test_no_contact_does_not_train_edge_message_via_unit_flow(self):
        m,s=make(44)
        output=m._flow(s,torch.zeros(m.d),.1).units.square().sum()
        grads=torch.autograd.grad(output,tuple(m.edge_message.parameters()),
                                  allow_unused=True)
        self.assertTrue(all(g is None or g.abs().sum().item()==0 for g in grads))

    def test_score_function_interface_has_valid_gradient(self):
        m,s=make(63)
        torch.manual_seed(901)
        r=m.advance(s,duration=.13,stochastic=True)
        loss=m.policy_loss(r.logits.square().mean(),
                           r.event_log_probability,baseline=0.0)
        self.assertTrue(torch.isfinite(loss))
        loss.backward()
        self.assertTrue(any(p.grad is not None and torch.isfinite(p.grad).all()
                            and p.grad.abs().sum()>0 for p in m.hazard.parameters()))

    def test_forward_and_step(self):
        x=torch.tensor([[2,3,5]],dtype=torch.long)
        r,s,logp=self.m.forward(x,duration=.001,stochastic=True,
                               return_state=True,return_event_log_probability=True)
        self.assertEqual(tuple(r.shape),(1,3,16))
        self.assertTrue(torch.isfinite(r).all())
        self.assertTrue(torch.isfinite(logp))
        self.assertEqual(len(s.unit_ids),s.units.size(0))

    def test_invalid_local_cues_rejected(self):
        with self.assertRaises(ValueError):
            self.m._flow(self.s,self.zero,.1,local_cues={0:torch.randn(3)})

    def test_zero_elapsed_is_identity(self):
        z=self.m._flow(self.s,self.zero,0)
        self.assertIs(z,self.s)


if __name__ == '__main__':
    unittest.main()
