"""Delta Neural Operator — current-state, co-evolving local law prototype.

This is a *neural-network computation mechanism*, not a pretrained language model.

Core state is the present effective configuration, not a history/event log:
    units / relations / executable operators / local boundaries / local laws / local time.

A shared trainable meta-rule acts on all these entities. Local *effective* laws
are part of the state and are themselves modified by contact, boundaries, and
elapsed local time. A unit may have zero, one, or arbitrarily many directed
relationships (subject only to actual memory and optional caller budgets).
Individuation may occur through an interaction of multiple existing units,
not only through a transformation of one existing unit. This computational
analogy is NOT a biological origin-of-life theory or a replication model.

There are no birth/contact/composition/death thresholds, mandated event counts,
fixed contact ports, or periodic deletion rules. Events compete using intensities
computed from the CURRENT configuration. A finite structural vocabulary is still
required to execute a finite program; the algorithm cannot invent arbitrary
mathematical primitives or bypass physical resource constraints.

This is a batch=1, interpretable reference implementation. The event scheduler
uses a piecewise-constant-hazard approximation while continuously flowing
between events. Its returned path log likelihood is correspondingly approximate;
it is useful for experimenting with score-function training, not an assertion
of exact continuous-time inference or correctness of any scientific theory.

This v3 reference implements a genuine *non-participation* distinction:
relations may remain present and evolve intrinsically without generating
messages until a shared-law interaction event is sampled. Local cues may be
addressed by stable current unit ID. No dormant flag, anchor class, fixed
reawakening deadline, or hard activation threshold is introduced.

The scheduler still uses a piecewise-constant hazard, enumerates candidate
pairs O(N²), and its finite primitives do not imply open-ended computation.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Optional, Sequence, Mapping
import math

import torch
from torch import Tensor, nn
import torch.nn.functional as F


# Only the algebra required to *execute* composition is fixed. Which operators
# exist, which relations use them, and how their effective laws behave can evolve.
# (kind, left parent, right parent); -1 means no parent.
BASE_OPERATIONS: tuple[str, ...] = ("identity", "neg", "tanh", "square")
COMPOSITE_OPERATIONS: tuple[str, ...] = ("add", "mul", "nested", "difference")
EVENT_KINDS: tuple[str, ...] = (
    "unit_branch", "unit_release", "relation_open", "relation_release",
    "operator_compose", "operator_rebind", "unit_assemble",
    "relation_interact",
)


@dataclass(frozen=True)
class OperatorNode:
    kind: str
    left: int = -1
    right: int = -1


@dataclass(frozen=True)
class ResourceBoundary:
    """External execution limits, NOT dynamic/semantic formation rules.

    None means no *configured* maximum; RAM and compute are always finite.
    Limiting events truncates the simulation rather than changing its law.
    """
    max_units: Optional[int] = None
    max_relations: Optional[int] = None
    max_operators: Optional[int] = None
    max_events_per_advance: Optional[int] = None


@dataclass(frozen=True)
class DeltaState:
    # The cardinalities N, E, P are all variable; P includes four executable bases.
    units: Tensor               # [N, D]
    boundaries: Tensor          # [N, B]
    unit_laws: Tensor           # [N, L]
    unit_times: Tensor          # [N, 1] — experienced local time
    unit_tempos: Tensor         # [N, 1] — effective pace, can change on contact
    edges: tuple[tuple[int, int], ...]     # E directed relations, no fixed degree
    relations: Tensor           # [E, R]
    relation_laws: Tensor       # [E, L]
    relation_times: Tensor      # [E, 1]
    relation_tempos: Tensor     # [E, 1]
    operators: tuple[OperatorNode, ...]   # P current executable DAG nodes
    op_states: Tensor           # [P, O]
    op_laws: Tensor             # [P, L]
    op_times: Tensor            # [P, 1]
    op_tempos: Tensor           # [P, 1]
    edge_operators: tuple[int, ...]       # E references into operators
    physical_time: float = 0.0
    # Stable CURRENT identities: needed to address local cues across birth/death.
    # These are not historical records.
    unit_ids: tuple[int, ...] = ()
    next_unit_id: int = 0

    def detach(self) -> "DeltaState":
        fields = ("units", "boundaries", "unit_laws", "unit_times", "unit_tempos",
                  "relations", "relation_laws", "relation_times", "relation_tempos",
                  "op_states", "op_laws", "op_times", "op_tempos")
        return replace(self, **{k: getattr(self, k).detach() for k in fields})

    def clone(self) -> "DeltaState":
        fields = ("units", "boundaries", "unit_laws", "unit_times", "unit_tempos",
                  "relations", "relation_laws", "relation_times", "relation_tempos",
                  "op_states", "op_laws", "op_times", "op_tempos")
        return replace(self, **{k: getattr(self, k).clone() for k in fields})

    @property
    def counts(self) -> tuple[int, int, int]:
        return self.units.size(0), len(self.edges), len(self.operators)

    def degree(self) -> tuple[tuple[int, int], ...]:
        """(out-degree, in-degree) for every currently existing unit."""
        n = self.units.size(0)
        outgoing, incoming = [0] * n, [0] * n
        for i, j in self.edges:
            outgoing[i] += 1
            incoming[j] += 1
        return tuple(zip(outgoing, incoming))


@dataclass(frozen=True)
class EvolutionResult:
    state: DeltaState
    logits: Tensor
    event_log_probability: Tensor  # optional score-function learning signal
    events_executed: int           # diagnostic only, not part of DeltaState
    truncated: bool               # external resource limit encountered
    interaction_events: int = 0     # diagnostic, never saved in DeltaState
    event_kinds: tuple[str, ...] = ()  # per-call diagnostic, not persistent history


@dataclass(frozen=True)
class _Proposal:
    kind: int
    source: int = -1
    target: int = -1
    edge: int = -1


class EvolvingDNO(nn.Module):
    """Variable-size, event-coupled, locally self-modifying neural operator.

    Time is both physical elapsed time and evolving *local* experienced time.
    Shared trainable parameters are the common computational substrate; effective
    local rules are variables in the current state, not immutable module roles.

    Discrete structural events are sampled. Ordinary backprop reaches continuous
    state/law flows. Their discrete choice probabilities may receive a
    score-function gradient via EvolutionResult.event_log_probability; a task
    loss by itself does NOT differentiate through a sampled topology decision.
    """

    def __init__(
        self,
        vocab_size: int,
        *,
        d_model: int = 48,
        d_boundary: int = 16,
        d_law: int = 16,
        d_relation: int = 16,
        d_operator: int = 16,
        d_hidden: int = 96,
        resources: Optional[ResourceBoundary] = None,
    ) -> None:
        super().__init__()
        if vocab_size <= 0 or min(d_model, d_boundary, d_law, d_relation,
                                  d_operator, d_hidden) <= 0:
            raise ValueError("All vocabulary and representation dimensions must be positive")
        self.vocab_size = vocab_size
        self.d = d_model
        self.b = d_boundary
        self.l = d_law
        self.r = d_relation
        self.o = d_operator
        self.resources = resources if resources is not None else ResourceBoundary()
        for value in (self.resources.max_units, self.resources.max_relations,
                      self.resources.max_operators,
                      self.resources.max_events_per_advance):
            if value is not None and value < 0:
                raise ValueError("Resource limits must be nonnegative or None")
        if self.resources.max_operators is not None and self.resources.max_operators < len(BASE_OPERATIONS):
            raise ValueError("The execution substrate must contain its base operators")

        self.embedding = nn.Embedding(vocab_size, self.d)
        self.external_projection = nn.Linear(self.d, self.d)
        self.unit_seed = nn.Linear(self.d, self.d + self.b + self.l + 1)

        # These local-law modulators alter the actual state transition operators.
        self.unit_modulation = nn.Linear(self.l, self.d)
        self.relation_modulation = nn.Linear(self.l, self.d)
        self.operator_modulation = nn.Linear(self.l, self.d)
        self.local_time_features = nn.Sequential(nn.Linear(2, self.l), nn.Tanh())

        # All updates are driven by the *current* interacting quantities.
        self.self_flow = self._mlp(self.d + self.b + self.l + self.l + self.d,
                                   self.d, d_hidden)
        self.edge_message = self._mlp(2 * self.d + 2 * self.b +
                                      self.r + 3 * self.l + self.d,
                                      2 * self.d, d_hidden)
        self.unit_meta = self._mlp(self.d + self.b + self.l + self.l +
                                    self.d + self.d,
                                    self.d + self.b + self.l + 1, d_hidden)
        self.relation_meta = self._mlp(2 * self.d + 2 * self.b + self.r +
                                       3 * self.l + self.d + self.d + self.d,
                                       self.r + self.l + 1, d_hidden)
        self.operator_meta = self._mlp(self.o + self.l + self.l + self.d,
                                       self.o + self.l + 1, d_hidden)
        self._relation_context_projection = nn.Linear(self.r, self.d)
        self._relation_clock_projection = nn.Linear(self.l, self.r)
        # A relation can evolve internally while it does NOT transmit to units,
        # other relations, or an operator. This law is shared by all relations.
        self.relation_autonomous = self._mlp(
            self.r + self.l + self.l, self.r + self.l + 1, d_hidden)

        # A single shared proposal scorer operates on all executable structural
        # events; the event kind is an argument, NOT a separate global manager.
        self.event_type = nn.Embedding(len(EVENT_KINDS), self.l)
        self.proposal_context_dim = (
            2 * (self.d + self.b + self.l + self.l) +
            (self.r + 2 * self.l) + self.d
        )
        self.hazard = self._mlp(self.proposal_context_dim + self.l,
                                1, d_hidden)

        # Changes to topology are themselves produced from current local state.
        self.branch_rule = self._mlp(self.d + self.b + self.l + self.l + self.d,
                                     self.d + self.b + self.l + 1, d_hidden)
        # Joint individuation: a fresh effective unit can be composed from two
        # current units and their effective local context. No source is copied,
        # no biological reproduction is presumed. The same shared event hazard
        # also decides whether this structural transition occurs at all.
        self.assembly_rule = self._mlp(self.proposal_context_dim,
                                       self.d + self.b + self.l + 1, d_hidden)
        self.link_rule = self._mlp(2 * self.d + 2 * self.b +
                                   2 * self.l + self.d,
                                   self.r + self.l + 1, d_hidden)
        self.op_seed_rule = self._mlp(self.r + self.l + self.d,
                                      self.o + self.l + 1, d_hidden)
        self.op_kind_rule = self._mlp(self.r + self.l + self.o + self.d,
                                      len(COMPOSITE_OPERATIONS), d_hidden)
        self.parent_query = nn.Linear(self.r + self.l + self.d, self.o)
        self.parent_key = nn.Linear(self.o + self.l, self.o)

        # The readout is simply a task interface, not a mandatory global
        # objective in the operator's internal dynamics.
        self.unit_readout = nn.Linear(self.d + self.b + self.l, 1)
        self.readout_norm = nn.LayerNorm(2 * self.d)
        self.output = nn.Linear(2 * self.d, vocab_size)

    @staticmethod
    def _mlp(in_dim: int, out_dim: int, hidden: int) -> nn.Sequential:
        return nn.Sequential(nn.Linear(in_dim, hidden), nn.SiLU(),
                             nn.Linear(hidden, out_dim))

    def initial_state(self) -> DeltaState:
        """Empty living ecology plus the minimum finite executable algebra."""
        w = self.embedding.weight
        zeros = lambda rows, width: w.new_zeros((rows, width))
        p = len(BASE_OPERATIONS)
        return DeltaState(
            units=zeros(0, self.d), boundaries=zeros(0, self.b),
            unit_laws=zeros(0, self.l), unit_times=zeros(0, 1),
            unit_tempos=zeros(0, 1), edges=(),
            relations=zeros(0, self.r), relation_laws=zeros(0, self.l),
            relation_times=zeros(0, 1), relation_tempos=zeros(0, 1),
            operators=tuple(OperatorNode(k) for k in BASE_OPERATIONS),
            op_states=zeros(p, self.o), op_laws=zeros(p, self.l),
            op_times=zeros(p, 1), op_tempos=zeros(p, 1),
            edge_operators=(), physical_time=0.0,
            unit_ids=(), next_unit_id=0,
        )

    def introduce_component(self, state: DeltaState, external: Tensor,
                            *, resources: Optional[ResourceBoundary] = None) -> DeltaState:
        """Expose one independent component supplied by the environment.

        This is an INPUT INTERFACE, not an autonomous creation event and not
        reproduction. The input representation becomes a new current unit;
        subsequent interactions/compositions remain governed by the same
        shared local rule. Use it when an environment exposes multiple
        independently existing constituents, instead of assuming they have
        all descended from the first token's effective unit.
        """
        if external.ndim != 1 or external.numel() != self.d:
            raise ValueError(f"external must have shape [{self.d}]")
        rb = resources if resources is not None else self.resources
        if rb.max_units is not None and state.units.size(0) >= rb.max_units:
            raise RuntimeError("external unit capacity reached")
        z = self.unit_seed(external)
        d, b, l = self.d, self.b, self.l
        return replace(
            state,
            units=torch.cat([state.units, torch.tanh(z[:d]).unsqueeze(0)], 0),
            boundaries=torch.cat([state.boundaries,
                                  torch.tanh(z[d:d+b]).unsqueeze(0)], 0),
            unit_laws=torch.cat([state.unit_laws,
                                 torch.tanh(z[d+b:d+b+l]).unsqueeze(0)], 0),
            unit_times=torch.cat([state.unit_times,
                                  external.new_zeros((1, 1))], 0),
            unit_tempos=torch.cat([state.unit_tempos,
                                   z[-1:].reshape(1, 1)], 0),
            unit_ids=state.unit_ids + (state.next_unit_id,),
            next_unit_id=state.next_unit_id + 1,
        )

    @staticmethod
    def _zeros_like_rows(example: Tensor, count: int, width: int) -> Tensor:
        return example.new_zeros((count, width))

    def _unit_time(self, state: DeltaState) -> Tensor:
        return self.local_time_features(torch.cat([state.unit_times, state.unit_tempos], -1))

    def _relation_time(self, state: DeltaState) -> Tensor:
        return self.local_time_features(torch.cat([state.relation_times,
                                                     state.relation_tempos], -1))

    def _operator_time(self, state: DeltaState) -> Tensor:
        return self.local_time_features(torch.cat([state.op_times, state.op_tempos], -1))

    def _ensure_external_seed(self, state: DeltaState, x: Tensor, rb: ResourceBoundary) -> DeltaState:
        """First external input constitutes a first active entity, not a reward event."""
        if state.units.size(0) or rb.max_units == 0:
            return state
        return self.introduce_component(state, x, resources=rb)

    def _programs(self, state: DeltaState, x: Tensor) -> Tensor:
        """Evaluate the *currently existing* operator DAG; output [P,E,D]."""
        e = x.size(0)
        if e == 0:
            return x.new_zeros((len(state.operators), 0, self.d))
        out: list[Tensor] = []
        for idx, op in enumerate(state.operators):
            if op.kind == "identity":
                v = x
            elif op.kind == "neg":
                v = -x
            elif op.kind == "tanh":
                v = x.tanh()
            elif op.kind == "square":
                v = x * x
            else:
                lhs, rhs = out[op.left], out[op.right]
                if op.kind == "add":
                    v = (lhs + rhs) * 0.5
                elif op.kind == "mul":
                    v = lhs * rhs
                elif op.kind == "nested":
                    v = torch.tanh(lhs + rhs)
                elif op.kind == "difference":
                    v = lhs - rhs
                else:
                    raise ValueError(f"Unknown executable operator: {op.kind}")
            # The current operator law affects executable output, not just naming.
            modulation = torch.tanh(self.operator_modulation(state.op_laws[idx]))
            out.append(torch.tanh(v * (1 + modulation.unsqueeze(0))))
        return torch.stack(out)

    def _effective_field(self, state: DeltaState, x: Tensor,
                         local_cues: Optional[Mapping[int, Tensor]] = None) -> Tensor:
        """Global environment plus cues addressed to CURRENT stable unit IDs.

        A cue is not broadcast to all units. Missing and extinct IDs are ignored;
        no remembered history or special memory-anchor category is introduced.
        """
        n = state.units.size(0)
        fields = []
        for unit_id in state.unit_ids:
            cue = None if local_cues is None else local_cues.get(unit_id)
            if cue is None:
                fields.append(x)
            else:
                if cue.shape != (self.d,) or cue.device != x.device:
                    raise ValueError('each local cue must have shape [d_model] on model device')
                fields.append(x + cue)
        return torch.stack(fields) if n else x.new_zeros((0, self.d))

    def _proposal_field(self, state: DeltaState, q: _Proposal, x: Tensor,
                        local_cues: Optional[Mapping[int, Tensor]] = None) -> Tensor:
        """Candidate's current local field, not a global all-unit cue broadcast."""
        if q.edge >= 0:
            indices = state.edges[q.edge]
        else:
            indices = tuple(i for i in (q.source, q.target) if i >= 0)
        if not indices or not local_cues:
            return x
        # O(1) for a one/two-unit proposal; never enumerate all n units to
        # resolve a single local cue. A pair samples its own current context.
        field = x
        for i in indices:
            cue = local_cues.get(state.unit_ids[i])
            if cue is not None:
                if cue.shape != (self.d,) or cue.device != x.device:
                    raise ValueError('each local cue must have shape [d_model] on model device')
                field = field + cue / len(indices)
        return field

    def _flow(self, state: DeltaState, x: Tensor, elapsed: float,
              local_cues: Optional[Mapping[int, Tensor]] = None) -> DeltaState:
        """Autonomous current-state evolution WITHOUT implicit transmission.

        Existing relations remain in state and can evolve internally while
        they do not affect external units/other relations/operators. A distinct
        interaction event is required for actual outward relational messages.
        Right-hand sides use the same current state (Euler approximation).
        """
        if elapsed <= 0:
            return state
        n, e, p = state.counts
        h, b, laws = state.units, state.boundaries, state.unit_laws
        u_clock = self._unit_time(state)
        r_clock = self._relation_time(state)
        o_clock = self._operator_time(state)
        fields = self._effective_field(state, x, local_cues)
        if n:
            self_in = torch.cat([h, b, laws, u_clock, fields], -1)
            intrinsic = self.self_flow(self_in)
            intrinsic = intrinsic * (1 + torch.tanh(self.unit_modulation(laws)))
            no_external_relation_impact = torch.zeros_like(h)
            unit_in = torch.cat([h, b, laws, u_clock, intrinsic,
                                 no_external_relation_impact], -1)
            delta = self.unit_meta(unit_in)
            d_h, d_b, d_l, d_tempo = torch.split(
                delta, [self.d, self.b, self.l, 1], -1)
            h_next = h + elapsed * torch.tanh(d_h + intrinsic)
            b_next = b + elapsed * torch.tanh(d_b)
            law_next = laws + elapsed * torch.tanh(d_l)
            utempo_next = state.unit_tempos + elapsed * torch.tanh(d_tempo)
            unit_time_next = state.unit_times + elapsed * F.softplus(state.unit_tempos)
        else:
            h_next, b_next, law_next = h, b, laws
            utempo_next, unit_time_next = state.unit_tempos, state.unit_times

        if e:
            # Only its own current relation state/law/time enters its intrinsic
            # evolution. Endpoints/other edges are not silently contacted.
            independent = self.relation_autonomous(torch.cat([
                state.relations, state.relation_laws, r_clock], -1))
            d_r, d_rl, d_rtempo = torch.split(independent,
                                               [self.r, self.l, 1], -1)
            rel_next = state.relations + elapsed * torch.tanh(
                d_r + self._relation_clock_projection(r_clock))
            rl_next = state.relation_laws + elapsed * torch.tanh(d_rl)
            rtempo_next = state.relation_tempos + elapsed * torch.tanh(d_rtempo)
            rel_time_next = state.relation_times + elapsed * F.softplus(
                state.relation_tempos)
        else:
            rel_next, rl_next = state.relations, state.relation_laws
            rtempo_next, rel_time_next = state.relation_tempos, state.relation_times

        # Operators also continue their own evolution, but no relation is
        # allowed to influence them without an interaction event.
        op_inputs = state.op_states.new_zeros((p, self.d))
        operator_in = torch.cat([state.op_states, state.op_laws,
                                 o_clock, op_inputs], -1)
        op_delta = self.operator_meta(operator_in)
        d_op, d_ol, d_otempo = torch.split(op_delta,
                                           [self.o, self.l, 1], -1)
        op_next = state.op_states + elapsed * torch.tanh(d_op)
        ol_next = state.op_laws + elapsed * torch.tanh(d_ol)
        optempo_next = state.op_tempos + elapsed * torch.tanh(d_otempo)
        op_time_next = state.op_times + elapsed * F.softplus(state.op_tempos)
        return replace(
            state, units=h_next, boundaries=b_next, unit_laws=law_next,
            unit_times=unit_time_next, unit_tempos=utempo_next,
            relations=rel_next, relation_laws=rl_next,
            relation_times=rel_time_next, relation_tempos=rtempo_next,
            op_states=op_next, op_laws=ol_next,
            op_times=op_time_next, op_tempos=optempo_next,
            physical_time=state.physical_time + elapsed,
        )

    def _interact(self, state: DeltaState, edge: int, x: Tensor) -> DeltaState:
        """Execute ONE actual relational interaction on the current structure.

        A retained relation is not continuously 'on'. When selected by the
        shared event intensity, its endpoints, its own state/law, and its
        active operator may be modified through existing trainable rules.
        Other relations do not automatically participate in this event.
        """
        src, dst = state.edges[edge]
        h, b, law = state.units, state.boundaries, state.unit_laws
        rel, rl = state.relations, state.relation_laws
        pair = torch.cat([h[src], h[dst], b[src], b[dst], rel[edge],
                          law[src], law[dst], rl[edge], x])
        message = self.edge_message(pair)
        raw, reaction = message.split(self.d, -1)
        program_bank = self._programs(state, raw.unsqueeze(0))
        op_id = state.edge_operators[edge]
        chosen = program_bank[op_id, 0] * (
            1 + torch.tanh(self.relation_modulation(rl[edge])))

        # Both contact partners may change, without enforcing symmetry.
        indices = torch.tensor([src, dst], device=h.device, dtype=torch.long)
        impacts = torch.stack([torch.tanh(reaction), chosen], 0)
        hc, bc, lc = h.index_select(0, indices), b.index_select(0, indices), law.index_select(0, indices)
        uclock = self._unit_time(state).index_select(0, indices)
        local_field = x.expand(2, -1)
        intrinsic = self.self_flow(torch.cat([hc, bc, lc, uclock, local_field], -1))
        intrinsic = intrinsic * (1 + torch.tanh(self.unit_modulation(lc)))
        delta = self.unit_meta(torch.cat([hc, bc, lc, uclock, intrinsic, impacts], -1))
        dh, db, dl, dtempo = torch.split(delta,
                                         [self.d, self.b, self.l, 1], -1)
        # Subtract the no-contact event contribution so the interaction is a
        # true relational increment, not another autonomous flow step.
        baseline = self.unit_meta(torch.cat([
            hc, bc, lc, uclock, intrinsic, torch.zeros_like(impacts)], -1))
        bdh, bdb, bdl, bdtempo = torch.split(baseline,
                                             [self.d, self.b, self.l, 1], -1)
        h_inc = torch.tanh(dh + intrinsic + impacts) - torch.tanh(bdh + intrinsic)
        b_inc = torch.tanh(db) - torch.tanh(bdb)
        law_inc = torch.tanh(dl) - torch.tanh(bdl)
        tempo_inc = torch.tanh(dtempo) - torch.tanh(bdtempo)
        h_next = h.index_add(0, indices, h_inc)
        b_next = b.index_add(0, indices, b_inc)
        laws_next = law.index_add(0, indices, law_inc)
        tempo_next = state.unit_tempos.index_add(0, indices, tempo_inc)

        # Relation-to-relation influence is possible only via an actual
        # interaction reading its CURRENT neighboring relation context.
        n,e,_ = state.counts
        rel_sum = rel.new_zeros((n,self.r))
        rel_count = rel.new_zeros((n,1))
        for k, (i,j) in enumerate(state.edges):
            rel_sum = rel_sum.index_add(0, torch.tensor([i,j],device=h.device),
                                         rel[k].unsqueeze(0).expand(2,-1))
            rel_count = rel_count.index_add(0, torch.tensor([i,j],device=h.device),
                                             rel.new_ones((2,1)))
        neighbor_context = rel_sum / (1 + rel_count)
        neighbor_msg = torch.tanh(self._relation_context_projection(
            neighbor_context[src] + neighbor_context[dst]))
        rel_delta = self.relation_meta(torch.cat([pair, chosen, neighbor_msg]))
        dr,drl,drtempo = torch.split(rel_delta, [self.r,self.l,1])
        idx = torch.tensor([edge],dtype=torch.long,device=h.device)
        rel_next = rel.index_add(0,idx,torch.tanh(dr).unsqueeze(0))
        rl_next = rl.index_add(0,idx,torch.tanh(drl).unsqueeze(0))
        rtempo_next = state.relation_tempos.index_add(
            0,idx,torch.tanh(drtempo).reshape(1,1))

        op_input = torch.cat([state.op_states[op_id], state.op_laws[op_id],
                              self._operator_time(state)[op_id], chosen])
        opd = self.operator_meta(op_input)
        dop,dol,dotempo = torch.split(opd,[self.o,self.l,1])
        opidx = torch.tensor([op_id],dtype=torch.long,device=h.device)
        op_states_next = state.op_states.index_add(0,opidx,torch.tanh(dop).unsqueeze(0))
        op_laws_next = state.op_laws.index_add(0,opidx,torch.tanh(dol).unsqueeze(0))
        op_tempo_next = state.op_tempos.index_add(0,opidx,torch.tanh(dotempo).reshape(1,1))

        return replace(state, units=h_next, boundaries=b_next,
                       unit_laws=laws_next, unit_tempos=tempo_next,
                       relations=rel_next, relation_laws=rl_next,
                       relation_tempos=rtempo_next, op_states=op_states_next,
                       op_laws=op_laws_next, op_tempos=op_tempo_next)

    def _proposal_context(self, state: DeltaState,
                          proposal: _Proposal, x: Tensor,
                          local_cues: Optional[Mapping[int, Tensor]] = None,
                          unit_clock: Optional[Tensor] = None,
                          relation_clock: Optional[Tensor] = None) -> Tensor:
        n, e, _ = state.counts
        ut = self._unit_time(state) if unit_clock is None else unit_clock
        rt = self._relation_time(state) if relation_clock is None else relation_clock
        unit_width = self.d + self.b + 2 * self.l
        relation_width = self.r + 2 * self.l
        zero_u = x.new_zeros(unit_width)
        zero_r = x.new_zeros(relation_width)

        def unit(i: int) -> Tensor:
            if i < 0:
                return zero_u
            return torch.cat([state.units[i], state.boundaries[i],
                              state.unit_laws[i], ut[i]], -1)

        if proposal.edge >= 0:
            r = proposal.edge
            rel = torch.cat([state.relations[r], state.relation_laws[r], rt[r]], -1)
            s, t = state.edges[r]
        else:
            rel = zero_r
            s, t = proposal.source, proposal.target
        return torch.cat([unit(s), unit(t), rel,
                          self._proposal_field(state, proposal, x, local_cues)], -1)

    def _proposals(self, state: DeltaState, rb: ResourceBoundary) -> list[_Proposal]:
        n, e, p = state.counts
        proposals: list[_Proposal] = []
        # No fixed number of ports or contacts for any given individual.
        # All possible *directed* pairs are enumerated here (O(N²)), both
        # for contact and for possible joint individuation. This is a finite
        # reference algorithm, not a scalable all-to-all-free implementation.
        if rb.max_units is None or n < rb.max_units:
            proposals.extend(_Proposal(0, source=i) for i in range(n))
            # Composition is an additional *possibility*, not a mandated
            # "birth mechanism" or a reproduction stage. Ordered pairs retain
            # possible directional asymmetry. There are no preallocated ports.
            # Include both coupled and as-yet-unconnected pairs: environment
            # can create an opportunity before an explicit relation exists.
            edge_lookup = {pair: k for k, pair in enumerate(state.edges)}
            proposals.extend(
                _Proposal(6, source=i, target=j,
                          edge=edge_lookup.get((i, j), -1))
                for i in range(n) for j in range(n) if i != j
            )
        proposals.extend(_Proposal(1, source=i) for i in range(n))
        if rb.max_relations is None or e < rb.max_relations:
            connected = set(state.edges)
            proposals.extend(
                _Proposal(2, source=i, target=j)
                for i in range(n) for j in range(n)
                if i != j and (i, j) not in connected
            )
        proposals.extend(_Proposal(3, edge=k) for k in range(e))
        # Retained edges MAY interact; existing does not imply participating.
        proposals.extend(_Proposal(7, edge=k) for k in range(e))
        if rb.max_operators is None or p < rb.max_operators:
            proposals.extend(_Proposal(4, edge=k) for k in range(e))
        if p > len(BASE_OPERATIONS):
            proposals.extend(_Proposal(5, edge=k) for k in range(e))
        return proposals

    def _event_rates(self, state: DeltaState, x: Tensor,
                     proposals: Sequence[_Proposal],
                     local_cues: Optional[Mapping[int, Tensor]] = None) -> Tensor:
        if not proposals:
            return x.new_zeros((0,))
        unit_clock = self._unit_time(state)
        relation_clock = self._relation_time(state)
        contexts = torch.stack([self._proposal_context(
            state,q,x,local_cues,unit_clock,relation_clock)
            for q in proposals])
        kinds = torch.tensor([q.kind for q in proposals],
                             dtype=torch.long, device=x.device)
        features = torch.cat([contexts, self.event_type(kinds)], -1)
        # A learned nonnegative intensity, not a manually chosen birth threshold.
        # Even if intensity > 0, finite windows may yield NO event.
        return F.softplus(self.hazard(features).squeeze(-1))

    def _choose(self, logits: Tensor, stochastic: bool) -> tuple[int, Tensor]:
        if stochastic:
            distribution = torch.distributions.Categorical(logits=logits)
            sampled = distribution.sample()
            return int(sampled.item()), distribution.log_prob(sampled)
        index = int(torch.argmax(logits.detach()).item())
        return index, F.log_softmax(logits, -1)[index]

    def _choose_operator(self, state: DeltaState, edge: int, x: Tensor,
                         stochastic: bool) -> tuple[int, Tensor]:
        q = torch.cat([state.relations[edge], state.relation_laws[edge], x])
        query = self.parent_query(q)
        keys = self.parent_key(torch.cat([state.op_states, state.op_laws], -1))
        logits = keys @ query / math.sqrt(self.o)
        return self._choose(logits, stochastic)

    def _garbage_collect_operators(self, state: DeltaState) -> DeltaState:
        """Keep only currently reachable composite operators. No event archive."""
        keep = set(range(len(BASE_OPERATIONS)))

        def visit(idx: int) -> None:
            if idx in keep:
                return
            keep.add(idx)
            op = state.operators[idx]
            if op.left >= 0:
                visit(op.left)
            if op.right >= 0:
                visit(op.right)

        for op_id in state.edge_operators:
            visit(op_id)
        indices = sorted(keep)
        if len(indices) == len(state.operators):
            return state
        mapping = {old: new for new, old in enumerate(indices)}
        ops = tuple(OperatorNode(
            state.operators[i].kind,
            mapping[state.operators[i].left] if state.operators[i].left >= 0 else -1,
            mapping[state.operators[i].right] if state.operators[i].right >= 0 else -1,
        ) for i in indices)
        selection = torch.tensor(indices, dtype=torch.long, device=state.op_states.device)
        return replace(
            state, operators=ops,
            op_states=state.op_states.index_select(0, selection),
            op_laws=state.op_laws.index_select(0, selection),
            op_times=state.op_times.index_select(0, selection),
            op_tempos=state.op_tempos.index_select(0, selection),
            edge_operators=tuple(mapping[i] for i in state.edge_operators),
        )

    def _apply_event(self, state: DeltaState, q: _Proposal,
                     x: Tensor, stochastic: bool,
                     local_cues: Optional[Mapping[int, Tensor]] = None) -> tuple[DeltaState, Tensor]:
        """One structural transition OR an actual interaction event."""
        original_environment = x
        x = self._proposal_field(state, q, x, local_cues)
        logp = x.new_zeros(())
        if q.kind == 0:  # unit branches from its CURRENT effective configuration
            i = q.source
            local = torch.cat([
                state.units[i], state.boundaries[i], state.unit_laws[i],
                self._unit_time(state)[i], x,
            ], -1)
            z = self.branch_rule(local)
            d, b, l = self.d, self.b, self.l
            child = torch.tanh(z[:d] + state.units[i])
            child_boundary = torch.tanh(z[d:d+b] + state.boundaries[i])
            child_law = torch.tanh(z[d+b:d+b+l] + state.unit_laws[i])
            child_tempo = z[-1:].reshape(1, 1) + state.unit_tempos[i:i+1]
            state = replace(
                state, units=torch.cat([state.units, child.unsqueeze(0)], 0),
                boundaries=torch.cat([state.boundaries, child_boundary.unsqueeze(0)], 0),
                unit_laws=torch.cat([state.unit_laws, child_law.unsqueeze(0)], 0),
                unit_times=torch.cat([state.unit_times,
                                      state.unit_times[i:i+1]], 0),
                unit_tempos=torch.cat([state.unit_tempos, child_tempo], 0),
                unit_ids=state.unit_ids + (state.next_unit_id,),
                next_unit_id=state.next_unit_id + 1,
            )
        elif q.kind == 6:  # individuation from JOINT current conditions
            # Neither parent must be replaced or duplicated. The new current
            # unit is an effective outcome of their combined action and the
            # environmental field. A relation need not have existed already.
            i, j = q.source, q.target
            if i < 0 or j < 0 or i == j:
                raise ValueError("joint individuation requires distinct units")
            context = self._proposal_context(state, q, original_environment, local_cues)
            z = self.assembly_rule(context)
            d, b, l = self.d, self.b, self.l
            state = replace(
                state,
                units=torch.cat([state.units, torch.tanh(z[:d]).unsqueeze(0)], 0),
                boundaries=torch.cat([
                    state.boundaries, torch.tanh(z[d:d+b]).unsqueeze(0)], 0),
                unit_laws=torch.cat([
                    state.unit_laws, torch.tanh(z[d+b:d+b+l]).unsqueeze(0)], 0),
                # A new unit has its OWN local time, not a copied event log.
                unit_times=torch.cat([state.unit_times, x.new_zeros((1, 1))], 0),
                unit_tempos=torch.cat([state.unit_tempos,
                                       z[-1:].reshape(1, 1)], 0),
                unit_ids=state.unit_ids + (state.next_unit_id,),
                next_unit_id=state.next_unit_id + 1,
            )
        elif q.kind == 1:  # unit can disappear; remaining indices are remapped
            i = q.source
            n = state.units.size(0)
            keep_u = torch.tensor([j for j in range(n) if j != i],
                                  dtype=torch.long, device=x.device)
            keep_e = [k for k, (s, t) in enumerate(state.edges) if i not in (s, t)]
            e_index = torch.tensor(keep_e, dtype=torch.long, device=x.device)
            remap = {j: (j if j < i else j - 1) for j in range(n) if j != i}
            state = replace(
                state,
                units=state.units.index_select(0, keep_u),
                boundaries=state.boundaries.index_select(0, keep_u),
                unit_laws=state.unit_laws.index_select(0, keep_u),
                unit_times=state.unit_times.index_select(0, keep_u),
                unit_tempos=state.unit_tempos.index_select(0, keep_u),
                edges=tuple((remap[s], remap[t]) for k, (s, t)
                            in enumerate(state.edges) if k in keep_e),
                relations=state.relations.index_select(0, e_index),
                relation_laws=state.relation_laws.index_select(0, e_index),
                relation_times=state.relation_times.index_select(0, e_index),
                relation_tempos=state.relation_tempos.index_select(0, e_index),
                edge_operators=tuple(state.edge_operators[k] for k in keep_e),
                unit_ids=tuple(state.unit_ids[j] for j in range(n) if j != i),
            )
            state = self._garbage_collect_operators(state)
        elif q.kind == 2:  # new directed relation; its reverse is independent
            i, j = q.source, q.target
            z = self.link_rule(torch.cat([
                state.units[i], state.units[j],
                state.boundaries[i], state.boundaries[j],
                state.unit_laws[i], state.unit_laws[j], x,
            ], -1))
            r, l = self.r, self.l
            state = replace(
                state, edges=state.edges + ((i, j),),
                relations=torch.cat([state.relations, torch.tanh(z[:r]).unsqueeze(0)], 0),
                relation_laws=torch.cat([state.relation_laws,
                                         torch.tanh(z[r:r+l]).unsqueeze(0)], 0),
                relation_times=torch.cat([state.relation_times,
                                          (state.unit_times[i:i+1] +
                                           state.unit_times[j:j+1]) / 2], 0),
                relation_tempos=torch.cat([state.relation_tempos,
                                           z[-1:].reshape(1, 1)], 0),
                edge_operators=state.edge_operators + (0,),
            )
        elif q.kind == 3:  # unlink; state not logged once it ceases to exist
            k = q.edge
            indices = torch.tensor([i for i in range(len(state.edges)) if i != k],
                                   dtype=torch.long, device=x.device)
            state = replace(
                state, edges=tuple(pair for i, pair in enumerate(state.edges) if i != k),
                relations=state.relations.index_select(0, indices),
                relation_laws=state.relation_laws.index_select(0, indices),
                relation_times=state.relation_times.index_select(0, indices),
                relation_tempos=state.relation_tempos.index_select(0, indices),
                edge_operators=tuple(o for i, o in enumerate(state.edge_operators) if i != k),
            )
            state = self._garbage_collect_operators(state)
        elif q.kind == 4:  # locally compose a currently executable operator
            k = q.edge
            u, p_u = self._choose_operator(state, k, x, stochastic)
            v, p_v = self._choose_operator(state, k, x, stochastic)
            local = torch.cat([state.relations[k], state.relation_laws[k],
                               state.op_states[u], x], -1)
            kind, p_kind = self._choose(self.op_kind_rule(local), stochastic)
            logp = p_u + p_v + p_kind
            z = self.op_seed_rule(torch.cat([
                state.relations[k], state.relation_laws[k], x,
            ]))
            o, l = self.o, self.l
            new_id = len(state.operators)
            ops = list(state.edge_operators)
            ops[k] = new_id
            state = replace(
                state,
                operators=state.operators +
                          (OperatorNode(COMPOSITE_OPERATIONS[kind], u, v),),
                op_states=torch.cat([state.op_states, torch.tanh(z[:o]).unsqueeze(0)], 0),
                op_laws=torch.cat([state.op_laws, torch.tanh(z[o:o+l]).unsqueeze(0)], 0),
                op_times=torch.cat([state.op_times, state.relation_times[k:k+1]], 0),
                op_tempos=torch.cat([state.op_tempos, z[-1:].reshape(1, 1)], 0),
                edge_operators=tuple(ops),
            )
        elif q.kind == 7:  # retained relation ACTUALLY acts this instant
            state = self._interact(state, q.edge, x)
        elif q.kind == 5:  # reassign an edge's effective operation
            k = q.edge
            selected, logp = self._choose_operator(state, k, x, stochastic)
            ops = list(state.edge_operators)
            ops[k] = selected
            state = replace(state, edge_operators=tuple(ops))
            state = self._garbage_collect_operators(state)
        else:
            raise ValueError(f"Unknown structural event kind: {q.kind}")
        return state, logp

    def _readout(self, state: DeltaState, x: Tensor) -> Tensor:
        if state.units.size(0) == 0:
            summary = x.new_zeros(self.d)
        else:
            features = torch.cat([state.units, state.boundaries,
                                  state.unit_laws], -1)
            weights = F.softmax(self.unit_readout(features).squeeze(-1), 0)
            summary = torch.sum(state.units * weights.unsqueeze(-1), 0)
        return self.output(self.readout_norm(torch.cat([summary, x], -1)))

    def advance(self, state: DeltaState, *, external: Optional[Tensor] = None,
                duration: float = 1.0, stochastic: bool = True,
                resources: Optional[ResourceBoundary] = None,
                local_cues: Optional[Mapping[int, Tensor]] = None) -> EvolutionResult:
        """Evolve for a duration; structural event count is not preordained.

        Caller-supplied resource limits, if any, bound actual computational work.
        Training of discrete structural choice requires using the returned
        log-probability in a score-function estimator. See policy_loss().
        """
        if not math.isfinite(duration) or duration < 0:
            raise ValueError("duration must be finite and nonnegative")
        if external is None:
            x = self.embedding.weight.new_zeros((self.d,))
        else:
            if external.ndim != 1 or external.numel() != self.d:
                raise ValueError(f"external must have shape [{self.d}]")
            x = external
        rb = resources if resources is not None else self.resources
        state = self._ensure_external_seed(state, x, rb) if external is not None else state
        if rb.max_operators is not None and rb.max_operators < len(BASE_OPERATIONS):
            raise ValueError("External operator capacity is below base algebra")
        remaining = float(duration)
        total_logp = x.new_zeros(())
        events = 0
        truncated = False
        interaction_events = 0
        kinds_executed: list[str] = []
        while remaining > 0:
            if (rb.max_events_per_advance is not None and
                    events >= rb.max_events_per_advance):
                truncated = True
                state = self._flow(state, x, remaining, local_cues)
                remaining = 0.0
                break
            proposals = self._proposals(state, rb)
            if not proposals:
                state = self._flow(state, x, remaining, local_cues)
                remaining = 0.0
                break
            rates = self._event_rates(state, x, proposals, local_cues)
            summed = rates.sum()
            if not bool(torch.isfinite(summed).detach()):
                raise FloatingPointError("event intensity became non-finite")
            if float(summed.detach()) == 0:
                state = self._flow(state, x, remaining, local_cues)
                remaining = 0.0
                break
            if stochastic:
                waiting = float(torch.distributions.Exponential(
                    summed.detach()).sample().item())
            else:
                waiting = 1.0 / float(summed.detach())
            if 0 <= waiting < math.ulp(remaining):
                waiting = math.ulp(remaining)
            if waiting >= remaining:
                # No event: probability of survival in this time window.
                total_logp = total_logp - summed * remaining
                state = self._flow(state, x, remaining, local_cues)
                remaining = 0.0
            else:
                total_logp = total_logp - summed * waiting
                state = self._flow(state, x, waiting, local_cues)
                # Intensity/choice refers to the beginning of this local
                # window; the flow may have changed it before event time.
                index, selected_logp = self._choose(torch.log(rates), stochastic)
                total_logp = total_logp + torch.log(summed) + selected_logp
                event_kind = proposals[index].kind
                state, structural_logp = self._apply_event(
                    state, proposals[index], x, stochastic, local_cues)
                kinds_executed.append(EVENT_KINDS[event_kind])
                interaction_events += int(event_kind == 7)
                total_logp = total_logp + structural_logp
                remaining -= waiting
                events += 1
        return EvolutionResult(state, self._readout(state, x),
                               total_logp, events, truncated,
                               interaction_events, tuple(kinds_executed))

    def step(self, token: Tensor | int, state: Optional[DeltaState] = None,
             *, duration: float = 1.0, stochastic: bool = True,
             resources: Optional[ResourceBoundary] = None) -> EvolutionResult:
        if state is None:
            state = self.initial_state()
        if isinstance(token, Tensor):
            if token.numel() != 1:
                raise ValueError("step accepts one scalar token")
            token = token.reshape(()).long().to(self.embedding.weight.device)
        else:
            token = torch.tensor(token, dtype=torch.long,
                                 device=self.embedding.weight.device)
        external = self.external_projection(self.embedding(token))
        return self.advance(state, external=external, duration=duration,
                            stochastic=stochastic, resources=resources)

    def forward(self, tokens: Tensor, state: Optional[DeltaState] = None,
                *, duration: float = 1.0, stochastic: bool = True,
                resources: Optional[ResourceBoundary] = None,
                return_state: bool = False,
                return_event_log_probability: bool = False):
        """Autoregressive language-model interface, reference batch size 1.

        All information from prior inputs needed for inference is represented
        by the passed current state. There is no mandatory input replay cache.
        """
        if tokens.ndim == 2:
            if tokens.size(0) != 1:
                raise ValueError("Dynamic reference implementation supports batch=1")
            tokens = tokens.squeeze(0)
        if tokens.ndim != 1 or tokens.numel() == 0:
            raise ValueError("tokens must be nonempty [T] or [1,T]")
        if state is None:
            state = self.initial_state()
        logits = []
        path_logp = self.embedding.weight.new_zeros(())
        for token in tokens:
            result = self.step(token, state, duration=duration,
                               stochastic=stochastic, resources=resources)
            state = result.state
            logits.append(result.logits)
            path_logp = path_logp + result.event_log_probability
        output = torch.stack(logits, 0).unsqueeze(0)
        if return_state and return_event_log_probability:
            return output, state, path_logp
        if return_state:
            return output, state
        if return_event_log_probability:
            return output, path_logp
        return output

    @staticmethod
    def policy_loss(task_loss: Tensor, event_log_probability: Tensor,
                    baseline: Optional[Tensor | float] = None) -> Tensor:
        """One possible score-function surrogate for sampled structural events.

        Not a built-in internal objective of Delta. The caller supplies the
        training objective and, if desired, its own baseline/control variate.
        The log probability is approximate because of event-rate freezing.
        """
        advantage = task_loss.detach()
        if baseline is not None:
            advantage = advantage - torch.as_tensor(baseline,
                dtype=advantage.dtype, device=advantage.device).detach()
        return task_loss + advantage * event_log_probability

    @torch.no_grad()
    def generate(self, prompt: Tensor, new_tokens: int,
                 *, duration: float = 1.0, stochastic: bool = True,
                 resources: Optional[ResourceBoundary] = None) -> Tensor:
        if prompt.ndim == 1:
            prompt = prompt.unsqueeze(0)
        logits, state = self.forward(prompt, duration=duration,
                                     stochastic=stochastic,
                                     resources=resources, return_state=True)
        output = prompt.clone()
        for _ in range(new_tokens):
            nxt = torch.argmax(logits[0, -1]).reshape(1, 1)
            output = torch.cat([output, nxt], 1)
            step = self.step(nxt.squeeze(), state, duration=duration,
                             stochastic=stochastic, resources=resources)
            logits, state = step.logits.reshape(1, 1, -1), step.state
        return output
