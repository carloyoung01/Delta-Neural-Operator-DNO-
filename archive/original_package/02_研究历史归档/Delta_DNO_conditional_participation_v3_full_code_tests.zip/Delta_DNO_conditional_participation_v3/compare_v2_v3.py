"""Compare presence-only causal influence in unchanged v2 vs v3.

No training and no explicit contact events within flow; both models are
separately randomized. This is a code-semantics check, not a fair ability
comparison or a parameter-matched benchmark.
"""
from __future__ import annotations
import importlib.util, json, sys
from pathlib import Path
import torch
from dno_conditional import EvolvingDNO as V3, _Proposal as PropV3
from tests.test_v3 import remove_edges

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v2_unmodified',ROOT/'reference_v2/dno_compositional.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(1)


def case(model_cls,prop_cls,seed):
    torch.manual_seed(seed)
    m=model_cls(16,d_model=8,d_boundary=4,d_law=4,d_relation=4,d_operator=4,d_hidden=24)
    s=m.initial_state()
    for _ in range(3):
        s=m.introduce_component(s,torch.randn(8))
    with torch.no_grad():
        s,_=m._apply_event(s,prop_cls(2,source=0,target=1),torch.zeros(8),False)
        a=m._flow(s,torch.zeros(8),.1)
        b=m._flow(remove_edges(s),torch.zeros(8),.1)
    return float((a.units-b.units).norm()),float((a.relations-s.relations).norm())


def main():
    trials=[]
    for seed in range(20):
        v2,r2=case(module.EvolvingDNO,module._Proposal,seed)
        v3,r3=case(V3,PropV3,seed)
        trials.append({'seed':seed,'v2_unit_presence_effect_l2':v2,
                       'v3_unit_presence_effect_l2':v3,
                       'v2_relation_intrinsic_change_l2':r2,
                       'v3_relation_intrinsic_change_l2':r3})
    result={'source_v2_unmodified':True,'seeds':20,
            'v2_nonzero_presence_effects':sum(x['v2_unit_presence_effect_l2']>1e-8 for x in trials),
            'v3_exact_zero_presence_effects':sum(x['v3_unit_presence_effect_l2']==0 for x in trials),
            'v3_relations_evolved':sum(x['v3_relation_intrinsic_change_l2']>1e-8 for x in trials),
            'trials':trials}
    target=ROOT/'results/BASELINE_COMPARISON.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k!='trials'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
