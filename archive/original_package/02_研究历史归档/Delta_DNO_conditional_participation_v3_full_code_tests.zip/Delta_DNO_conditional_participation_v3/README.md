# Delta DNO v3 · 当前结构的条件性参与（参考实现）

**目的**：让普通单元与关系在当前状态中持续存在和自主演化，同时取消“凡是存在的关系，每一次连续更新都必须向外传递消息”的假设。关系只有在共享可学习事件规律实际采样出 `relation_interact` 事件时才传递对应的外部消息。**不增加记忆锚点类、显式休眠位、固定唤醒周期或人工接触阈值。**

此实现是 *PyTorch 研究原型*，不是训练完成的语言大模型，也不证明 Delta 是自然界的普适规律。

## 文件

- `dno_conditional.py`：全部可运行的 v3 核心代码。
- `reference_v2/dno_compositional.py`：原封不动的上一版 v2，SHA256 对照记录在 `TEST_REPORT_ZH.md`。
- `reference_v2/test_smoke.py`：原版4项测试。
- `tests/test_v3.py`：v3 的18项代码级检查。
- `experiments.py`：32组持久性、32组因果干预、96组随机事件、3组微型监督学习以及8组长期演化。
- `compare_v2_v3.py`：20组 v2 与 v3 的被动关系影响对照。
- `results/`：所有真实执行的日志、原始 JSON 和汇总文件。
- `DELTA_CONDITIONAL_PARTICIPATION_MATH_ZH.md`：数学与概念边界。
- `TEST_REPORT_ZH.md`：测量条件与完整结果。
- `CODE_DIFF.patch`：旧版到新版的精确代码差异。

## 运行

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python experiments.py
python compare_v2_v3.py

# 旧版回归测试（在不修改原版前提下）
cd reference_v2
python -m unittest discover -s . -p 'test_smoke.py' -v
```

Python 3.13、PyTorch 2.10.0+cpu 已实际运行。可以在项目根目录设置 `OMP_NUM_THREADS=1` 获得可比较的本地速度。所有合成演化均发生在 CPU 小模型中。随机种子和关键参数写在脚本中，仅为实验可复现；不是 DNO 自身的形成/消散条件。

## 核心调用

```python
import torch
from dno_conditional import EvolvingDNO, ResourceBoundary

model = EvolvingDNO(64, d_model=16, d_boundary=8, d_law=8,
                    d_relation=8, d_operator=8, d_hidden=32)
state = model.initial_state()
state = model.introduce_component(state, torch.randn(16))
state = model.introduce_component(state, torch.randn(16))

# 接触线索定位于稳定的当前单元 ID，不会给所有单元广播。
cue = {state.unit_ids[0]: torch.randn(16)}
result = model.advance(state, duration=0.1, local_cues=cue,
                       stochastic=True)
state = result.state
print(state.counts, result.event_kinds, result.interaction_events)

# 普通语言 step / forward 接口仍然保留；external 是全局环境输入。
logits = model(torch.tensor([[2, 3]]), duration=0.01)
```

`resource` 的数值预算可为 `None`，表示没有**预先配置的**上限，并非无穷的物理内存。`max_events_per_advance` 是外部计算截断，触及时返回 `truncated=True`。`EvolutionResult.event_kinds` 仅为此次调用的外部诊断，**不**存储在下一当前状态中。

## 最重要的差别

- v2：关系存在即进入每次 `_flow()` 的消息计算；哪怕没有结构事件，仍改变单元更新。
- v3：`_flow()` 使单元与关系分别按共享规律进行自身演化，**不存在从被动关系发往端点的消息**；新增 `relation_interact` 事件，只有实际采样此事件才发生接触、作用和更新。
- 关系参与性不是一个 `sleep` / `wake` 布尔状态，而是指定时间窗口内**是否实际发生过接触事件**。未参与时，它的状态、局部规律和时间仍在变化。
- 接触数量可为零或不对称；局部线索通过 `unit_ids` 选择性进入对应单元与事件提议。
- 可学习共享规律决定非负事件发生率；离散事件采样本身仍需要显式的估计器或训练目标才能学习。

## 未解决与不能宣称的内容

1. 候选新接触和共同组合仍全局枚举所有有向单元对，复杂度约 `O(N²)`，尚非规模化的真正局部接触搜索。
2. 对已列出的事件候选使用 `softplus` 非零发生率；严格的**当前不可发生**与**当前可发生但没采样到**尚没有完整的状态内在判定区分。
3. 事件调度器使用窗口开始发生率的近似，流动期间发生率变化没有被精确积分；不能据此主张精确连续时间物理模拟。
4. 小规模监督线索实验只检验可训练性，且训练/评估复用同一种线索和局部任务；不等于自动形成记忆、自然语言理解、泛化或节能优势。
5. 外部全局环境输入仍可以影响所有单元，这是显式的环境场；局部线索通过 `local_cues` 分别传达。
6. 即使某个关系未发送消息，其**存在**仍可能改变候选事件集合/事件率。此版本严格分离的是“存在”与“实际消息接触”，不是要求其在任意反事实下完全没有一切间接影响。
7. 运算体系有有限的基础运算语法，无法宣称发现了任意新的数学原语。
