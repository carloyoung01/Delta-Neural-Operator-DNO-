"""Run actual v3 structural, temporal, causal and learning probes.

This is NOT a learned natural-language memory task. All measurement thresholds
below are floating point display tolerances, not internal formation laws.
"""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import copy, json, hashlib, statistics, math, time
import torch
import torch.nn.functional as F
from dno_conditional import EvolvingDNO, ResourceBoundary, _Proposal
from tests.test_v3 import make, remove_edges

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
torch.set_num_threads(1)


def measure_persistence(seeds=32,steps=60):
    samples=[]
    with torch.no_grad():
        for seed in range(seeds):
            m,s=make(100+seed)
            no=remove_edges(s)
            original_rel=s.relations.clone()
            original_law=s.relation_laws.clone()
            for tick in range(steps):
                cue={s.unit_ids[2]:torch.sin(torch.arange(1,m.d+1)*.09*(tick+1))}
                s=m._flow(s,torch.zeros(m.d),.045,local_cues=cue)
                no=m._flow(no,torch.zeros(m.d),.045,local_cues=cue)
            samples.append(dict(seed=seed, edges=len(s.edges),unit_isolation_l2=float((s.units-no.units).norm()),
                relation_changed_l2=float((s.relations-original_rel).norm()),
                law_changed_l2=float((s.relation_laws-original_law).norm()),
                time=float(s.physical_time),finite=bool(torch.isfinite(s.units).all()
                and torch.isfinite(s.relations).all())))
    return {'seed_count':seeds,'steps':steps,'per_seed':samples,
        'relation_preserved':sum(x['edges']==1 for x in samples),
        'isolation_exact':sum(x['unit_isolation_l2']==0 for x in samples),
        'relation_changed':sum(x['relation_changed_l2']>1e-8 for x in samples),
        'law_changed':sum(x['law_changed_l2']>1e-8 for x in samples)}


def measure_intervention(seeds=32):
    samples=[]
    with torch.no_grad():
        for seed in range(seeds):
            m,s=make(500+seed)
            x=torch.sin(torch.arange(1,m.d+1)*(.17+seed*.01))
            s0=s.clone()
            s1,_=m._apply_event(s,_Proposal(7,edge=0),x,False)
            now=float((s1.units-s0.units).norm())
            relation_now=float((s1.relations-s0.relations).norm())
            for _ in range(15):
                s0=m._flow(s0,torch.zeros(m.d),.06)
                s1=m._flow(s1,torch.zeros(m.d),.06)
            future=float((s1.units-s0.units).norm())
            output=float((m._readout(s1,torch.zeros(m.d))-
                          m._readout(s0,torch.zeros(m.d))).norm())
            samples.append(dict(seed=seed,contact_immediate_unit_l2=now,
                contact_immediate_relation_l2=relation_now,
                future_unit_l2=future,future_output_l2=output))
    return {'seed_count':seeds,'per_seed':samples,
        'contact_caused_unit_difference':sum(x['contact_immediate_unit_l2']>1e-7 for x in samples),
        'contact_caused_relation_difference':sum(x['contact_immediate_relation_l2']>1e-7 for x in samples),
        'difference_persisted_in_future':sum(x['future_unit_l2']>1e-7 for x in samples),
        'changed_future_output':sum(x['future_output_l2']>1e-8 for x in samples)}


def measure_natural_events(seeds=96):
    no_contact_before=0
    rel_alive_after_first=0
    after_contact=0
    no_contact_then_contact=0
    all_event_hist={}
    sample=[]
    for seed in range(seeds):
        m,s=make(1200+seed,budget=ResourceBoundary(max_units=3,max_relations=1,
                                                    max_operators=4,max_events_per_advance=10))
        x=torch.zeros(m.d)
        cue={s.unit_ids[0]:torch.cos(torch.arange(1,m.d+1)*.37)}
        torch.manual_seed(50000+seed)
        with torch.no_grad():
            first=m.advance(s,duration=.04,stochastic=True)
            second=m.advance(first.state,duration=.35,stochastic=True,local_cues=cue)
        no_before=first.interaction_events==0
        no_contact_before+=int(no_before)
        rel_alive_after_first+=int(len(first.state.edges)>0)
        contact=second.interaction_events>0
        after_contact+=int(contact)
        no_contact_then_contact+=int(no_before and contact and len(first.state.edges)>0)
        for kind in first.event_kinds+second.event_kinds:
            all_event_hist[kind]=all_event_hist.get(kind,0)+1
        sample.append({'seed':seed,'pre_events':first.events_executed,
            'pre_contacts':first.interaction_events,'pre_edges':len(first.state.edges),
            'cue_events':second.events_executed,'cue_contacts':second.interaction_events,
            'post_edges':len(second.state.edges),'truncated':first.truncated or second.truncated})
    return {'seeds':seeds,'first_window':.04,'second_window':.35,
        'no_contact_in_first':no_contact_before,'edge_alive_after_first':rel_alive_after_first,
        'any_contact_in_second':after_contact,
        'no_contact_then_contact_with_retained_edge':no_contact_then_contact,
        'event_histogram':all_event_hist,'per_seed':sample,
        'note':'A local cue is present in second window, but these untrained trials do NOT isolate cue causality.'}


def cue_learning(steps=120,seed=2026):
    # EXTERNAL supervised engineering diagnostic, not a built-in drive:
    # can the SAME shared scorer learn that an endpoint-local cue predicts
    # participation, but identical content at unrelated unit does not?
    rb=ResourceBoundary(max_units=3,max_relations=1,max_operators=4,max_events_per_advance=1)
    m,s=make(seed,budget=rb)
    s=s.detach()
    cue=torch.sin(torch.arange(1,m.d+1)*.53).detach()
    pos={s.unit_ids[0]:cue}; neg={s.unit_ids[2]:cue}
    x=torch.zeros(m.d)
    proposals=m._proposals(s,rb)
    contact_index=next(i for i,p in enumerate(proposals) if p.kind==7)
    window=.11
    def rates_and_prob(cues,current_state=None):
        rates=m._event_rates(s if current_state is None else current_state,
                             x,proposals,cues)
        total=rates.sum()
        share=rates[contact_index]/total
        # Prob[first event is contact within this finite time window]
        # under the SAME piecewise constant hazard approximation as advance.
        probability=share*(-torch.expm1(-total*window))
        return rates,share,probability
    def evaluate(current_state=None):
        with torch.no_grad():
            p,ps,pp=rates_and_prob(pos,current_state)
            n,ns,np=rates_and_prob(neg,current_state)
            return {'endpoint_rate':float(p[contact_index]),
                    'unrelated_rate':float(n[contact_index]),
                    'endpoint_contact_share':float(ps),
                    'unrelated_contact_share':float(ns),
                    'endpoint_all_rate':float(p.sum()),
                    'unrelated_all_rate':float(n.sum()),
                    'endpoint_contact_probability_in_window':float(pp),
                    'unrelated_contact_probability_in_window':float(np)}
    before=evaluate()
    optim=torch.optim.Adam(list(m.hazard.parameters())+
                           list(m.event_type.parameters()),lr=.012)
    curve=[]
    for step in range(steps):
        optim.zero_grad()
        _,_,p_pos=rates_and_prob(pos)
        _,_,p_neg=rates_and_prob(neg)
        # Proper time-window event likelihood includes SURVIVAL (no event).
        # A high conditional event *share* alone is not enough if its
        # total hazard goes to zero. This is an artificial supervised task.
        loss=-torch.log(p_pos+1e-10)-torch.log(1-p_neg+1e-10)
        loss.backward()
        optim.step()
        if step in (0,19,49,steps-1):
            curve.append({'update':step+1,'rates':evaluate(),
                          'loss':float(loss.detach())})
    after=evaluate()
    # Delayed-state test: relationship persists through OTHER dynamics without
    # any contact events, and the SAME learned scorer faces a changed present.
    # This is unseen temporal context, not a replay of earlier inputs.
    with torch.no_grad():
        aged=s
        for _ in range(50):
            aged=m._flow(aged,x,.05)
    after_aged=evaluate(aged)
    def stochastic_sample(cues,current_state=None):
        # First-event sampling under shared scheduler; the one-event resource
        # boundary is a test harness STOP, not a rule selecting interactions.
        contacts=0;any_events=0;truncated=0
        with torch.no_grad():
            for trial in range(120):
                torch.manual_seed(800000+trial)
                r=m.advance(s if current_state is None else current_state,
                            duration=.11,stochastic=True,
                            local_cues=cues,resources=rb)
                contacts+=int(r.interaction_events>0)
                any_events+=int(r.events_executed>0)
                truncated+=int(r.truncated)
        return {'trials':120,'relation_contact_trials':contacts,
                'any_event_trials':any_events,'truncated_trials':truncated}
    return {'task':'artificial supervised local-cue discrimination, not spontaneous memory or language generalization',
        'seed':seed,'updates':steps,'rates_before':before,'rates_after':after,
        'rates_after_50_intrinsic_steps':after_aged,
        'curve':curve,'stochastic_endpoint':stochastic_sample(pos),
        'stochastic_unrelated':stochastic_sample(neg),
        'aged_endpoint':stochastic_sample(pos,aged),
        'aged_unrelated':stochastic_sample(neg,aged),
        'warning':'One training state and one cue per seed; temporal shift is uncontrolled test, not a language generalization test.'}


def long_run(seeds=8, steps=150):
    records=[]
    for seed in range(seeds):
        rb=ResourceBoundary(max_units=6,max_relations=12,max_operators=9,
                            max_events_per_advance=12)
        m,s=make(3000+seed,budget=rb)
        contacts=0; events=0; idle=0; truncated=0; max_edges=0
        torch.manual_seed(22222+seed)
        with torch.no_grad():
            for k in range(steps):
                local={s.unit_ids[0]:torch.sin(torch.arange(1,m.d+1)*.11*k)} if s.unit_ids and k%7==0 else None
                r=m.advance(s,duration=.025,stochastic=True,local_cues=local)
                s=r.state
                events+=r.events_executed;contacts+=r.interaction_events
                idle+=int(r.interaction_events==0)
                truncated+=int(r.truncated)
                max_edges=max(max_edges,len(s.edges))
                all_tensors=(s.units,s.boundaries,s.unit_laws,s.unit_times,
                             s.relations,s.relation_laws,s.relation_times,
                             s.op_states,s.op_laws)
                if not all(torch.isfinite(t).all() for t in all_tensors):
                    raise AssertionError(f'nonfinite state in seed={seed}, step={k}')
                if len(set(s.unit_ids)) != len(s.unit_ids):
                    raise AssertionError('duplicate persistent ID')
                if len(s.unit_ids)!=s.units.size(0) or len(s.edges)!=len(s.edge_operators):
                    raise AssertionError('structural state inconsistent')
                if any(i<0 or j<0 or i>=s.units.size(0) or j>=s.units.size(0)
                       for i,j in s.edges):
                    raise AssertionError('dangling edge')
                if any(i<0 or i>=len(s.operators) for i in s.edge_operators):
                    raise AssertionError('dangling operator reference')
        records.append({'seed':seed,'steps':steps,'total_events':events,
            'total_interactions':contacts,'windows_without_contact':idle,
            'truncated_windows':truncated,'final_counts':s.counts,'max_edges':max_edges,
            'physical_time':s.physical_time})
    return {'runs':seeds,'windows_per_run':steps,'records':records,
        'all_finite':True,'total_contact_events':sum(r['total_interactions'] for r in records),
        'total_nonparticipation_windows':sum(r['windows_without_contact'] for r in records)}


def main():
    started=time.perf_counter()
    report={'implementation':'Delta DNO v3 conditional participation',
            'torch_version':torch.__version__,
            'scope':'actual CPU tests, small untrained systems plus one explicitly supervised cue diagnostic',
            'persistent_intrinsic_evolution':measure_persistence(),
            'contact_counterfactual':measure_intervention(),
            'stochastic_event_sequences':measure_natural_events(),
            'cue_conditioned_hazard_learning':cue_learning(),
            'cue_replications':[cue_learning(seed=2027),cue_learning(seed=2028)],
            'long_run':long_run()}
    report['elapsed_seconds']=round(time.perf_counter()-started,3)
    target=OUT/'FULL_RESULTS.json'
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    sections=('persistent_intrinsic_evolution','contact_counterfactual',
              'stochastic_event_sequences','cue_conditioned_hazard_learning','long_run')
    summary={k:{key:value for key,value in report[k].items() if key not in ('per_seed','records','curve')}
             for k in sections}
    summary['cue_replications']=[{'seed':r['seed'],
        'rates_before':r['rates_before'], 'rates_after':r['rates_after'],
        'rates_after_50_intrinsic_steps':r['rates_after_50_intrinsic_steps'],
        'stochastic_endpoint':r['stochastic_endpoint'],
        'stochastic_unrelated':r['stochastic_unrelated'],
        'aged_endpoint':r['aged_endpoint'], 'aged_unrelated':r['aged_unrelated']}
        for r in report['cue_replications']]
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('elapsed_seconds:',report['elapsed_seconds'])


if __name__=='__main__':main()
