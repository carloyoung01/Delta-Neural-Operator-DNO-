# Delta DNO 多视角只读分析（暂定研究工具）

这不是新 Delta 版本，不会修改冻结 DNO。仅用于从不同已有状态坐标看问题、记录观察不足、避免把每次解释困难直接等同架构缺陷。

```bash
PYTHONPATH=frozen:. python -m unittest discover -s tests -v
PYTHONPATH=frozen:. pytest -q tests/test_frozen.py
python demo.py
```

- `frozen/dno.py`：原冻结生成器逐字节拷贝，不做修改。
- `multiview_observer.py`：只读观察、坐标巡检、有限未来模型观察、正交坐标不变量检查。
- `demo.py`：完整可复现示例。
- `REPORT_ZH.md`：数学解释、外部研究方法、已有文献、风险与适用条件。
- `evidence/`：逐次测试结果、文件哈希与演示输出。

要求：Python 3.10+、PyTorch、NumPy。结果为观察分析，不是完整因果鉴别或数学完备性证明。
