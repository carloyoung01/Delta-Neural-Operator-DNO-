from dataclasses import replace
import json
import torch
from frozen.dno import DNO
from multiview_observer import compare, snapshot_hash

def run():
    torch.manual_seed(42)
    m=DNO(d=3,hidden=12).eval()
    with torch.no_grad():
        a=m.introduce(m.blank(),torch.tensor([[1.,0.,0.],[0.,1.,0.]]))
        b=replace(a,value=a.value.flip(0))
        c=replace(a,law=a.law+.2)
        reports={}
        for name, other in [('global_hidden',b),('law_hidden',c),('identical',a)]:
            before=snapshot_hash(a,m)
            q=compare(a,other,model=m,views=('global_mean','value','boundary','law','incidence','time','observer','future_value'))
            assert snapshot_hash(a,m)==before
            reports[name]={'status':q.status,'first_view':q.first_distinguishing_view,
                            'trace':[{'name':e.name,'finding':e.finding,'magnitude':e.magnitude,'reason':e.reason} for e in q.trace]}
    return reports

if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,indent=2))
