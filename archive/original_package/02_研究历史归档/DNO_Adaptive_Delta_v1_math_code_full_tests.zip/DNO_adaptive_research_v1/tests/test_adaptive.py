import unittest,sys,torch
from dataclasses import replace
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dno_adaptive import AdaptiveDNO
import torch.nn.functional as F

class TestAdaptive(unittest.TestCase):
 def setUp(self):
  torch.manual_seed(44);torch.set_num_threads(1)
  self.m=AdaptiveDNO(20,d_model=14,d_constraint=5,d_relation=6,
    max_live_units=16,max_live_edges=40,max_operator_nodes=25,
    birth_threshold=.28,compose_threshold=.12,contact_threshold=.25)
 def test_dimensions_grad(self):
  x=torch.tensor([[1,4,9,3,8,12,0,4]])
  y,s=self.m(x,return_state=True)
  self.assertEqual(tuple(y.shape),(1,8,20))
  loss=F.cross_entropy(y[:,:-1].reshape(-1,20),x[:,1:].reshape(-1));loss.backward()
  self.assertTrue(bool(torch.isfinite(y).all()))
  self.assertGreater(sum(float(p.grad.abs().sum()) for p in self.m.parameters() if p.grad is not None),0.)
 def test_causal_prefix(self):
  a=torch.tensor([[1,2,3,4,5]]);b=torch.tensor([[1,2,3,10,11]])
  with torch.no_grad():
   x=self.m(a);y=self.m(b)
  self.assertTrue(torch.allclose(x[:,:3],y[:,:3],atol=1e-5))
 def test_stream_equivalence(self):
  x=torch.tensor([[1,4,6,8,3,2,1]])
  with torch.no_grad():
   a,sa=self.m(x,return_state=True)
   b,sb=self.m(x[:,:3],return_state=True)
   c,sc=self.m(x[:,3:],state=sb,return_state=True)
  self.assertTrue(torch.allclose(a,torch.cat([b,c],1),atol=1e-6))
  self.assertEqual(sa.edges,sc.edges)
 def test_variable_units_edges_ops(self):
  s=self.m.initial_state()
  with torch.no_grad():
   for t in range(40):_,s=self.m.step(t%20,s)
  self.assertGreater(s.h.shape[0],1)
  self.assertEqual(len(s.edges),len(s.edge_ops))
  self.assertEqual(len(s.edges),s.relations.shape[0])
  self.assertGreaterEqual(len(s.programs),4)
  self.assertTrue(all(0<=i<s.h.shape[0] and 0<=j<s.h.shape[0] for i,j in s.edges))
 def test_identity_and_program_intervention(self):
  s=self.m.initial_state()
  with torch.no_grad():
   for t in range(30):_,s=self.m.step(t%20,s)
   base,_=self.m.step(3,s)
   if len(s.edges):
    changed=replace(s,relations=torch.ones_like(s.relations))
    other,_=self.m.step(3,changed)
    self.assertGreater(float((base-other).norm()),1e-7)
   if any(i>=4 for i in s.edge_ops):
    changed=replace(s,edge_ops=tuple(0 for _ in s.edge_ops))
    other,_=self.m.step(3,changed)
    self.assertGreater(float((base-other).norm()),1e-9)
 def test_idle_no_birth(self):
  s=self.m.initial_state()
  with torch.no_grad():
   for _ in range(20):_,s=self.m.step(None,s)
  self.assertEqual(s.births,0)
  self.assertEqual(s.h.shape[0],1)
 def test_unlimited_growth_option(self):
  m=AdaptiveDNO(20,d_model=10,d_constraint=4,d_relation=4,
    max_live_units=None,max_live_edges=None,max_operator_nodes=None,
    birth_threshold=0,contact_threshold=0,compose_threshold=0)
  s=m.initial_state()
  with torch.no_grad():
   for i in range(22):_,s=m.step(i%20,s)
  self.assertGreater(s.h.shape[0],6)
  self.assertGreater(len(s.edges),5)
  self.assertGreater(len(s.programs),4)
 def test_finite_200_steps(self):
  s=self.m.initial_state()
  with torch.no_grad():
   for i in range(200):_,s=self.m.step((i*7)%20 if i%3 else None,s)
  self.assertTrue(bool(torch.isfinite(s.h).all()))
  self.assertTrue(bool(torch.isfinite(s.boundary).all()))
  self.assertTrue(bool(torch.isfinite(s.relations).all()))

if __name__=='__main__':unittest.main()
