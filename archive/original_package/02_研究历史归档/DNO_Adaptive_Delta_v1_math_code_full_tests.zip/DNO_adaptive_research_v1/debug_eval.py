import torch,time,random,faulthandler,os,sys
from experiments import *
faulthandler.dump_traceback_later(12,repeat=True)
torch.set_num_threads(1);torch.manual_seed(2026);random.seed(2026)
m=DNO_model('adaptive');opt=torch.optim.AdamW(m.parameters(),lr=.003,weight_decay=.002)
tr,held=grammar_data();pool=data_pool(tr);ev=data_pool(held);r=random.Random(2103)
start=time.perf_counter()
for i in range(900):
 x=pool[r.randrange(len(pool))].unsqueeze(0)
 opt.zero_grad(set_to_none=True)
 y=m(x[:,:-1]);l=F.cross_entropy(y.reshape(-1,VOCAB),x[:,1:].reshape(-1))
 l.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step()
 if i%100==0:print('train',i,round(time.perf_counter()-start,2),flush=True)
for j,x in enumerate(ev):
 print('eval',j,flush=True)
 with torch.no_grad():
  y,s=m(x.unsqueeze(0)[:,:-1],return_state=True)
  if j%12==0:print('state',m.resources(s),flush=True)
print('done',round(time.perf_counter()-start,2),flush=True)
sys.stdout.flush();os._exit(0)
