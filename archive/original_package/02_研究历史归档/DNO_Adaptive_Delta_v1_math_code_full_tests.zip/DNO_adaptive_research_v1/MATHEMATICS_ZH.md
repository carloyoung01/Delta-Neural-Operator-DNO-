# Delta 与自适应 DNO：数学概念、可执行机制和边界（研究扩展 v1）

> **关键原则：** 本文不更改 `reference_v0/` 的原始数学与代码。Delta 是跨领域的作用—状态概念；本目录的 `AdaptiveDNO` 只是一个有限、可微训练的神经网络工程实例。不得把该实例的阈值、算子列表和资源预算解释成 Delta 的数学公理。

## 一、Delta 不依赖神经网络的概念层

1. **相对独立的有效单元**：存在集合 \(U_t\)，其中每个单元可以在当前条件下独立变化，独立不等于完全隔离。
2. **当前有效状态**：\(\Omega_t=(U_t,R_t,C_t)\) 是过去作用已形成的当下现实；它**不是历史记录**，不要求保留或重放全部事件。
3. **条件性作用**：\(\iota_t\in\operatorname{Enabled}(\Omega_t;\mathcal B,E_t)\)；\(\mathcal B\) 为有限底层规律，\(E_t\) 为当前外界条件。存在合法但未发生的候选作用。
4. **关系成为有效实体**：\(R_t\) 中的关系不是相似度的别名；可具有当前状态并改变未来作用。
5. **约束与边界**：内部约束 \(C_t\) 可以随作用变化；计算预算、执行权限等外部硬界不能被网络任意修改。
6. **自主变化与耦合**：个体可以独立变化，也可以因接触改变；保持、消散与暂停不被预先定义为失败。
7. **关系再作用**：若 \(r,r'\in R_t\)，允许 \(r\) 的作用影响 \(r'\) 未来的有效条件。
8. **状态承载与信息边界**：多段不同过去可能映射到相同 \(\Omega_t\)；有限状态不能保证任意未来查询都无损。
9. **观察与可达性**：当前结构可以改变 \(\operatorname{Reach}_{H}(\Omega_t)\)；需通过反事实干预而非仅用相关性来证明。
10. **有限规律、开放结构**：可生成多样复合结构，不意味着无限计算资源或自动创造不存在的基础数学原语。

综合式（定义性数学记号，不是物理定律证明）：

\[
\boxed{\Omega_{t+1}\in\mathfrak D_{\mathcal B}(\Omega_t,I_t,E_t)}
\]

## 二、由 Delta 导出的具体自适应神经算子

\[
\Omega_t=(H_t,C_t,A_t,\mathcal E_t, Z_t,\mathcal P_t),
\]

- \(H_t\in\mathbb R^{N_t\times d}\)：**数量可变**的有效单元状态。
- \(C_t\in\mathbb R^{N_t\times c}\)：有效局部边界。
- \(A_t\in[0,1]^{N_t}\)：当前活动。
- \(\mathcal E_t\subseteq\{(i,j):i,j<N_t\}\)：**数量可变**的稀疏有向接触集合；不定义每单元固定 \(K\)。
- \(Z_t\in\mathbb R^{|\mathcal E_t|\times r}\)：每条当前关系的状态。
- \(\mathcal P_t\)：当前正在使用的运算 DAG，节点引用其他当前运算节点；不是修改事件日志。

共享神经网络参数为 \(\theta\)（由数据训练）。单次语境的 \(\Omega_t\) 是实际运算中生成的有效状态，二者不能混同。

### 2.1 接触选择不是全量注意力

首先使用当前 \(h_i,c_i\) 的学习索引 \(k_\theta(h_i,c_i)\) 排序，在相邻位置产生候选，再并入已存在关系及有限探索候选：

\[
\mathcal Q_t=\mathcal E_t\cup\operatorname{Adj}(\operatorname{Sort}(k_\theta(H_t,C_t)))\cup\operatorname{Probe}(\Omega_t,t).
\]

新增关系由当下双方状态、边界和当前关系状态决定：
\[
 g_{ij}=\sigma\!\left(f_g(h_i,h_j,c_i,c_j,z_{ij})\right).
\]

基于候选提议选择少量新关系，数量受**运行环境预算**而非每单元固定端口控制。排序和新增/移除决策是离散的，**普通梯度无法穿过这些选择本身**。这是现有实现尚未解决的学习缺口。

### 2.2 输入引发的单元生成

对当前输入表示 \(v_t\)，根据当前状态选择一个相对匹配的单元 \(i^*\)，计算不匹配程度（novelty）与可学习生成门：
\[
\nu_t=1-\max_i\cos(h_i,v_t),\quad
p_b=\sigma(f_b(h_{i^*},v_t,\nu_t)),\quad
b_t=p_b(\nu_t+0.12).
\]

当 \(b_t>\tau_b\) 且外部资源许可时，生成一个新单元：
\[
 h_{N_t}=p_b\tanh(f_{\rm split}(h_{i^*},v_t)),\quad N_{t+1}=N_t+1.
\]

**限制**：这个阈值是一种工程定义；可训练的门参与数值计算，但离散出生动作不是端到端可微，不能据此宣布已学会合理扩容。长期生长、停止、压缩和消散需要更好的状态与资源机制。

### 2.3 个体与关系的局部变化

\[
\delta_i=f_{\rm self}(h_i,c_i),\quad
m_{ij}=g_{ij}f_m(h_i,h_j,c_i,c_j,z_{ij}),
\]

\[
 z'_{ij}=\tanh(0.965z_{ij}+0.075f_r(h_i,h_j,c_i,c_j,z_{ij},\overline z_i,\overline z_j)),
\]

\[
 c'_i=\tanh(0.98c_i+0.07f_c(h_i,c_i,\bar m_i)),
\]

\[
 h'_i=(1-0.24u_i)h_i+0.24u_i\tanh(h_i+0.12\delta_i+0.23\bar m_i).
\]

\(\bar z_i\) 为当前共享端点的关系摘要，形成有限的“关系作用于关系”。小数常量是实验选择，不是普适律。

### 2.4 运算结构组合

存在有限的基础运算 \(\{x,\tanh(x),-x,x^2\}\)。当前条件可把已有运算 DAG 节点通过 `add`、`mul`、`chain` 等复合操作连接成新节点。复合节点**确实用于后续关系消息的数值计算**，不是仅打印新名称。

\[
\mathcal P_{t+1}=\mathcal P_t\cup\{\operatorname{Compose}(p_a,p_b;\kappa)\}
\]

仅在实际触发时新增；不再使用的节点经过可达性裁剪。**这意味着生成了新的组合表达式，而非新的基础数学运算原语**。离散结构选择采用阈值和 argmax，尚不具备任意新运算生成的端到端训练能力。

### 2.5 语言任务与训练

\[
 p_\theta(x_{t+1}\mid x_{\le t})=\operatorname{softmax}(W_o\,\operatorname{Readout}(\Omega_{t+1})),\quad
\mathcal L=-\sum_t\log p_\theta(x_{t+1}\mid x_{\le t}).
\]

预测目标只在训练时用来改变共享参数。它不是 Delta 所有局部变化的强制成功方向。实际计算只依赖**当前有效状态**，推理不要求重放过往所有 Token；训练 BPTT 需要保存展开计算图。

## 三、计算资源与明确边界

- 当前演化单元为 \(N_t\)，有效关系为 \(E_t=|\mathcal E_t|\)，复合运算图当前节点数为 \(P_t\)。不再强制 \(N_t=N\) 或每单元 \(K=5\)。
- 发现候选利用排序（大致 \(O(N_t\log N_t)\)）与稀疏边集合，在候选之外无法保证发现一切潜在作用。
- CPU 原型在 Python 中执行离散分配、排序与关系集合更新，尚无 GPU 吞吐、峰值显存或能耗优势证据。
- `None` 资源上限仅表示没有该**预设**数值限制；有限 RAM/计算时间依然是实际物理边界。
- 当前实现没有自动删除单元；弱关系可以被删，但本次稳定性样例没有观察到关系消散事件。必须诚实报告这一不完整性。
- 单元生成和组合运算由可学习门与**人为阈值共同触发**。要证明学会何时生成，还需要训练与反事实实验揭示其适应性。

## 四、实验与文献

完整测试见 `TEST_REPORT_ZH.md`，数值记录见 `results/`。相关文献：

- Evanson et al., *Language acquisition: do children and language models follow similar learning stages?* ACL 2023. https://aclanthology.org/2023.findings-acl.773/
- Biderman et al., *Pythia*, ICML 2023. https://proceedings.mlr.press/v202/biderman23a.html
- Eldan & Li, *TinyStories*, 2023. https://arxiv.org/abs/2305.07759
- Schaeffer et al., *Are Emergent Abilities ... a Mirage?*, NeurIPS 2023. https://proceedings.neurips.cc/paper_files/paper/2023/hash/adc98a266f45005c403b8311ca7e8bd7-Abstract-Conference.html
- Liu et al., *DARTS*, ICLR 2019. https://mlanthology.org/iclr/2019/liu2019iclr-darts/
- Mordvintsev et al., *Growing Neural Cellular Automata*, Distill 2020. https://distill.pub/2020/growing-ca/
- Jia & Zhou, *Self-motivated growing neural network*, Neurocomputing 2026. https://doi.org/10.1016/j.neucom.2026.134581
