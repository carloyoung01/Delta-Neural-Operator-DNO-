# DNO Adaptive Research v1 / DeltaLM 自适应结构实验

本目录是**独立的、可执行的研究扩展**。`reference_v0/` 原样保留 DNO v0；Delta 跨领域数学概念不因本次工程实现而被重新定义。本次实现探索在 LLM 的计算骨干位置上使用**当前有效状态、可增长单元、可变稀疏关系与有限运算结构组合**。

**不能宣称**：已经学会自然语言理解、创造任意新数学原语、具有无限扩张能力、超越 Transformer、节约能耗、形成通用智能。

## 目录

- `dno_adaptive.py`：完整 PyTorch 自适应神经计算骨干；当前参考实现 **batch=1**。
- `experiments.py`：原始受控英语关系问答任务、基线、结构与长时运行测试，`--quick` 已确认可以运行。
- `run_one.py`：隔离训练单一条件（处理沙盒中多组短生命周期动态 autograd 图的退出/回收不稳定）。
- `train_chunks.py`：严格按更新次数保存模型、优化器与采样 RNG 的分段训练；不减少真实优化步骤。
- `eval_chunks.py`：在独立进程评估指定训练节点。
- `eval_structure_checkpoints.py`：相同输入流比较训练前后单元/关系/算子结构及干预。
- `tests/test_adaptive.py`：输入因果性、梯度、状态接续、可变结构、干预、空闲及有界稳定性测试。
- `reference_v0/`：未改动的 DNO v0 源文件、文档与测试。
- `MATHEMATICS_ZH.md`：严格数学层次、运行公式与约束。
- `TEST_REPORT_ZH.md`：实测结果、问题及开放界限。
- `results/`：完整 JSON、原始日志、可视化图、选择性训练检查点。

## 环境

Python 3.10+、PyTorch >= 2.1。实际执行 `torch 2.10.0+cpu`、无 GPU；并非已在所有依赖版本验证。

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python experiments.py --quick
```

完整 350 步条件测试：

```bash
python experiments.py
```

本报告已跑过的 **2500 步**自适应模型，可用可恢复训练方式重做。每一段的 `--start` 必须与之前保存的精确检查点相符：

```bash
python train_chunks.py --kind adaptive --start 0 --end 200
python train_chunks.py --kind adaptive --start 200 --end 400
# 依次推进到 2500；具体检查点见 results/checkpoints/
python eval_chunks.py --kind adaptive --step 2500 --examples 48
```

原始基准 v0 的测试：

```bash
cd reference_v0
python -m unittest discover -s tests -v
```

## 最小 API

```python
from dno_adaptive import AdaptiveDNO
import torch

m = AdaptiveDNO(vocab_size=32, max_live_units=16,
                max_live_edges=64, max_operator_nodes=40)
s = m.initial_state()
for token in [3, 7, 8, 1, 3]:
    logits, s = m.step(token, s)
print(m.resources(s))
# 改为 None 可关闭相应预设容量限制，但可能耗尽实际内存。
```

## 证据限制

目前的数据只有程序生成的英语关系问答句，不是自然语言语料。训练单元增长阈值与运算结构生成阈值尚需更强的机制学习；训练和组合泛化表现总体不如本次小型 Transformer。全部原始负面结果均保留。
