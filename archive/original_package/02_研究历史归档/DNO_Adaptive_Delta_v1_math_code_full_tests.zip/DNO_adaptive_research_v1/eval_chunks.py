"""Evaluate each training checkpoint in a FRESH process.
This avoids training/evaluation cross-run resource interference.
"""
import argparse,torch,json,os,sys
from pathlib import Path
from experiments import DNO_model,SmallGRU,SmallTransformer,grammar_data,data_pool,eval_model,VOCAB
p=argparse.ArgumentParser();p.add_argument('--kind',default='adaptive')
p.add_argument('--seed',type=int,default=2026);p.add_argument('--step',type=int,required=True)
p.add_argument('--examples',type=int,default=96)
a=p.parse_args();torch.set_num_threads(1)
torch.manual_seed(a.seed)
model=SmallGRU(VOCAB) if a.kind=='gru' else SmallTransformer(VOCAB) if a.kind=='transformer' else DNO_model(a.kind)
if a.step:
 ckpt=Path(__file__).parent/'results'/'checkpoints'/f'{a.kind}_{a.seed}_{a.step}.pt'
 data=torch.load(ckpt,map_location='cpu',weights_only=True)
 model.load_state_dict(data['model'])
tr,held=grammar_data();pool=data_pool(held)
r=eval_model(model,pool,a.examples)
r.update({'kind':a.kind,'seed':a.seed,'step':a.step})
q=Path(__file__).parent/'results'/f'eval_{a.kind}_{a.seed}_{a.step}.json'
q.write_text(json.dumps(r,indent=2))
print(json.dumps(r),flush=True);sys.stdout.flush();os._exit(0)
