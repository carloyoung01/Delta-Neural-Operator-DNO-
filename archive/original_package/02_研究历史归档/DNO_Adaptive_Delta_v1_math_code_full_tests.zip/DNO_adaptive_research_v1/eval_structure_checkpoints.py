"""Fixed-stream structural observations at trained checkpoints.
No event log is inserted into model state; trajectories recorded externally.
"""
from dataclasses import replace
from pathlib import Path
import torch,json,math
from experiments import DNO_model,grammar_data,data_pool
from dno_adaptive import AdaptiveDNO
P=Path(__file__).parent/'results';torch.set_num_threads(1)
records=[]
tr,held=grammar_data();pool=data_pool(held)
stream=[int(x) for row in pool[::11][:10] for x in row][:100]
for step in (0,200,400,600,800,1000,1250,1500,2000,2500):
 torch.manual_seed(2026)
 m=DNO_model();m.eval()
 if step:
  data=torch.load(P/'checkpoints'/f'adaptive_2026_{step}.pt',weights_only=True,map_location='cpu')
  m.load_state_dict(data['model'])
 s=m.initial_state();points=[];births=[];ops=[]
 with torch.no_grad():
  for i,token in enumerate(stream):
   _,ns,diag=m.step(token,s,diagnostics=True)
   if ns.births>s.births:births.append(i+1)
   if ns.compositions>s.compositions:ops.append(i+1)
   s=ns
   if i in (0,9,29,59,99):points.append({'step':i+1,**m.resources(s)})
  # Current-state intervention: same state, same input, replace existing operator
  # assignments, then inspect the *next predicted logits*.
  base,_=m.step(5,s)
  if s.edge_ops:
   c=replace(s,edge_ops=tuple(0 for _ in s.edge_ops))
   alternative,_=m.step(5,c)
   l2_op=float((base-alternative).norm())
   c=replace(s,relations=torch.zeros_like(s.relations))
   alt2,_=m.step(5,c)
   l2_rel=float((base-alt2).norm())
  else:l2_op=None;l2_rel=None
 records.append({'trained_steps':step,'current':m.resources(s),'trajectory':points,
                 'birth_steps_in_fixed_stream':births,'new_op_steps_in_fixed_stream':ops,
                 'operator_intervention_l2':l2_op,'relation_intervention_l2':l2_rel})
 print('STRUCT',step,'final',m.resources(s),'op_l2',l2_op,flush=True)
(P/'structural_across_training.json').write_text(json.dumps(records,indent=2))
