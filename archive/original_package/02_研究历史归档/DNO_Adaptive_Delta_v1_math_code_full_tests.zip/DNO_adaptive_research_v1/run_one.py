"""Run a training condition in an isolated process to avoid cross-run memory interference."""
import argparse,json,torch
from pathlib import Path
from experiments import train,threshold_events,OUT
p=argparse.ArgumentParser()
p.add_argument('--kind',default='adaptive');p.add_argument('--seed',type=int,default=2026)
p.add_argument('--steps',type=int,default=350);p.add_argument('--eval-count',type=int,default=32)
a=p.parse_args()
torch.set_num_threads(1)
model,rec=train(a.kind,a.seed,a.steps,eval_count=a.eval_count,
        eval_steps=sorted(({0,25,50,100,175,250,350,500,750,1000,1500,2000,3000,a.steps//2,a.steps}) & set(range(a.steps+1))))
rec['thresholds']=[threshold_events(rec['curve'],x) for x in (.25,.5,.75)]
OUT.mkdir(exist_ok=True)
q=OUT/f'curve_{a.kind}_{a.seed}_{a.steps}.json'
q.write_text(json.dumps(rec,indent=2,ensure_ascii=False))
print(json.dumps({'file':str(q),'kind':a.kind,'seed':a.seed,'time':rec['train_time_s'],
 'final':rec['curve'][-1], 'thresholds':rec['thresholds']},ensure_ascii=False),flush=True)
# The sandbox may stall during PyTorch GC/interpreter teardown with many
# short-lived ragged autograd graphs. All results are saved above.
import os
os._exit(0)
