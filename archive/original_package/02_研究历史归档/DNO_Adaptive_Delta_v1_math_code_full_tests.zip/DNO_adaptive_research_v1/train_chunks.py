"""Checkpointed training, separating runs at exact update steps.
Unlike a single long Python run, each chunk ends with an atomic saved checkpoint.
"""
import argparse,random,os,sys,time
from pathlib import Path
import torch
import torch.nn.functional as F
from experiments import DNO_model,SmallGRU,SmallTransformer,grammar_data,data_pool,VOCAB

p=argparse.ArgumentParser();p.add_argument('--kind',default='adaptive')
p.add_argument('--seed',type=int,default=2026)
p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,required=True)
a=p.parse_args()
torch.set_num_threads(1)
if a.start>=a.end:raise ValueError('end must exceed start')
model = SmallGRU(VOCAB) if a.kind=='gru' else SmallTransformer(VOCAB) if a.kind=='transformer' else DNO_model(a.kind)
opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.002)
rng=random.Random(a.seed+77)
res=Path(__file__).parent/'results'/'checkpoints';res.mkdir(exist_ok=True)
if a.start:
 q=res/f'{a.kind}_{a.seed}_{a.start}.pt'
 r=torch.load(q,map_location='cpu',weights_only=True)
 model.load_state_dict(r['model']);opt.load_state_dict(r['optimizer']);rng.setstate(r['rng'])
else:
 torch.manual_seed(a.seed)
 # Recreate after seed for exact initial RNG matching.
 model = SmallGRU(VOCAB) if a.kind=='gru' else SmallTransformer(VOCAB) if a.kind=='transformer' else DNO_model(a.kind)
 opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.002)
tr,held=grammar_data();pool=data_pool(tr)
t=time.perf_counter()
for i in range(a.start,a.end):
 x=pool[rng.randrange(len(pool))].unsqueeze(0)
 opt.zero_grad(set_to_none=True)
 y=model(x[:,:-1]);loss=F.cross_entropy(y.reshape(-1,VOCAB),x[:,1:].reshape(-1))
 loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
 if (i+1)%100==0:print('training',a.kind,'step',i+1,'loss',round(float(loss.detach()),4),'seconds',round(time.perf_counter()-t,2),flush=True)
q=res/f'{a.kind}_{a.seed}_{a.end}.pt';tmp=q.with_suffix('.tmp')
torch.save({'model':model.state_dict(),'optimizer':opt.state_dict(),'rng':rng.getstate(),
            'kind':a.kind,'seed':a.seed,'step':a.end},tmp)
os.replace(tmp,q)
print('SAVED',q,flush=True)
sys.stdout.flush();os._exit(0)
