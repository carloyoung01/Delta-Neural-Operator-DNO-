from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent;out=p/'results'
reads={}
for kind in ['adaptive','no_growth','no_composition','gru','transformer']:
  files=sorted(out.glob(f'curve_{kind}_2026_*.json'))
  if files:
   files.sort(key=lambda z:int(z.stem.split('_')[-1])); reads[kind]=json.loads(files[-1].read_text())
adapt_points=[]
for z in sorted(out.glob('eval_adaptive_2026_*.json')):
 d=json.loads(z.read_text());adapt_points.append(d)
adapt_points.sort(key=lambda x:x['step'])
tr=reads['transformer'];gru=reads['gru']
struct=json.loads((out/'structural_budgets.json').read_text())
longrun=json.loads((out/'long_run.json').read_text())
evolving=json.loads((out/'structural_across_training.json').read_text())

plt.figure(figsize=(9,5.2))
plt.plot([r['step'] for r in adapt_points],[r['answer_acc'] for r in adapt_points],'-o',label='Adaptive DNO')
plt.plot([r['step'] for r in tr['curve']],[r['answer_acc'] for r in tr['curve']],'-s',label='Small Transformer')
plt.plot([r['step'] for r in gru['curve']],[r['answer_acc'] for r in gru['curve']],'-^',label='Small GRU')
plt.axhline(.125,linestyle=':',color='gray',label='Uniform 8-name guess (12.5%)')
plt.xlabel('Training updates');plt.ylabel('Held-out relational answer accuracy');plt.ylim(-.03,1.05)
plt.title('Checkpoint behavior on controlled English relation QA')
plt.legend();plt.grid(alpha=.2);plt.tight_layout();plt.savefig(out/'checkpoint_answer_accuracy.png',dpi=170);plt.close()

plt.figure(figsize=(9,5.2))
plt.plot([r['step'] for r in adapt_points],[r['loss'] for r in adapt_points],'-o',label='Adaptive DNO')
plt.plot([r['step'] for r in tr['curve']],[r['loss'] for r in tr['curve']],'-s',label='Small Transformer')
plt.plot([r['step'] for r in gru['curve']],[r['loss'] for r in gru['curve']],'-^',label='Small GRU')
plt.xlabel('Training updates');plt.ylabel('Held-out next-token cross entropy')
plt.title('Lower loss does not necessarily imply relational QA success')
plt.legend();plt.grid(alpha=.2);plt.tight_layout();plt.savefig(out/'checkpoint_loss.png',dpi=170);plt.close()

labels=list(struct);keys=['active_units','active_edges','operator_nodes']
fig,ax=plt.subplots(figsize=(9,5))
x=list(range(len(labels)))
for j,k in enumerate(keys):
 ax.bar([xx+(j-1)*.23 for xx in x],[struct[z]['final'][k] for z in labels],width=.22,label=k)
ax.set_xticks(x,labels);ax.set_ylabel('Current objects');ax.set_title('Variable-size effective structures under different runtime budgets')
ax.legend();plt.tight_layout();plt.savefig(out/'variable_structure_budgets.png',dpi=170);plt.close()

report={
 'nature':'controlled synthetic-English QA, NOT natural language understanding',
 'hardware':'CPU, PyTorch 2.10.0+cpu',
 'param_count':{k:v['parameters'] for k,v in reads.items()},
 'training_2500':{'adaptive':adapt_points[-1],
   'transformer':tr['curve'][-1],
   'gru':gru['curve'][-1]},
 'ablations_1000':{
  k:json.loads((out/f'eval_{k}_2026_1000.json').read_text())
  for k in ['no_growth','no_composition']},
 'all_DNO_checkpoint_evals':adapt_points,
 'all_Transformer_checkpoints':tr['curve'],
 'all_GRU_checkpoints':gru['curve'],
 'structural_experiments':struct,
 'structural_across_learning':evolving,
 'longrun':longrun,
 'test_suites':{'adaptive':'8/8','original_v0':'8/8'},
 'claims_not_supported':['real language understanding','arbitrary new primitive','learned optimal growth policy',
  'superiority over Transformer','constant memory for arbitrary histories','energy saving','infinite-time stability']
}
(out/'AGGREGATED_RESULTS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print('aggregate generated',len(adapt_points),'checkpoint DNO', len(tr['curve']),'Transformer')
