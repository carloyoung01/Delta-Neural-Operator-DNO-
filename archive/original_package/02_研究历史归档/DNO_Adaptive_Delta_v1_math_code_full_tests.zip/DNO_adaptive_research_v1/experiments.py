"""DNO v1 controlled checkpoint study; no real-world language-understanding claim.
CPU-only, seeded, honest synthetic English relational syntax test.
"""
from __future__ import annotations
import argparse, json, random, math, time, sys
from pathlib import Path
from dataclasses import replace
import torch
from torch import nn
import torch.nn.functional as F
from dno_adaptive import AdaptiveDNO,parameter_count

OUT=Path(__file__).parent/'results'
NAMES=('alice','bob','clara','david','emma','felix','grace','henry')
VERBS=('helped','followed','called','visited')
WORDLIST=['<start>','<end>','.','?','who','whom','did',*NAMES,*VERBS]
TO_ID={s:i for i,s in enumerate(WORDLIST)}
VOCAB=len(WORDLIST)


def grammar_data():
    # Deterministic split by pair, not by duplicate sentences. Held-out
    # directed pairs (a,b) never trained in any verb/query variant.
    pairs=[(a,b) for a in NAMES for b in NAMES if a!=b]
    r=random.Random(193)
    r.shuffle(pairs)
    held=set(pairs[:12]); train=set(pairs[12:]);return train,held


def seq(a,b,verb,which):
    if which=='subject':
        words=['<start>',a,verb,b,'.','who',verb,b,'?',a,'<end>']
    elif which=='object':
        words=['<start>',a,verb,b,'.','whom','did',a,verb,'?',b,'<end>']
    else:raise ValueError(which)
    return torch.tensor([TO_ID[t] for t in words],dtype=torch.long)


def data_pool(pairs):
    return [seq(a,b,verb,k) for a,b in sorted(pairs) for verb in VERBS for k in ('subject','object')]


class SmallGRU(nn.Module):
    def __init__(self,vocab,hidden=22):
        super().__init__();self.embed=nn.Embedding(vocab,hidden)
        self.gru=nn.GRU(hidden,hidden,batch_first=True)
        self.read=nn.Linear(hidden,vocab)
    def forward(self,x):
        z,_=self.gru(self.embed(x));return self.read(z)

class SmallTransformer(nn.Module):
    def __init__(self,vocab,hidden=24,heads=2):
        super().__init__();self.emb=nn.Embedding(vocab,hidden)
        self.pos=nn.Embedding(64,hidden)
        enc=nn.TransformerEncoderLayer(d_model=hidden,nhead=heads,dim_feedforward=48,
                dropout=0,batch_first=True,activation='gelu',norm_first=True)
        self.net=nn.TransformerEncoder(enc,num_layers=1,enable_nested_tensor=False)
        self.ln=nn.LayerNorm(hidden);self.read=nn.Linear(hidden,vocab)
    def forward(self,x):
        t=x.shape[1];z=self.emb(x)+self.pos(torch.arange(t,device=x.device))[None]
        mask=torch.triu(torch.ones(t,t,device=x.device,dtype=torch.bool),diagonal=1)
        return self.read(self.ln(self.net(z,mask=mask)))


def DNO_model(kind='adaptive'):
    args=dict(vocab_size=VOCAB,d_model=18,d_constraint=6,d_relation=6,
              max_live_units=12,max_live_edges=30,max_operator_nodes=22,max_program_depth=7,
              birth_threshold=.38,contact_threshold=.35,compose_threshold=.17)
    if kind=='no_growth':args['grow_units']=False
    if kind=='no_composition':args['compose_ops']=False
    if kind=='no_relation_to_relation':args['relation_to_relation']=False
    if kind=='fixed_contacts':args['evolve_contacts']=False
    return AdaptiveDNO(**args)


def eval_model(m,pool,limit=28):
    m.eval();total=0;sumloss=0.;target_ok=0;mean_entropy=0.
    with torch.no_grad():
        for tokens in ([pool[min(len(pool)-1,int((i+.5)*len(pool)/limit))] for i in range(limit)] if limit<len(pool) else pool):
            x=tokens.unsqueeze(0)
            logits=m(x[:,:-1]) if not isinstance(m,AdaptiveDNO) else m(x[:,:-1])
            ce=F.cross_entropy(logits.reshape(-1,VOCAB),x[:,1:].reshape(-1),reduction='mean')
            sumloss+=float(ce)
            target_pos=(tokens==TO_ID['?']).nonzero().flatten().item()
            pred=logits[0,target_pos].argmax().item()
            target_ok+=int(pred==int(tokens[target_pos+1]))
            mean_entropy+=float(torch.distributions.Categorical(logits=logits[0,target_pos]).entropy())
            total+=1
    m.train();return {'loss':round(sumloss/total,5),'answer_acc':round(target_ok/total,5),
                        'answer_entropy':round(mean_entropy/total,5),'samples':total}


def train(kind='adaptive',seed=2026,steps=300,eval_steps=None,eval_count=28):
    torch.manual_seed(seed);random.seed(seed)
    model=SmallGRU(VOCAB) if kind=='gru' else SmallTransformer(VOCAB) if kind=='transformer' else DNO_model(kind)
    opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.002)
    tr,held=grammar_data();train_pool=data_pool(tr);test_pool=data_pool(held)
    rng=random.Random(seed+77)
    eval_steps=eval_steps or sorted({0,10,25,50,100,150,200,steps})
    points=[];start=time.perf_counter(); tokens_seen=0
    for i in range(steps+1):
        if i in eval_steps:
            e=eval_model(model,test_pool,eval_count)
            e.update({'step':i,'tokens_seen':tokens_seen,
                      'elapsed_s':round(time.perf_counter()-start,2)})
            points.append(e)
        if i==steps:break
        x=train_pool[rng.randrange(len(train_pool))].unsqueeze(0)
        tokens_seen+=x.shape[1]-1
        opt.zero_grad(set_to_none=True)
        logits=model(x[:,:-1]);loss=F.cross_entropy(logits.reshape(-1,VOCAB),x[:,1:].reshape(-1))
        loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.0);opt.step()
    return model,{'kind':kind,'seed':seed,'steps':steps,'parameters':parameter_count(model),
                  'heldout_pairs':len(held),'training_pairs':len(tr),'curve':points,
                  'train_time_s':round(time.perf_counter()-start,2)}


def threshold_events(curve, threshold):
    # A first crossing is a *probe event*, not evidence of a real phase transition.
    hits=[z['step'] for z in curve if z['answer_acc']>=threshold]
    sustained=None
    for i in range(len(curve)-1):
        if curve[i]['answer_acc']>=threshold and curve[i+1]['answer_acc']>=threshold:
            sustained=curve[i]['step'];break
    return {'threshold':threshold,'first_checkpoint':hits[0] if hits else None,
            'two_consecutive_checkpoints':sustained}


def structural_probes(model=None):
    torch.manual_seed(414)
    # Different budgets are RESOURCE constraints, not the computational rule.
    tracks={}
    for label,cap in [('small',(6,9,8)),('medium',(14,32,24)),
                      ('large',(28,90,55)),('unrestricted',(None,None,None))]:
        torch.manual_seed(414)
        m=AdaptiveDNO(48,d_model=16,d_constraint=5,d_relation=5,
            max_live_units=cap[0],max_live_edges=cap[1],max_operator_nodes=cap[2],
            birth_threshold=.34,contact_threshold=.30,compose_threshold=.13,
            max_program_depth=8)
        m.eval();s=m.initial_state();samples=[];ops_difference=None
        with torch.no_grad():
            for t in range(100 if label!='unrestricted' else 35):
                _,s,d=m.step(int((t*7+t*t//9)%48),s,diagnostics=True)
                if t in (0,4,9,19,34,59,99):
                    samples.append({'step':t+1,**m.resources(s)})
            if len(s.edge_ops)>0 and any(x>=4 for x in s.edge_ops):
                # Structural intervention: same state, same input, change only op assignment.
                alternative=replace(s,edge_ops=tuple(0 for _ in s.edge_ops))
                y1,_=m.step(5,s);y2,_=m.step(5,alternative)
                ops_difference=float((y1-y2).norm())
            # after input stops, independent dynamics still can proceed
            old_b=s.births
            for t in range(90):_,s=m.step(None,s)
            finite=bool(torch.isfinite(s.h).all() and torch.isfinite(s.boundary).all()
                        and torch.isfinite(s.relations).all())
        tracks[label]={'caps':cap,'trajectory':samples,'final':m.resources(s),
                       'operator_counterfactual_l2':ops_difference,
                       'births_during_idle':s.births-old_b,'finite_after_idle':finite}
    return tracks


def long_run_test():
    torch.manual_seed(501)
    m=AdaptiveDNO(40,d_model=14,d_constraint=4,d_relation=5,
      max_live_units=20,max_live_edges=52,max_operator_nodes=40,
      compose_threshold=.13,birth_threshold=.40,contact_threshold=.30)
    s=m.initial_state();points=[];finite=True
    with torch.no_grad():
        for t in range(900):
            x=(t*11+t//17)%40 if t%3 else None
            _,s=m.step(x,s)
            if t%150==149:points.append({'step':t+1,**m.resources(s),
                'norm':round(float(s.h.norm()),5)})
            if not(torch.isfinite(s.h).all() and torch.isfinite(s.boundary).all() and
                   torch.isfinite(s.relations).all()):finite=False;break
    return {'finite':finite,'completed_steps':t+1,'trajectory':points,
      'not_infinite_time_proof':True}


def main():
    """Short reproducibility suite; each training condition is process-isolated.

    Extended 2500-step study uses train_chunks.py + eval_chunks.py to avoid
    memory/GC interference observed with long ragged-graph autograd runs.
    """
    import subprocess
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true')
    args=ap.parse_args()
    torch.set_num_threads(1)
    OUT.mkdir(exist_ok=True)
    tests=[('adaptive',2026,350),('adaptive',2027,350),
           ('no_growth',2026,350),('no_composition',2026,350),
           ('gru',2026,350),('transformer',2026,350)]
    if args.quick:tests=[('adaptive',2026,80),('no_growth',2026,80),('gru',2026,80)]
    runs=[]
    for kind,seed,steps in tests:
        call=[sys.executable,str(Path(__file__).parent/'run_one.py'),
              '--kind',kind,'--seed',str(seed),'--steps',str(steps)]
        proc=subprocess.run(call,check=True,timeout=55,capture_output=True,text=True)
        print(proc.stdout.strip(),flush=True)
        rec=json.loads((OUT/f'curve_{kind}_{seed}_{steps}.json').read_text())
        runs.append(rec)
    struct=structural_probes();longtest=long_run_test()
    result={'dataset':{'type':'synthetic_English_relational_QA',
      'is_real_natural_language_understanding':False,
      'heldout_directed_pairs':12,'train_directed_pairs':44,
      'verbs':len(VERBS),'target_task':'who/whom answer at ? token',
      'chance_conditional_on_8_names':1/len(NAMES)},
      'runs':runs,'structure':struct,'long_run':longtest,
      'hardware':{'device':'CPU','torch':torch.__version__,
       'threads':torch.get_num_threads()}}
    (OUT/'quick_or_full_suite.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print('WROTE',OUT/'quick_or_full_suite.json',flush=True)
    return result

if __name__=='__main__':main()
