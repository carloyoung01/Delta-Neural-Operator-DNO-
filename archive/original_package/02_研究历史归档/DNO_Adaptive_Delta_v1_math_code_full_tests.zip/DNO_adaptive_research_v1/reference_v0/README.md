# DNO — Delta Neural Operator (research v0)

**可运行神经网络算法原型，不是已训练的 LLM，不是 Transformer 的已证实替代品。**

这是从跨领域 Delta 数学概念提取的一个 **有限、可微、流式、无全量 Attention** 的语言建模骨干。它的当前有效状态由独立单元、有限端口关系、可变内部边界、活动程度和当前接触身份组成。没有强制的全局内部优化目标，也没有推理时的过往事件日志。

## 文件说明

| 文件 | 用途 |
|---|---|
| `MATHEMATICS_ZH.md` | Delta 基础概念 1–14，DNO 算法 15–22，公式逐一对应源代码 |
| `dno.py` | 可训练的 PyTorch DNO + `DNOState` + 流式生成接口 |
| `train_toy.py` | 公开、可重做的合成序列学习实验 |
| `ablations.py` | 固定候选/关闭关系再作用的有限消融 |
| `tests/test_dno.py` | 形状、因果性、继续运行、梯度、关系干预、有限稳定性 |
| `results/*.json` | 本次真实运行结果 |
| `TEST_REPORT_ZH.md` | 实际结果、失败或未证明的部分 |

## 安装与运行

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python train_toy.py --steps 300
python ablations.py
```

在 CPU 上执行也可以。所附试验使用 Python 3 与 PyTorch 2.10.0+cpu；`requirements.txt` 声明了较低的支持起点，但并未在所有旧版本上重测。

## 最小使用示例

```python
import torch
from dno import DNO

model = DNO(vocab_size=32, slots=7, d_model=24,
            d_constraint=8, d_relation=8)
ids = torch.tensor([[1, 4, 2, 1, 4, 2]], dtype=torch.long)
logits, state = model(ids, return_state=True)
print(logits.shape)   # [1, 6, 32]
print(state.tick)     # 6

# 当前状态直接用于后续计算，无须重新输入上面 6 个 token。
next_logits, next_state = model(torch.tensor([[3, 4]]), state, return_state=True)
print(next_state.tick) # 8
```

训练时使用 `logits[:, :-1]` 来预测 `tokens[:, 1:]`。`train_toy.py` 采用同一逻辑，但为了评估重复模式，仅从第 4 个 token 开始计算训练损失。

## 学术完整性

- 本实现是**算法设计实例**；Delta 的基本概念不限于该神经网络。
- 固定单元数量（`slots`），关系是动态候选端口与可持续的局部状态；没有证明可以自行无限产生新身份。
- 训练时的自动微分会沿时间展开并保留激活，这不等于推理状态存储过去全部事件。
- `index_key` 参与可微接合门，但决定候选身份的排序本身不可微；不能说完整拓扑学习具有端到端连续梯度。
- 语言骨干尚未经过自然文本、Transformer/Mamba 同预算对照、多随机种子和长上下文验证。
- 外部约束、权限、行动工具不在本算法之内。

## 开源与发布

这是一份当前会话生成的研究原型，不自动授予任何第三方仓库公开许可。正式公开之前请由项目负责人审查、选择合法适用的 LICENSE，并记录版本/运行环境。代码不依赖之前的 `delta_core.py`，所以原有 v37 不受修改。
