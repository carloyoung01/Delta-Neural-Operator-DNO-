"""Predeclared controlled ablations with identical training budget/seed/toy data."""
import json,random,time
from pathlib import Path
import torch
import torch.nn.functional as F
from dno import DNO,parameter_count
from train_toy import data,evaluate


def one_case(seed,steps,contact_mode,relation_mode):
    torch.manual_seed(seed);random.seed(seed)
    model=DNO(13,slots=7,d_model=24,d_constraint=8,d_relation=8,
              dynamic_contacts=contact_mode,relation_to_relation=relation_mode)
    opt=torch.optim.AdamW(model.parameters(),lr=0.003,weight_decay=0.001)
    before=evaluate(model)
    model.train()
    for _ in range(steps):
        x=data(16,12,13)
        logits=model(x[:,:-1])
        loss=F.cross_entropy(logits[:,2:].reshape(-1,13),x[:,3:].reshape(-1))
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    return {'dynamic_contacts':contact_mode,'relation_to_relation':relation_mode,
            'parameters':parameter_count(model),'before':before,'after':evaluate(model)}

if __name__=='__main__':
    torch.set_num_threads(1)
    start=time.perf_counter();steps=300
    results=[one_case(2026,steps,True,True),
             one_case(2026,steps,False,True),
             one_case(2026,steps,True,False)]
    out={'task':'period-3-next-token','seed':2026,'steps_each':steps,
         'same_code_except_ablation':True,'cases':results,'elapsed_seconds':time.perf_counter()-start,
         'interpretation_warning':'One random seed and one synthetic task, not statistical evidence of superiority.'}
    Path('results/ablations.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(out,indent=2,ensure_ascii=False))
