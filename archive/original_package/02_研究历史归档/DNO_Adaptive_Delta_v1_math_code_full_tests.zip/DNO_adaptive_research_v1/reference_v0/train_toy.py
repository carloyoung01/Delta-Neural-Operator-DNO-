"""Controlled synthetic next-token experiment. DOES NOT imply language understanding.

Run: python train_toy.py --steps 100 --out results/toy.json
Trains and tests on different random examples, same deterministic sequence rule.
"""
from __future__ import annotations
import argparse,json,random,time
from pathlib import Path
import torch
import torch.nn.functional as F
from dno import DNO,parameter_count


def data(batch:int,length:int,vocab:int,device:str='cpu'):
    """Periodic 3-seed tokens, random seed per example; next token = token[t-2].

    For t>=3: x[t]=x[t-3]. Tokens in 0..vocab-1.
    """
    seed=torch.randint(0,vocab,(batch,3),device=device)
    return seed.repeat(1,(length+2)//3)[:,:length].contiguous()


def evaluate(model, rng_seed:int=2040, batches:int=8,batch:int=24,length:int=12):
    torch.manual_seed(rng_seed)
    model.eval(); total_loss=0.;total_ok=0;total=0
    with torch.no_grad():
        for _ in range(batches):
            x=data(batch,length,model.vocab_size)
            y=model(x[:,:-1]); true=x[:,1:]
            # Ignore initial part of each sequence where the periodic rule is underdetermined.
            y=y[:,2:]; true=true[:,2:]
            total_loss+=F.cross_entropy(y.reshape(-1,model.vocab_size),true.reshape(-1),reduction='sum').item()
            total_ok+=(y.argmax(-1)==true).sum().item()
            total+=true.numel()
    return {'loss':total_loss/total,'accuracy':total_ok/total}


def run(steps:int=100,seed:int=2026,output:str='results/toy.json',
        batch:int=16,length:int=12,dim:int=24,slots:int=7):
    torch.set_num_threads(1)
    torch.manual_seed(seed);random.seed(seed)
    vocab=13
    model=DNO(vocab,slots=slots,d_model=dim,d_constraint=8,d_relation=8)
    optimizer=torch.optim.AdamW(model.parameters(),lr=0.003,weight_decay=0.001)
    initial=evaluate(model)
    history=[]; t0=time.perf_counter()
    model.train()
    for step in range(1,steps+1):
        x=data(batch,length,vocab)
        logits=model(x[:,:-1])
        loss=F.cross_entropy(logits[:,2:].reshape(-1,vocab),x[:,3:].reshape(-1))
        optimizer.zero_grad();loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
        optimizer.step()
        if step in (1,steps//4,steps//2,3*steps//4,steps):
            history.append({'step':step,'train_loss':round(float(loss.item()),6)})
    elapsed=time.perf_counter()-t0
    trained=evaluate(model)
    obj={'experiment':'period-3-next-token toy prediction',
         'description':'Random three tokens repeated. Validation uses fresh random seeds, same rule. Loss excludes first three tokens.',
         'seed':seed,'train_steps':steps,'batch_size':batch,'seq_length':length,
         'slots':slots,'vocab':vocab,'parameters':parameter_count(model),
         'untrained':initial,'trained':trained,'training_seconds_cpu':elapsed,
         'train_history':history,'note':'No natural-language understanding, no baseline dominance claim; finite random toy task.'}
    p=Path(output);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(obj,indent=2,ensure_ascii=False))
    return obj

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=100)
    p.add_argument('--out',default='results/toy.json');p.add_argument('--seed',type=int,default=2026)
    a=p.parse_args();run(steps=a.steps,seed=a.seed,output=a.out)
