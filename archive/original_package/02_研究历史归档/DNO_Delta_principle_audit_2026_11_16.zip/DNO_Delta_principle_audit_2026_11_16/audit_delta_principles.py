"""Read-only tests of existing v0/v3/v4 and optional v5 strategies.

No DNO source is edited. This is a mathematical audit, not a training proof.
Run: python audit_delta_principles.py
"""
from __future__ import annotations
import os, sys, json, math, statistics, hashlib
from dataclasses import replace
from pathlib import Path
import torch

ROOT = Path('/mnt/data')
OUTPUT = Path(__file__).resolve().parent
for name in ('DNO_research_v0','Delta_DNO_conditional_participation_v3',
             'DNO_v4_exposure_probe','DNO_v5_multi_hypothesis_probe'):
    sys.path.insert(0, str(ROOT / name))
import dno as v0
import dno_conditional as v3
import dno_exposure as v4
import local_discovery as v5

torch.set_num_threads(1)
SEEDS = [11,19,29,41,53,67,79,97]
RESULT = {'environment': {'torch':torch.__version__, 'seeds':SEEDS},'checks':{}}

def entry(name, **data):
    RESULT['checks'][name]=data
    print(f'{name}: {json.dumps(data,ensure_ascii=False,default=str)}',flush=True)

def l2(x): return float(x.detach().norm())

def make(mod, seed, n=3, edges=(), resources=None):
    torch.manual_seed(seed)
    r = resources or mod.ResourceBoundary(max_units=7,max_relations=10,max_operators=12,max_events_per_advance=8)
    m = mod.EvolvingDNO(11,d_model=8,d_boundary=4,d_law=4,
                        d_relation=4,d_operator=4,d_hidden=24,resources=r)
    s = m.initial_state()
    x = torch.zeros(m.d)
    for _ in range(n):
        s=m.introduce_component(s,torch.randn(m.d))
    for i,j in edges:
        s,_=m._apply_event(s,mod._Proposal(2,source=i,target=j),x,False)
    return m,s,x

def remove_all_edges(s):
    return replace(s,edges=(),edge_operators=(),relations=s.relations[:0],
        relation_laws=s.relation_laws[:0],relation_times=s.relation_times[:0],
        relation_tempos=s.relation_tempos[:0])

def pair_proposals(ps):
    return [(int(q.kind),int(q.source),int(q.target)) for q in ps if q.kind in (2,6)]

# P1. Present-state recursion, no external input, local effective law and boundary.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,n=3)
        r1=m._flow(s,x,.15)
        r2=m._flow(r1,x,.15)
        r1_duplicate=m._flow(s.clone(),x,.15)
        altered_b=replace(s,boundaries=s.boundaries+torch.ones_like(s.boundaries)*.8)
        altered_l=replace(s,unit_laws=s.unit_laws+torch.ones_like(s.unit_laws)*.8)
        rb=m._flow(altered_b,x,.15)
        rl=m._flow(altered_l,x,.15)
        rec.append({'seed':seed,'state_change_2steps':l2(r2.units-s.units),
            'repeat_max_abs':float((r1.units-r1_duplicate.units).abs().max()),
            'boundary_effect':l2(rb.units-r1.units),
            'unit_law_effect':l2(rl.units-r1.units),
            'law_self_evolves':l2(r1.unit_laws-s.unit_laws)})
entry('P1_endogenous_recursion_and_effective_law',all_nonzero=all(z['state_change_2steps']>1e-7 and z['boundary_effect']>1e-7 and z['unit_law_effect']>1e-7 for z in rec),
      deterministic=all(z['repeat_max_abs']==0 for z in rec),samples=rec)

# P2. Dormant links evolve, do not transmit until actual interaction.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3,((0,1),))
        dorm=m._flow(s,x,.2)
        deleted=m._flow(remove_all_edges(s),x,.2)
        a,_=m._apply_event(s,v4._Proposal(7,edge=0),x,False)
        rec.append({'seed':seed,'passive_unit_diff':l2(dorm.units-deleted.units),
                    'relation_internal_change':l2(dorm.relations-s.relations),
                    'relation_law_internal_change':l2(dorm.relation_laws-s.relation_laws),
                    'active_contact_unit_increment':l2(a.units-s.units)})
entry('P2_relation_exists_without_participation',all_passive_exact_zero=all(z['passive_unit_diff']==0 for z in rec),
      all_relation_internal_change=all(z['relation_internal_change']>1e-7 for z in rec),
      all_active_contact_has_effect=all(z['active_contact_unit_increment']>1e-7 for z in rec),samples=rec)

# P3. Trace of past interaction lives in effective current state after edge deletion.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3,((0,1),))
        active,_=m._apply_event(s,v4._Proposal(7,edge=0),x,False)
        active,_=m._apply_event(active,v4._Proposal(3,edge=0),x,False)
        passive,_=m._apply_event(s,v4._Proposal(3,edge=0),x,False)
        assert active.edges==passive.edges==()
        active=m._flow(active,x,.3)
        passive=m._flow(passive,x,.3)
        rec.append({'seed':seed,'same_topology':active.edges==passive.edges,
                    'state_history_residual':l2(active.units-passive.units),
                    'readout_residual':l2(m._readout(active,x)-m._readout(passive,x))})
entry('P3_history_as_current_state_after_edge_removed',all_state_residual=all(z['state_history_residual']>1e-7 for z in rec),
      all_output_residual=all(z['readout_residual']>1e-8 for z in rec),samples=rec)

# P4. Path dependence of joint interactions (contact order changes present state).
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3,((0,1),(1,2)))
        ab,_=m._apply_event(s,v4._Proposal(7,edge=0),x,False)
        ab,_=m._apply_event(ab,v4._Proposal(7,edge=1),x,False)
        ba,_=m._apply_event(s,v4._Proposal(7,edge=1),x,False)
        ba,_=m._apply_event(ba,v4._Proposal(7,edge=0),x,False)
        rec.append({'seed':seed,'same_final_topology':ab.edges==ba.edges,
                    'order_unit_difference':l2(ab.units-ba.units),
                    'order_law_difference':l2(ab.unit_laws-ba.unit_laws)})
entry('P4_path_dependent_coupled_interaction',all_noncommutative=all(z['order_unit_difference']>1e-9 for z in rec),samples=rec)

# P5. Static event proposal eligibility not recomputed from mutable boundaries.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3)
        rb=m.resources
        baseline=m._proposals(s,rb,((0,1),))
        h0=m._event_rates(s,x,baseline)
        perturbed=replace(s,boundaries=s.boundaries+10.,unit_laws=s.unit_laws-5.)
        changed=m._proposals(perturbed,rb,((0,1),))
        h1=m._event_rates(perturbed,x,changed)
        pairidx=[i for i,q in enumerate(baseline) if q.kind==2 and (q.source,q.target)==(0,1)]
        assert len(pairidx)==1
        k=pairidx[0]
        rec.append({'seed':seed,'proposal_identity_same':[(q.kind,q.source,q.target,q.edge) for q in baseline]==[(q.kind,q.source,q.target,q.edge) for q in changed],
                    'rate_before':float(h0[k]),'rate_after':float(h1[k]),
                    'all_candidate_rates_positive':bool(torch.all(h0>0) and torch.all(h1>0)),
                    'rate_shift':abs(float(h0[k]-h1[k]))})
entry('P5_boundary_modulates_rate_but_not_reachability',all_candidates_same=all(z['proposal_identity_same'] for z in rec),
      all_rates_strict_positive=all(z['all_candidate_rates_positive'] for z in rec),
      changed_rate_count=sum(z['rate_shift']>1e-9 for z in rec),samples=rec)

# P6. Initial contact opportunities vs the environment / application contract.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3)
        no=m._proposals(s,m.resources)
        changed=m._proposals(m._flow(s,x,1.0),m.resources)
        yes=m._proposals(s,m.resources,((0,1),))
        narrowed=v5.OptionalRestriction(frozenset({0,2}))(s,{(0,1),(0,2)})
        rec.append({'seed':seed,
                    'pair_candidates_unexposed':len(pair_proposals(no)),
                    'pair_candidates_after_state_only_flow':len(pair_proposals(changed)),
                    'pair_candidates_exposed':len(pair_proposals(yes)),
                    'optional_app_restriction':sorted(list(narrowed)),
                    'autonomous_nonpair_candidates':len(no)})
entry('P6_contact_exposure_is_optional_external_contract',all_unexposed_empty=all(z['pair_candidates_unexposed']==0 for z in rec),
      all_state_only_still_empty=all(z['pair_candidates_after_state_only_flow']==0 for z in rec),
      all_exposed_available=all(z['pair_candidates_exposed']==2 for z in rec),samples=rec)

# P7. Low-level built-in event kinds can remain possible without any external exposure.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3)
        qs=m._proposals(s,m.resources)
        rs=m._event_rates(s,x,qs)
        release_rates=[float(rs[i]) for i,q in enumerate(qs) if q.kind==1]
        rec.append({'seed':seed,'number_release_candidates':len(release_rates),
                    'min_release_rate':min(release_rates),
                    'release_rate_sum':sum(release_rates),
                    'has_exact_zero_release':any(r==0 for r in release_rates)})
entry('P7_builtin_release_has_positive_rate_without_external_cue',all_release_positive=all(z['min_release_rate']>0 for z in rec),samples=rec)

# P8. Count-driven total event intensity from candidate enumeration under constant hazard.
# This is controlled *in-memory modification* of the hazard network for proof of count effect,
# not an edit to any DNO source nor a trained result.
pressure=[]
with torch.no_grad():
    for mod,label in ((v3,'v3_global'),(v4,'v4_exposure')):
        for n in (3,6,12):
            m,s,x=make(mod,19,n=0,resources=mod.ResourceBoundary(max_units=20,max_relations=100,max_operators=12))
            for _ in range(n):
                s=m.introduce_component(s,torch.randn(m.d))
            for p in m.hazard.parameters(): p.zero_()
            ps=m._proposals(s,m.resources)
            rates=m._event_rates(s,x,ps)
            pressure.append({'version':label,'N':n,'candidate_total':len(ps),
                'pair_candidate_count':len(pair_proposals(ps)),
                'total_intensity':float(rates.sum()),
                'mean_event_wait':1./float(rates.sum())})
entry('P8_candidate_count_induces_event_frequency',controlled_zero_hazard_parameters=True,samples=pressure)

# P9. Exposed positional index can silently point at a different identity after deletion.
with torch.no_grad():
    m,s,x=make(v4,101,3)
    initial_ids=s.unit_ids
    intended_pair_ids=(s.unit_ids[0],s.unit_ids[1])
    after,_=m._apply_event(s,v4._Proposal(1,source=0),x,False)
    shifted=m._proposals(after,m.resources,((0,1),))
    link=[q for q in shifted if q.kind==2 and (q.source,q.target)==(0,1)]
    now_pair_ids=(after.unit_ids[0],after.unit_ids[1])
    caught=None
    try: m._proposals(after,m.resources,((1,2),))
    except Exception as ex: caught=type(ex).__name__
entry('P9_exposure_index_identity_hazard',old_ids=initial_ids,ids_after_deletion=after.unit_ids,
      originally_intended_ids=intended_pair_ids,now_targeted_ids=now_pair_ids,
      silently_redirected=len(link)>0 and intended_pair_ids!=now_pair_ids,
      out_of_bounds_exposure_error=caught)

# P10. Differentiable local laws; score-based discrete hazard not ordinary task-gradient.
# The event is selected by detached discrete sampling/argmax; compare gradients explicitly.
rec=[]
for seed in SEEDS[:4]:
    m,s,x=make(v4,seed,3,((0,1),))
    p=v4._Proposal(7,edge=0)
    rates=m._event_rates(s,x,[p])
    gr=torch.autograd.grad(rates.sum(),m.hazard[-1].weight,retain_graph=True,allow_unused=True)[0]
    result=m.advance(s,duration=.5,stochastic=False,
        resources=v4.ResourceBoundary(max_units=7,max_relations=10,max_operators=12,max_events_per_advance=1))
    task=result.logits.square().mean()
    g_task=torch.autograd.grad(task,m.hazard[-1].weight,retain_graph=True,allow_unused=True)[0]
    g_path=torch.autograd.grad(result.event_log_probability,m.hazard[-1].weight,retain_graph=True,allow_unused=True)[0]
    rec.append({'seed':seed,'event_count':result.events_executed,
                'hazard_rate_supervision_grad':None if gr is None else l2(gr),
                'task_to_hazard_grad':None if g_task is None else l2(g_task),
                'path_to_hazard_grad':None if g_path is None else l2(g_path)})
entry('P10_discrete_selection_training_path',samples=rec)

# P11. Numerical integration non-equivalence by chunking elapsed time.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3,((0,1),))
        single=m._flow(s,x,1.0)
        split=s
        for k in range(10): split=m._flow(split,x,.1)
        rec.append({'seed':seed,'unit_chunking_error':l2(single.units-split.units),
                    'law_chunking_error':l2(single.unit_laws-split.unit_laws),
                    'relation_chunking_error':l2(single.relations-split.relations)})
entry('P11_Euler_duration_chunking_effect',samples=rec)

# P12. Global task readout mixes disconnected units, although autonomous flow is local.
rec=[]
with torch.no_grad():
    for seed in SEEDS:
        m,s,x=make(v4,seed,3)
        pert=replace(s,units=s.units + torch.nn.functional.one_hot(torch.tensor(2),num_classes=3).float().unsqueeze(-1)*1.2)
        a=m._flow(s,x,.1); b=m._flow(pert,x,.1)
        rec.append({'seed':seed,
                    'unconnected_units01_flow_diff':l2(a.units[:2]-b.units[:2]),
                    'global_readout_diff':l2(m._readout(a,x)-m._readout(b,x))})
entry('P12_readout_global_vs_local_flow',samples=rec)

# P13. Observing readout is pure / not an autonomous observer state change.
with torch.no_grad():
    m,s,x=make(v4,17,3)
    old=s.clone()
    out1=m._readout(s,x); out2=m._readout(s,x)
    no_state_change = torch.equal(old.units,s.units) and torch.equal(old.unit_laws,s.unit_laws)
entry('P13_observation_is_task_interface',repeat_same_logits=bool(torch.equal(out1,out2)),
      readout_did_not_mutate_state=no_state_change,
      explicit_observer_mode_in_state='observer_mode' in s.__dataclass_fields__,
      explicit_possibility_state='possibilities' in s.__dataclass_fields__,
      has_anchor_memory_module=any('memory_anchor' in k.lower() for k in m.state_dict()))

# P14. v0 already carries state, boundary and relation; separate same-interface intervention.
with torch.no_grad():
    torch.manual_seed(73)
    mo=v0.DNO(vocab_size=10,slots=5,d_model=12,d_constraint=6,d_relation=6)
    sv=mo.initial_state(1)
    t=torch.tensor([2])
    _,sv=mo.step(t,sv)
    _,sv=mo.step(torch.tensor([4]),sv)
    base=mo.step(t,sv)[1]
    altered_boundary=replace(sv,boundary=sv.boundary+.5)
    altered_relation=replace(sv,relations=sv.relations+.5)
    b=mo.step(t,altered_boundary)[1]
    r=mo.step(t,altered_relation)[1]
entry('P14_v0_had_endogenous_state_effect',boundary_intervention_l2=l2(base.h-b.h),
      relation_intervention_l2=l2(base.h-r.h),
      has_variable_unit_count=False, has_continuous_time=False)

# P15. The generic computation is still packaged with an obligatory language decoder.
with torch.no_grad():
    m,s,x=make(v4,5,2)
    out=m.advance(s,duration=.0)
    without_vocab_error=None
    try: v4.EvolvingDNO()  # requires language vocabulary even if only using vectors
    except Exception as ex: without_vocab_error=type(ex).__name__
entry('P15_language_adapter_still_embedded_in_core',constructor_without_vocabulary_error=without_vocab_error,
      vector_advance_logit_shape=list(out.logits.shape),output_vocab_dimension=m.vocab_size,
      has_separate_task_head_adapter=False)

# P16. Finite executable primitive algebra vs dynamic recombination.
with torch.no_grad():
    m,s,x=make(v4,22,3,((0,1),))
    previous=len(s.operators)
    expanded,_=m._apply_event(s,v4._Proposal(4,edge=0),x,False)
    computed=m._programs(expanded,x.unsqueeze(0))
entry('P16_dynamic_composition_but_fixed_operation_alphabet',
      initial_operator_count=previous,post_composition_count=len(expanded.operators),
      newly_composed_kind=expanded.operators[-1].kind,
      executable_bank_shape=list(computed.shape),
      base_operation_vocabulary=list(v4.BASE_OPERATIONS),
      composite_operation_vocabulary=list(v4.COMPOSITE_OPERATIONS),
      event_kind_vocabulary=list(v4.EVENT_KINDS))

# P17. Application restriction of exposed contacts does not restrict unrelated
# universal event kinds such as unit release.
with torch.no_grad():
    m,s,x=make(v4,27,3)
    narrowed=v5.discover(s,use_paths=False,extra_pairs=((0,1),(1,2)),
             restriction=v5.OptionalRestriction(frozenset()))
    qs=m._proposals(s,m.resources,narrowed)
    kinds=[v4.EVENT_KINDS[q.kind] for q in qs]
entry('P17_pair_restriction_does_not_disable_other_builtins',
      pairs_allowed=len(narrowed),
      release_proposals=kinds.count('unit_release'),
      branch_proposals=kinds.count('unit_branch'),
      relation_open_proposals=kinds.count('relation_open'))

# Source integrity and state definition
paths={
  'v0':ROOT/'DNO_research_v0'/'dno.py',
  'v3':ROOT/'Delta_DNO_conditional_participation_v3'/'dno_conditional.py',
  'v4':ROOT/'DNO_v4_exposure_probe'/'dno_exposure.py',
  'v5_core':ROOT/'DNO_v5_multi_hypothesis_probe'/'dno_exposure.py',
  'v5_optional':ROOT/'DNO_v5_multi_hypothesis_probe'/'local_discovery.py',
}
RESULT['sha256_sources']={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()}
RESULT['source_equality']={'v4_v5_core_identical':paths['v4'].read_bytes()==paths['v5_core'].read_bytes()}
OUTPUT.joinpath('raw_results.json').write_text(json.dumps(RESULT,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
print('saved:',OUTPUT/'raw_results.json')
