# DNO Delta mathematical-fidelity audit — 2026-11-16

Read-only audit across available v0/v3/v4 source files, with v5 optional module verification. All original source files remain untouched.

## Contents
- `REPORT_ZH.md`: Full Chinese findings, strict evidence levels, examples and fix/no-fix decisions.
- `audit_delta_principles.py`: Reproducible 17-group counterfactual probe using eight initializations where applicable.
- `raw_results.json` and `audit_run.log`: Observed results and SHA256 references to inspected code.
- `train_delayed_information_v0.py`: Training protocol on unchanged DNO v0, with no dedicated memory training.
- `v0_delayed_information_training.json`, `train_v0.log`: Raw 3-seed data.
- `regression_v0.log` ... `regression_v5.log`: Re-run original tests (some tests overlap by version).

## Run

From this directory, with prior model files in their original `/mnt/data` paths:

```bash
python audit_delta_principles.py
python train_delayed_information_v0.py
```

The scripts are not self-contained without the pre-existing versioned DNO source code.
They do not alter those sources. The optional v5 exposure module is an application plugin, not a new core.

Potential limitations: fixed toy setups, small random seeds, controlled intervention with internal methods, no large-scale task generalization, CPU PyTorch and approximate event scheduler.
