"""Validate observed experimental claims against recorded files.
This does NOT turn finite experiments into a proof of Delta mathematics.
"""
import json, pathlib, re
p=pathlib.Path(__file__).resolve().parent
r=json.loads((p/'raw_results.json').read_text())
c=r['checks']
assert len(c)==17, f'Expected 17 categories, got {len(c)}'
assert c['P1_endogenous_recursion_and_effective_law']['all_nonzero']
assert c['P1_endogenous_recursion_and_effective_law']['deterministic']
assert c['P2_relation_exists_without_participation']['all_passive_exact_zero']
assert c['P2_relation_exists_without_participation']['all_active_contact_has_effect']
assert c['P3_history_as_current_state_after_edge_removed']['all_state_residual']
assert c['P3_history_as_current_state_after_edge_removed']['all_output_residual']
assert c['P4_path_dependent_coupled_interaction']['all_noncommutative']
assert c['P5_boundary_modulates_rate_but_not_reachability']['all_candidates_same']
assert c['P5_boundary_modulates_rate_but_not_reachability']['all_rates_strict_positive']
assert c['P6_contact_exposure_is_optional_external_contract']['all_unexposed_empty']
assert c['P6_contact_exposure_is_optional_external_contract']['all_state_only_still_empty']
assert c['P6_contact_exposure_is_optional_external_contract']['all_exposed_available']
assert c['P7_builtin_release_has_positive_rate_without_external_cue']['all_release_positive']
assert c['P9_exposure_index_identity_hazard']['silently_redirected']
assert c['P9_exposure_index_identity_hazard']['out_of_bounds_exposure_error']=='ValueError'
assert r['source_equality']['v4_v5_core_identical']
assert all(x['task_to_hazard_grad'] is None and x['path_to_hazard_grad']>0
           for x in c['P10_discrete_selection_training_path']['samples'])
assert all(x['unconnected_units01_flow_diff']==0 and x['global_readout_diff']>0
           for x in c['P12_readout_global_vs_local_flow']['samples'])
assert c['P15_language_adapter_still_embedded_in_core']['constructor_without_vocabulary_error']=='TypeError'
assert c['P16_dynamic_composition_but_fixed_operation_alphabet']['post_composition_count']==5
assert c['P17_pair_restriction_does_not_disable_other_builtins']['release_proposals']==3
tr=json.loads((p/'v0_delayed_information_training.json').read_text())['results']
assert len(tr)==3
for x in tr:
    assert x['heldout_delay3_accuracy']>=.99 and x['heldout_delay7_accuracy']>=.99
    assert .35<x['query_only_reset_accuracy']<.65
    assert x['counterfactual_flipped_accuracy']>=.99
for name in 'v0','v1','v2','v3','v4','v5':
    log=(p/f'regression_{name}.log').read_text()
    assert ('OK' in log or 'passed' in log) and 'FAILED' not in log, name
print('Validation PASS: 17 audit categories, 3 memory-task seeds, 6 regression suites, v4/v5 core byte identity.')
