"""Optional *application training* example: no memory-anchor type or algorithm.
Train a v0 network on delayed first-symbol classification, then test reset/longer delay.
Does not test Delta completeness nor prove emergent meaningful human memory.
"""
from __future__ import annotations
import sys,json,torch
from pathlib import Path
sys.path.insert(0,'/mnt/data/DNO_research_v0')
from dno import DNO
from torch.nn import functional as F
out=Path(__file__).resolve().parent

torch.set_num_threads(1)

def data(n,delay,gen):
    label=torch.randint(0,2,(n,),generator=gen)
    noise=torch.randint(2,4,(n,delay),generator=gen)
    seq=torch.cat((label.unsqueeze(1),noise,torch.full((n,1),4,dtype=torch.long)),dim=1)
    return seq,label

results=[]
for seed in (17,33,49):
    torch.manual_seed(seed)
    gen=torch.Generator().manual_seed(seed+10000)
    m=DNO(vocab_size=5,slots=5,d_model=16,d_constraint=6,d_relation=6)
    optimizer=torch.optim.Adam(m.parameters(),lr=.004)
    losses=[]
    for step in range(260):
        x,y=data(64,3,gen)
        pred=m(x)[:,-1,:]
        loss=F.cross_entropy(pred,y)
        optimizer.zero_grad();loss.backward();optimizer.step()
        if step in (0,29,99,179,259): losses.append({'step':step+1,'loss':float(loss.detach())})
    with torch.no_grad():
        ev=torch.Generator().manual_seed(88000+seed)
        short,label=data(512,3,ev)
        long,label_long=data(512,7,ev)
        normal=(m(short)[:,-1,:2].argmax(-1)==label).float().mean().item()
        longer=(m(long)[:,-1,:2].argmax(-1)==label_long).float().mean().item()
        reset=(m(short[:,-1:])[:,-1,:2].argmax(-1)==label).float().mean().item()
        # First-token intervention with otherwise EXACTLY same tail.
        cf=short.clone();cf[:,0]=1-cf[:,0]
        flipped=(m(cf)[:,-1,:2].argmax(-1)==cf[:,0]).float().mean().item()
        change=float((m(short)[:,-1,:2]-m(cf)[:,-1,:2]).abs().mean())
    z={'seed':seed,'train_loss':losses,'heldout_delay3_accuracy':normal,
       'heldout_delay7_accuracy':longer,'query_only_reset_accuracy':reset,
       'counterfactual_flipped_accuracy':flipped,'mean_logit_shift_flip_initial_bit':change}
    print(json.dumps(z,ensure_ascii=False),flush=True)
    results.append(z)
(out/'v0_delayed_information_training.json').write_text(json.dumps({'method':'3 random seeds, 260 Adam updates, 64 samples/update, no dedicated memory supervision, fixed delay=3 task labels','results':results},indent=2)+'\n')
