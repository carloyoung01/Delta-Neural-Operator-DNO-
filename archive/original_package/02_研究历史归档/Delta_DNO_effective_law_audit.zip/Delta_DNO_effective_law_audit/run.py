import json,time,hashlib,pathlib
from effective import DirectMLP,FrozenDNOBridge,fit,assess,intervention_geometry
import torch

@torch.no_grad()
def extra_eval(model):
    gen=torch.Generator().manual_seed(8132)
    from effective import world,effect_contrast
    s=torch.rand((1000,3),generator=gen)*1.8-.9
    u=torch.rand((1000,),generator=gen)*2-1
    continuous_mse=float(((model(s,u)-world(s,u))**2).mean())
    # Shift beyond the training cube to expose extrapolation weakness.
    s2=torch.rand((1000,3),generator=gen)*2.6-1.3
    u2=torch.where(torch.rand((1000,),generator=gen)>.5,1.,-1.)
    extrap_mse=float(((model(s2,u2)-world(s2,u2))**2).mean())
    results=dict(continuous_action_mse=continuous_mse,extrapolation_mse=extrap_mse)
    if hasattr(model,"core"):
        base=model(s,u2)
        for mode in ["law","boundary","both"]:
            out=model(s,u2,ablate=mode)
            results["ablate_"+mode+"_mse"]=float(((out-world(s,u2))**2).mean())
            results["ablate_"+mode+"_change"]=float((out-base).abs().mean())
    return results

out={'experiment':'Effective distinction via counterfactual contrasts; both models share paired samples',
     'geometry':intervention_geometry(),'models':{}, 'frozen_sha256':hashlib.sha256(pathlib.Path('dno.py').read_bytes()).hexdigest(),
     'notes':['world() equation only exists in evaluation simulator, not in models.',
              'FrozenDNOBridge uses unmodified DNO generator and seed modules, batched for training.',
              'This is a 1-carrier special case, not complete multi-carrier behavior.']}
for name,cls in [('frozen_dno',FrozenDNOBridge),('nonlinear_control',DirectMLP)]:
    out['models'][name]={}
    for seed in [3,17,29]:
        torch.manual_seed(seed)
        model=cls()
        train=fit(model,seed=seed)
        ev=assess(model)
        ev.update(extra_eval(model))
        out['models'][name][str(seed)]={'train_mse':train,**ev}
        print(name,seed,'train',round(train,7),'outcome',round(ev['outcome_mse'],7),'contrast',round(ev['contrast_mse'],7),'roots',ev['roots'],flush=True)
pathlib.Path('evidence/results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print('geometry',out['geometry'])
