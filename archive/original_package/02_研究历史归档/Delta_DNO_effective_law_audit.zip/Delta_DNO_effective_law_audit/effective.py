"""Counterfactual effective-distinction audit. No event labels or boundary thresholds.

The numerical simulator is a falsifiable *test environment*, not a DNO law.
Feature influence is defined by a finite-difference intervention contrast.
"""
from __future__ import annotations
import torch
from torch import nn


def world(s: torch.Tensor, u: torch.Tensor) -> torch.Tensor:
    """Test-only dynamics, scalar outcome, s=[x,y,z].

    Context-dependent influence of y vanishes along x+z=0; this boundary
    must be inferred, never passed to learner.
    """
    x,y,z = s.unbind(-1)
    return x + 0.2 * u * y * (x + z)


def sample(n, generator, device='cpu'):
    s = (torch.rand((n,3), generator=generator,device=device)*1.8-.9)
    u = torch.where(torch.rand(n, generator=generator,device=device)>.5,1.,-1.)
    return s,u,world(s,u)


def effect_contrast(predict, s, *, coordinate=1, delta=0.02):
    """Difference in perturbation response across u=+1 and u=-1.

    No criterion for 'significant' effects is hardcoded.  The returned signed
    scalar is a measured conditional effect, not a Boolean relation.
    """
    offset=torch.zeros_like(s)
    offset[:,coordinate]=delta
    positive=torch.ones(s.shape[0],device=s.device)
    negative=-positive
    return ((predict(s+offset,positive)-predict(s-offset,positive)) -
            (predict(s+offset,negative)-predict(s-offset,negative)))/(4*delta)


class DirectMLP(nn.Module):
    def __init__(self,hidden=32):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(4,hidden),nn.Tanh(),nn.Linear(hidden,hidden),nn.Tanh(),nn.Linear(hidden,1))
    def forward(self,s,u):
        return (s[:,0]+self.net(torch.cat([s,u[:,None]],-1))[:,0])


class FrozenDNOBridge(nn.Module):
    """Unmodified original DNO, one carrier, scalar output via evolve.

    Bridge is merely tensor I/O; there is NO added internal learning algorithm.
    """
    def __init__(self):
        super().__init__()
        from dno import DNO
        self.core=DNO(d=4,hidden=32)

    def forward(self,s,u, *, ablate=None):
        # Vectorized independent single-carrier states; this is an exact
        # batched version of the dno.py evolve generator's n=1 update.
        n=s.shape[0]
        val=torch.cat([s,torch.zeros((n,1),device=s.device)],-1)
        boundary=self.core.seed_boundary(val).tanh()
        law=self.core.seed_law(val).tanh()
        if ablate == "law":
            law=torch.zeros_like(law)
        if ablate == "boundary":
            boundary=torch.zeros_like(boundary)
        if ablate == "both":
            boundary=torch.zeros_like(boundary)
            law=torch.zeros_like(law)
        pack=torch.cat([val,boundary,law,torch.ones((n,1),device=s.device),torch.zeros((n,1),device=s.device)],-1)
        cues=torch.zeros((n,4),device=s.device); cues[:,0]=u
        delta,_,_=self.core._call(pack,torch.zeros_like(pack),torch.zeros_like(val),cues,torch.ones((n,1),device=s.device))
        return val[:,0] + delta[:,0].tanh()


def fit(model,seed=3,steps=450,n_train=512,lr=.009):
    torch.manual_seed(seed)
    g=torch.Generator().manual_seed(1234)  # exactly the same data across models
    s,u,y=sample(n_train,g)
    optimizer=torch.optim.Adam(model.parameters(),lr=lr)
    for t in range(steps):
        optimizer.zero_grad(set_to_none=True)
        p=model(s,u)
        loss=((p-y)**2).mean()
        loss.backward()
        optimizer.step()
    return float(loss.detach())

@torch.no_grad()
def assess(model,seed=2026):
    g=torch.Generator().manual_seed(seed)
    s,u,y=sample(1000,g)
    mse=float(((model(s,u)-y)**2).mean())
    contrast_true=effect_contrast(world,s)
    contrast_model=effect_contrast(model,s)
    contrast_mse=float(((contrast_true-contrast_model)**2).mean())
    # Discover effective boundaries for 5 held-out x from signed contrasts
    # without giving boundary equation to prediction model.
    x_values=[-.65,-.35,0.,.35,.65]
    roots=[]
    for x in x_values:
        zs=torch.linspace(-.9,.9,181)
        pts=torch.column_stack([torch.full_like(zs,x),torch.zeros_like(zs),zs])
        effects=effect_contrast(model,pts)
        signs=effects[:-1]*effects[1:]
        crossings=(signs<=0).nonzero().flatten().tolist()
        if not crossings:
            roots.append(None)
        else:
            # Choose the root closest to the oracle boundary ONLY for
            # error scoring; the model does not see oracle when learning.
            rr=[float(zs[k] - effects[k]*(zs[k+1]-zs[k])/(effects[k+1]-effects[k]+1e-12)) for k in crossings]
            roots.append(min(rr,key=lambda a:abs(a+x)))
    valid=[abs(r+x) for x,r in zip(x_values,roots) if r is not None]
    return dict(outcome_mse=mse,contrast_mse=contrast_mse,
                roots=roots,true_roots=[-x for x in x_values],
                root_mae=(sum(valid)/len(valid) if len(valid)==5 else None),
                recovered=len(valid))


def intervention_geometry():
    # From black-box interventions alone; never inspect the world equation.
    xx=torch.linspace(-.9,.9,29); zz=torch.linspace(-.9,.9,29)
    xgrid,zgrid=torch.meshgrid(xx,zz,indexing='ij')
    pts=torch.stack([xgrid.reshape(-1),torch.zeros(29*29),zgrid.reshape(-1)],-1)
    contrast=effect_contrast(world,pts).reshape(29,29)
    singular=torch.linalg.svdvals(contrast)
    return dict(singular_values=[float(v) for v in singular[:5]],
                rank_99_9=int((torch.cumsum(singular**2,0)/torch.sum(singular**2)<.999).sum()+1),
                area_abs_effect=float(contrast.abs().mean()),
                sign_positive_fraction=float((contrast>0).float().mean()))
