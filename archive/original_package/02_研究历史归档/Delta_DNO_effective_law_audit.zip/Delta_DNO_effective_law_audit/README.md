# Delta DNO — effective law audit

Requirements: Python 3.10+, PyTorch, pytest.

```sh
python -m pytest -q tests/test_effective.py
python run.py
```

`dno.py` is an unchanged copy of the frozen Delta DNO core. `effective.py` provides a black-box intervention contrast and baseline bridge. `run.py` trains identical-data reference and DNO models (3 seeds) and stores evaluations in `evidence/results.json`. This is an independent synthetic falsification experiment, not a new version of the frozen architecture.
