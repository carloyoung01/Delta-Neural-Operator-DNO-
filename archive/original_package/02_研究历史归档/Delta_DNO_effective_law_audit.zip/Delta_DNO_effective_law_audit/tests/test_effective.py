import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from effective import world,effect_contrast,intervention_geometry,FrozenDNOBridge,DirectMLP

def test_oracle_boundary_emerges_from_interventions():
    s=torch.tensor([[.4,0.,-.4],[.4,0.,.2],[-.2,0.,.5]])
    effects=effect_contrast(world,s)
    assert abs(float(effects[0]))<1e-4
    assert float(effects[1])>0
    assert float(effects[2])>0

def test_effect_is_not_observational_correlation():
    s=torch.tensor([[.7,0.,-.7],[.7,0.,.4]])
    e=effect_contrast(world,s)
    assert abs(float(e[0])) < 1e-4 and e[1]>0

def test_no_effect_when_action_is_off():
    s=torch.rand(7,3)
    assert torch.allclose(world(s,torch.zeros(7)),s[:,0])

def test_both_models_can_propagate_gradient():
    for model in [DirectMLP(),FrozenDNOBridge()]:
        s=torch.rand(8,3)
        pred=model(s,torch.ones(8))
        pred.sum().backward()
        assert any(p.grad is not None for p in model.parameters())

def test_frozen_bridge_matches_core_evolve_one_step():
    torch.manual_seed(11)
    b=FrozenDNOBridge()
    s=torch.tensor([[.2,-.4,.3]])
    u=torch.tensor([.7])
    v=b(s,u)
    core=b.core
    state=core.introduce(core.blank(),torch.tensor([[.2,-.4,.3,0.]]))
    cue=torch.tensor([.7,0.,0.,0.])
    evolved=core.evolve(state,1.0,local={0:cue})
    assert torch.allclose(v,evolved.value[0,0],atol=1e-6)

def test_no_hardcoded_boundary_in_inference():
    import inspect,effective
    code=inspect.getsource(effective.effect_contrast)
    assert 'x + z' not in code and '0.2' not in code

def test_geometry_has_nontrivial_structure():
    g=intervention_geometry()
    assert g['rank_99_9']==2
    assert g['singular_values'][0]>g['singular_values'][1]>0

def test_same_observed_outcome_can_hide_distinct_effectiveness():
    # Under no action, these share the same observed result x, but after
    # intervention their conditional effects diverge: observation alone fails.
    s=torch.tensor([[.35,-.2,-.35],[.35,-.2,.40]])
    u=torch.zeros(2)
    assert torch.allclose(world(s,u)[0],world(s,u)[1])
    impacts=effect_contrast(world,s)
    assert abs(float(impacts[0]))<1e-4
    assert abs(float(impacts[1]))>.1


def test_intervention_contrast_cancels_action_invariant_component():
    def shifted(s,u):
        return world(s,u)+0.7*s[:,2]**2+0.5*s[:,1]
    s=torch.rand((8,3))
    assert torch.allclose(effect_contrast(world,s),effect_contrast(shifted,s),atol=1e-4)
