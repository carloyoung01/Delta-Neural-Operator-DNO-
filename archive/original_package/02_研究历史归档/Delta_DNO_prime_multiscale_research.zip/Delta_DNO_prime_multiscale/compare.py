"""Controls: no general superiority claim from a target built using prime frequencies."""
import json
import math
from pathlib import Path
import torch
from prime_delta import first_primes,ScaleLift

torch.set_num_threads(1)
torch.manual_seed(20261116)
k=8
prime=torch.log(torch.tensor(first_primes(k),dtype=torch.float64))
integer=torch.log(torch.arange(2,k+2,dtype=torch.float64))
random=torch.sort(0.5+torch.rand(k,dtype=torch.float64)*3.0).values
frequency_sets={'prime_log':prime,'integer_log':integer,'random':random}
# Fixed velocities, no target-dependent learning of feature parameters.
def features(w,x,t,scale):
    arg=(x+0.25*t+0.4*torch.log(scale))[:,None]*w[None,:]
    return torch.cat((torch.ones(x.shape[0],1,dtype=torch.float64),torch.cos(arg),torch.sin(arg)),1)

def run(task):
    # OOD x interval, while t and scale remain drawn from same distributions.
    xtr=torch.rand(256,dtype=torch.float64)*4-2
    xte=2+torch.rand(256,dtype=torch.float64)*3
    ttr=torch.rand(256,dtype=torch.float64)*3; tte=torch.rand(256,dtype=torch.float64)*3
    str_=torch.exp(torch.rand(256,dtype=torch.float64)*2-1)
    ste=torch.exp(torch.rand(256,dtype=torch.float64)*2-1)
    ztr=xtr+.25*ttr+.4*torch.log(str_)
    zte=xte+.25*tte+.4*torch.log(ste)
    if task=='prime_constructed':
        target=lambda z: (torch.sin(z*prime[0])+.65*torch.cos(z*prime[3])-.4*torch.sin(z*prime[6]))
    elif task=='integer_constructed':
        target=lambda z: (torch.sin(z*integer[0])+.65*torch.cos(z*integer[3])-.4*torch.sin(z*integer[6]))
    else:
        target=lambda z: (torch.sin(0.7*z)+0.35*torch.cos(1.4*z))
    out={}
    for name,w in frequency_sets.items():
        a=features(w,xtr,ttr,str_); b=features(w,xte,tte,ste)
        lam=1e-5
        coef=torch.linalg.solve(a.T@a+lam*torch.eye(a.shape[1],dtype=torch.float64),a.T@target(ztr))
        out[name]={'train_mse':float(((a@coef-target(ztr))**2).mean()),'ood_mse':float(((b@coef-target(zte))**2).mean())}
    return out

results={task:run(task) for task in ('prime_constructed','integer_constructed','neutral')}
Path(__file__).parent.joinpath('results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
