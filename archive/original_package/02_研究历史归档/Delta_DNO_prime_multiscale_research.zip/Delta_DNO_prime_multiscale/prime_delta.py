"""Finite, falsifiable prime-scale lift for Delta distinction dynamics.

Not an implementation or proof of the Riemann hypothesis. Prime frequencies
are one hypothesis; controls are essential. No primality-based event rules.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import torch
from torch import nn, Tensor


def first_primes(n: int) -> list[int]:
    if n < 1: raise ValueError('n >= 1 required')
    found=[]; v=2
    while len(found)<n:
        if all(v%p for p in found if p*p<=v): found.append(v)
        v+=1
    return found


def finite_euler(s: complex, primes: list[int]) -> complex:
    """Partial Euler product; convergence to zeta only for Re(s)>1."""
    if s.real<=1: raise ValueError('Euler product identity needs Re(s)>1')
    z=1+0j
    for p in primes: z*=1/(1-p**(-s))
    return z


def smooth_numbers(primes: list[int], cap: int) -> list[int]:
    """All integers <= cap with prime factors in primes."""
    seen={1}; queue=[1]
    while queue:
        n=queue.pop()
        for p in primes:
            v=n*p
            if v<=cap and v not in seen: seen.add(v); queue.append(v)
    return sorted(seen)


class ScaleLift(nn.Module):
    """Complex phase lift: z_k=exp(i omega_k (x + v*t + w*log(scale))).

    Shape x,t,scale: broadcastable 1D batches; returns [batch,2K].
    Frequencies may be prime logs, consecutive integer logs, or matched random.
    The map is a representation, not an event catalog or exhaustive future set.
    """
    def __init__(self, frequencies: Tensor, *, learn_phase: bool=False):
        super().__init__()
        if frequencies.ndim!=1 or frequencies.numel()<1 or not bool(torch.isfinite(frequencies).all()):
            raise ValueError('finite nonempty 1D frequencies required')
        self.register_buffer('omega', frequencies.detach().float().clone())
        self.time_velocity=nn.Parameter(torch.tensor(0.25))
        self.scale_velocity=nn.Parameter(torch.tensor(0.4))
        self.phase=nn.Parameter(torch.zeros(len(frequencies)), requires_grad=learn_phase)
    def forward(self,x:Tensor,t:Tensor,scale:Tensor)->Tensor:
        x,t,scale=torch.broadcast_tensors(x.float(),t.float(),scale.float())
        if not bool((scale>0).all()): raise ValueError('scale must be positive')
        angle=(x+self.time_velocity*t+self.scale_velocity*torch.log(scale)).unsqueeze(-1)*self.omega+self.phase
        return torch.cat([torch.cos(angle),torch.sin(angle)],-1)


class DeltaSpectralState(nn.Module):
    """Current content, law and space-time scale determine next content/law.

    Shared finite generator; no enumerated event kinds. Actual interaction is
    supplied as a tensor; observation is explicitly optional. Historical
    information is in current content/law, not an event log.
    """
    def __init__(self,dim:int,frequencies:Tensor,hidden:int=48):
        super().__init__()
        self.dim=dim
        self.lift=ScaleLift(frequencies)
        k=2*len(frequencies)
        self.generator=nn.Sequential(nn.Linear(dim*3+k,hidden),nn.Tanh(),nn.Linear(hidden,dim*2))
        self.observer=nn.Sequential(nn.Linear(dim+k,hidden),nn.Tanh(),nn.Linear(hidden,dim))
    def evolve(self,content:Tensor,law:Tensor,interaction:Tensor,t:Tensor,scale:Tensor):
        if content.shape!=law.shape or content.shape!=interaction.shape or content.shape[-1]!=self.dim:
            raise ValueError('content, law, interaction must match [N,D]')
        phase=self.lift(content.mean(-1),t,scale)
        change=self.generator(torch.cat([content,law,interaction,phase],-1))
        dc,dl=change.chunk(2,-1)
        return content+dc,law+dl
    def observe(self,content:Tensor,t:Tensor,scale:Tensor):
        phase=self.lift(content.mean(-1),t,scale)
        return self.observer(torch.cat([content,phase],-1))


def future_signature(model:DeltaSpectralState, content:Tensor,law:Tensor,
                     interventions:Tensor,t:Tensor,scale:Tensor)->Tensor:
    """Finite *specified* intervention signatures; no universal equivalence claim."""
    outs=[]
    for u in interventions:
        c,l=model.evolve(content,law,u.expand_as(content),t,scale)
        outs.append(model.observe(c,t,scale))
    return torch.stack(outs,1)


def distance_matrix(signatures:Tensor)->Tensor:
    flat=signatures.flatten(1)
    return torch.cdist(flat,flat).square()
