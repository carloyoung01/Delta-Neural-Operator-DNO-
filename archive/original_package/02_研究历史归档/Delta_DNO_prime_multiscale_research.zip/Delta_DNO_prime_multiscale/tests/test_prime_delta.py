import math
import pytest
import torch
from prime_delta import first_primes, finite_euler, smooth_numbers, ScaleLift,DeltaSpectralState,future_signature,distance_matrix

def test_primes(): assert first_primes(6)==[2,3,5,7,11,13]
def test_euler_finite():
    ps=[2,3,5]; s=2.4+0.6j
    terms=sum(n**(-s) for n in smooth_numbers(ps,200000))
    assert abs(terms-finite_euler(s,ps))<2e-9

def test_euler_domain():
    with pytest.raises(ValueError): finite_euler(0.5+14j,[2,3,5])
def test_scale_time():
    m=ScaleLift(torch.log(torch.tensor(first_primes(6),dtype=torch.float32)))
    x=torch.tensor([0.4,0.8]); t=torch.tensor([0.,0.]); sc=torch.ones(2)
    a=m(x,t,sc); assert a.shape==(2,12)
    assert not torch.allclose(a,m(x,t+1,sc))
    assert not torch.allclose(a,m(x,t,sc*2))
    assert torch.allclose(a[:,:6].square()+a[:,6:].square(),torch.ones(2,6),atol=1e-6)
def test_scale_positive():
    with pytest.raises(ValueError): ScaleLift(torch.ones(3))(torch.ones(1),torch.ones(1),torch.zeros(1))
def test_no_implicit_observation():
    m=DeltaSpectralState(3,torch.log(torch.tensor(first_primes(4),dtype=torch.float32)))
    c=torch.randn(4,3); l=torch.randn_like(c); u=torch.zeros_like(c)
    a,b=m.evolve(c,l,u,torch.zeros(4),torch.ones(4))
    assert a.shape==c.shape and b.shape==l.shape
    assert not torch.allclose(a,c)
def test_current_law_causal():
    torch.manual_seed(3)
    m=DeltaSpectralState(3,torch.log(torch.tensor(first_primes(4),dtype=torch.float32)))
    c=torch.randn(4,3); l=torch.randn_like(c); u=torch.zeros_like(c)
    a,_=m.evolve(c,l,u,torch.zeros(4),torch.ones(4))
    b,_=m.evolve(c,l+0.2,u,torch.zeros(4),torch.ones(4))
    assert (a-b).abs().max()>1e-6
def test_history_without_log():
    torch.manual_seed(5)
    m=DeltaSpectralState(3,torch.log(torch.tensor(first_primes(4),dtype=torch.float32)))
    c=torch.randn(3,3); l=torch.randn_like(c)
    a,la=m.evolve(c,l,torch.ones_like(c),torch.zeros(3),torch.ones(3))
    b,lb=m.evolve(c,l,torch.zeros_like(c),torch.zeros(3),torch.ones(3))
    a,_=m.evolve(a,la,torch.zeros_like(c),torch.ones(3),torch.ones(3))
    b,_=m.evolve(b,lb,torch.zeros_like(c),torch.ones(3),torch.ones(3))
    assert not torch.allclose(a,b)
def test_signature():
    torch.manual_seed(9)
    m=DeltaSpectralState(3,torch.log(torch.tensor(first_primes(4),dtype=torch.float32)))
    c=torch.randn(4,3); l=torch.randn_like(c); u=torch.randn(3,3)
    sig=future_signature(m,c,l,u,torch.zeros(4),torch.ones(4))
    d=distance_matrix(sig)
    assert sig.shape==(4,3,3) and d.shape==(4,4)
    assert torch.allclose(d,d.T) and torch.allclose(torch.diag(d),torch.zeros(4),atol=1e-6)
def test_trainable_gradient():
    m=DeltaSpectralState(2,torch.log(torch.tensor(first_primes(4),dtype=torch.float32)))
    c=torch.randn(8,2); l=torch.randn_like(c)
    a,b=m.evolve(c,l,torch.randn_like(c),torch.ones(8),torch.ones(8))
    (a.square().mean()+b.square().mean()).backward()
    assert m.lift.time_velocity.grad is not None and m.lift.time_velocity.grad.abs()>0
    assert m.generator[0].weight.grad is not None
