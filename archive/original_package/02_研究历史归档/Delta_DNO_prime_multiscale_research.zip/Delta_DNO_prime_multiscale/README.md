# Delta DNO: Prime-scale spatiotemporal lift

Requires Python, PyTorch, pytest.

```bash
pip install torch pytest
PYTHONPATH=. pytest -q tests/
python compare.py
```

`prime_delta.py`: finite Euler-product check, log-prime phase lift, shared Delta state transition and finite future distinction signature.

`compare.py`: matched-size frequency controls; results in `results.json`.

`REPORT_ZH.md`: math derivation, boundaries, numerical outcomes, interpretation.

This is a **separate research prototype**. It does not overwrite frozen DNO or claim a proof of the Riemann hypothesis.
