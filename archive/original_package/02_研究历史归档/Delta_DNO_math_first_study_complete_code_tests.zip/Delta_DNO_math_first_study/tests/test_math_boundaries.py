"""Expected-limit checks: record boundaries without inventing mechanisms.

These tests PASS by correctly observing limitations. They are NOT positive
proofs that the full Delta mathematics has been implemented.
"""
from dataclasses import replace
import types
import torch
from delta_core import DeltaCore


def construct(seed=10):
    torch.manual_seed(seed)
    m=DeltaCore(d=12,b=4,l=5,r=6,hidden=24)
    s=m.introduce(m.blank(),torch.randn(4,12))
    return m,s


def test_original_dead_relation_counterexample_and_minimal_repair():
    m,s=construct()
    with torch.no_grad():
        m.rewrite[-1].weight[-1].zero_()
        m.rewrite[-1].bias[-1]=1.0
    s=m.contact(s,0,1)
    other=replace(s,relations=s.relations+3.0)
    active=float((m.address(s).target_probs-m.address(other).target_probs).norm().detach())
    # This bypass reproduces the first implementation's failing causal path.
    old=m._keys
    m._keys=lambda state: m.unit_key(m._effective_unit(state)).tanh()
    dead=float((m.address(s).target_probs-m.address(other).target_probs).norm().detach())
    m._keys=old
    assert dead==0.0
    assert active>1e-8


def test_internal_soft_access_is_not_exact_unreachability():
    m,s=construct()
    q=m.address(s)
    # No dynamic internal boundary has proven strict zero/forbidden contact.
    assert bool((q.source_probs>0).all())
    assert bool((q.target_probs>0).all())
    # The optional application mask can enforce exact zeros.
    masked=m.address(s,allowed_target_ids={s.ids[0]})
    assert masked.target_probs[1:].sum().item()==0


def test_no_endogenous_unit_individuation_primitive_yet():
    m,s=construct()
    # Generic contact may rewrite state and make/retain a relation;
    # it cannot yet emit a newly distinct unit, unless environment introduces.
    a=m.evolve(s,.8)
    b=m.contact(a,s.ids[0],s.ids[1])
    assert len(a.ids)==len(s.ids)==len(b.ids)
    c=m.introduce(b,torch.randn(m.d))
    assert len(c.ids)==len(s.ids)+1


def test_effective_law_changes_without_updating_foundational_weights():
    m,s=construct()
    before={name:p.detach().clone() for name,p in m.named_parameters()}
    evolved=m.evolve(s,.7)
    assert (evolved.laws-s.laws).norm()>0
    assert all(torch.equal(p,before[name]) for name,p in m.named_parameters())


def test_global_observer_updates_without_explicit_read_call():
    m,s=construct()
    a=m.evolve(s,.1)
    assert (a.observer-s.observer).norm()>0
    # Therefore the current prototype does NOT establish a fully optional
    # no-observation dynamic even though an application can abstain from readout.


def test_old_input_not_replayable_from_same_current_state():
    m,s=construct()
    a=m.evolve(s,.1)
    b=m.evolve(s.clone(),.1)
    assert torch.equal(a.units,b.units)
    assert torch.equal(a.observer,b.observer)
