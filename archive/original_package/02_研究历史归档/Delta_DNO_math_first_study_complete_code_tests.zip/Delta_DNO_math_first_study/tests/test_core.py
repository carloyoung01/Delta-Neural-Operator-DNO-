import math
from dataclasses import replace
import pytest
import torch
from delta_core import DeltaCore
from runtimes import ReferenceBernoulliRuntime


def setup(seed=0,n=4):
    torch.manual_seed(seed)
    m=DeltaCore(d=12,b=4,l=5,r=6,hidden=24)
    s=m.introduce(m.blank(),torch.randn(n,12))
    return m,s


def test_no_event_type_catalogue_and_no_pairs_constructed():
    import inspect
    import delta_core
    source=inspect.getsource(delta_core)
    assert not hasattr(delta_core, 'EVENT_KINDS')
    assert '_proposals(' not in source
    assert 'for j in range(n)' not in source
    m,s=setup(n=25)
    a=m.address(s)
    assert a.source_probs.shape==(25,)
    assert a.target_probs.shape==(25,)
    assert a.units_seen==25


def test_blank_introduction_stable_ids():
    m,s=setup(n=3)
    s.validate()
    assert s.ids==(0,1,2)
    s=m.retire(s,1)
    assert s.ids==(0,2)
    s=m.introduce(s,torch.randn(1,m.d))
    assert s.ids==(0,2,3)
    s.validate()


def test_absent_external_still_evolves():
    m,s=setup()
    n=m.evolve(s,.3)
    assert (n.units-s.units).norm()>0
    assert (n.laws-s.laws).norm()>0
    assert (n.observer-s.observer).norm()>0
    assert n.t==pytest.approx(.3)


def test_current_boundary_and_law_are_causal():
    m,s=setup()
    a=m.evolve(s,.2)
    b=m.evolve(replace(s,boundaries=s.boundaries+1.0),.2)
    c=m.evolve(replace(s,laws=s.laws+1.0),.2)
    assert (a.units-b.units).norm()>1e-7
    assert (a.units-c.units).norm()>1e-7
    assert (m.address(s).target_probs-m.address(replace(s,laws=s.laws+1.0)).target_probs).norm()>0


def test_no_contact_no_relation_to_unit_messages():
    m,s=setup()
    # Controlled current relation, no domain constraints or automatic contact
    s=m.contact(s,0,1)
    # Compare keeping/removing relation, retaining all current unit information.
    sr=replace(s,edges=(),relations=s.relations[:0],relation_laws=s.relation_laws[:0],
               relation_clocks=s.relation_clocks[:0],relation_mass=s.relation_mass[:0])
    a=m.evolve(s,.2)
    b=m.evolve(sr,.2)
    assert torch.equal(a.units,b.units)
    assert torch.equal(a.laws,b.laws)


def test_contact_is_effective_and_history_persists_after_remove():
    m,s=setup()
    after=m.contact(s,0,1)
    # first contact affects current units, even if no persistent edge written
    assert (after.units-s.units).norm()>1e-6
    after=m.evolve(after,.4)
    plain=m.evolve(s,.4)
    assert (after.units-plain.units).norm()>1e-6
    assert (m.observe(after)-m.observe(plain)).norm()>1e-8


def test_dynamic_relation_creation_and_removal_by_current_support():
    m,s=setup()
    # Set learned persistence output positive for controlled construction.
    with torch.no_grad():
        m.rewrite[-1].weight[-1].zero_()
        m.rewrite[-1].bias[-1].fill_(1.0)
    z=m.contact(s,1,3)
    assert (1,3) in z.edges
    assert z.relation_mass[z.edges.index((1,3))].item()>0
    # Autonomous relation dynamics still proceeds when no contact happens.
    w=m.evolve(z,.2)
    assert not torch.equal(w.relations,z.relations)
    # External removal uses stable identities, never stale row numbers.
    q=m.retire(w,1)
    assert (1,3) not in q.edges
    q.validate()


def test_sample_can_choose_no_contact():
    m,s=setup()
    with torch.no_grad():
        m.contact_rate[-1].weight.zero_()
        m.contact_rate[-1].bias.fill_(-20)
    g=torch.Generator().manual_seed(987)
    for _ in range(16):
        out=ReferenceBernoulliRuntime(m).advance(s,.001,generator=g)
        assert out.contact is None
        assert not out.state.edges


def test_dynamic_policy_strictly_excludes_target_identity():
    m,s=setup(n=4)
    a=m.address(s,allowed_target_ids={2})
    assert a.target_probs[2].item()==pytest.approx(1.0)
    assert torch.count_nonzero(a.target_probs)==1
    assert m.address(s,allowed_source_ids={1,3}).source_probs[0].item()==0
    # Empty application policy prevents contact even when it has positive rate.
    out=ReferenceBernoulliRuntime(m).advance(s,.8,allowed_target_ids=set())
    assert out.contact is None
    assert out.address is None


def test_address_changes_from_current_state_without_new_input():
    m,s=setup()
    a=m.address(s).target_probs
    z=m.evolve(s,.6)
    b=m.address(z).target_probs
    assert (a-b).norm()>1e-7


def test_observer_is_effective_not_just_stored():
    m,s=setup()
    v=m.observe(s)
    t=m.observe(replace(s,observer=s.observer+torch.ones_like(s.observer)))
    assert (v-t).norm()>1e-6
    assert (m.address(s).target_probs-m.address(replace(s,observer=s.observer+torch.ones_like(s.observer))).target_probs).norm()>1e-8


def test_training_gradient_to_address_and_law():
    m,s=setup()
    a=m.address(s)
    loss=-a.target_probs[3].log()
    loss.backward()
    assert sum(p.grad.abs().sum().item() for p in m.target_query.parameters() if p.grad is not None)>0
    assert m.seed_law.weight.grad is not None
    assert m.seed_law.weight.grad.abs().sum()>0


def test_no_hidden_info_from_identical_state_and_input():
    m,s=setup()
    z=m.evolve(s,.3)
    z2=m.evolve(s.clone(),.3)
    assert torch.equal(z.units,z2.units)
    assert torch.equal(m.observe(z),m.observe(z2))


def test_zero_dt_identity_and_validate():
    m,s=setup()
    a=ReferenceBernoulliRuntime(m).advance(s,0)
    assert a.contact is None
    assert torch.equal(a.state.units,s.units)
    a.state.validate()
    with pytest.raises(ValueError):m.evolve(s,-.01)


def test_relation_compaction_does_not_force_archive():
    m,s=setup()
    with torch.no_grad():
        m.rewrite[-1].weight[-1].zero_()
        m.rewrite[-1].bias[-1].fill_(1.)
    s=m.contact(s,0,1)
    z=replace(s,relation_mass=torch.zeros_like(s.relation_mass))
    w=m.compact(z)
    assert not w.edges
    assert torch.equal(w.units,z.units)
    assert torch.equal(w.laws,z.laws)


def test_local_cue_not_broadcast_into_unrelated_unit_flow():
    m,s=setup()
    a=m.evolve(s,.1)
    b=m.evolve(s,.1,local_cues={s.ids[0]:torch.randn(m.d)})
    assert (a.units[0]-b.units[0]).norm()>1e-7
    assert torch.equal(a.units[1:],b.units[1:])


def test_event_counts_not_forced_from_n(n=4):
    m,s=setup(n=n)
    # 1 address per step, N scores each; no N(N-1) event catalogue
    for k in (2,8,20):
        p=m.introduce(m.blank(),torch.randn(k,m.d))
        a=m.address(p)
        assert a.units_seen==k
        assert a.source_logits.numel()+a.target_logits.numel()==2*k


def test_soft_contact_trains_selection_without_pair_supervision():
    m,s=setup()
    before=s.units.clone()
    z=m.soft_contact(s,external=torch.randn(m.d))
    assert (before-z.units).norm()>1e-7
    # Ordinary state-outcome error reaches address query parameters.
    loss=(z.units[3]**2).sum()
    loss.backward()
    assert any(p.grad is not None and p.grad.abs().sum()>0 for p in m.target_query.parameters())
    assert z.edges==s.edges  # no silent discrete structure mutation


def test_runtime_trajectory_likelihood_can_train_rate():
    m,s=setup()
    gen=torch.Generator().manual_seed(88)
    result=ReferenceBernoulliRuntime(m).advance(s,.4,generator=gen)
    result.log_probability.backward()
    assert any(p.grad is not None and p.grad.abs().sum()>0 for p in m.contact_rate.parameters())


def test_existing_relation_state_changes_future_addressing():
    m,s=setup()
    with torch.no_grad():
        m.rewrite[-1].weight[-1].zero_()
        m.rewrite[-1].bias[-1].fill_(1.)
    s=m.contact(s,0,2)
    assert s.edges
    from dataclasses import replace
    other=replace(s,relations=s.relations+5.)
    assert (m.address(s).target_probs-m.address(other).target_probs).norm()>1e-8


def test_event_clock_is_replaceable_not_mandatory_core():
    from runtimes import ExternalTriggerRuntime
    m,s=setup()
    assert not hasattr(m,'advance')
    t=ExternalTriggerRuntime(m).advance(s,.2,contacts=())
    assert torch.equal(t.units,m.evolve(s,.2).units)
    with_contact=ExternalTriggerRuntime(m).advance(s,.2,contacts=[(0,2)])
    assert (t.units-with_contact.units).norm()>1e-7


def test_current_relation_changes_contact_effect_without_autonomous_messages():
    m,s=setup()
    with torch.no_grad():
        m.rewrite[-1].weight[-1].zero_()
        m.rewrite[-1].bias[-1]=1.
    s=m.contact(s,0,1)
    other=replace(s,relations=s.relations+1.0)
    a=m.contact(s,2,3)
    b=m.contact(other,2,3)
    assert (a.units-b.units).norm()>1e-8
    assert torch.equal(m.evolve(s,.1).units,m.evolve(other,.1).units)
