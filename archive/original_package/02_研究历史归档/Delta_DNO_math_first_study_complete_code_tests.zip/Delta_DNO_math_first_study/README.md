# Delta-first DNO — mathematical-contract research implementation

**Scope:** an independently runnable experimental DNO computation kernel and cross-version audit, **not** a proven complete implementation of Delta's open mathematical theory. The existing v0 and v4 sources are copied byte-for-byte under `reference_v0/` and `reference_v4/`. Previous files elsewhere were not modified.

## What actually changed

- `delta_core.py`: variable-size current-state units, boundaries, local effective laws, clocks, stable IDs, directed relations with support mass, and a current observer. Autonomous flows carry state forward without replaying past events.
- `address(...)`: trainable source/target *addresses* from the CURRENT state; one query computes `O(N+E)` key work, not the Cartesian product of all pairs. Existing relation content causally influences addresses through incident relation features; it does **not** continuously transmit unit messages.
- `contact(...)`: one shared generic rewrite of the two selected current entities, their local laws and optionally their persistent relation. Persistent link writing is not forced; it depends on the nonnegative learned relation mass. No named event type catalogue is used.
- `soft_contact(...)`: differentiable relaxation, **not** the exact expected trajectory of sampled contact. Suitable for training and analysis; creates no discrete link.
- `runtimes.py`: **optional** Bernoulli time-grid and externally triggered runners. `DeltaCore` contains no mandatory contact scheduler; finite execution semantics still exist in each runtime.
- `training.py`: two *applications*, neither hardwired into the kernel: outcome-only directed pair retrieval, and a 5-symbol delayed-recall adapter. No special memory anchor, event-type label, or relation pair label is used for training the retrieval models.
- `tests/`: math-first counterfactuals, expected-failure/limit checks, proper code behavior tests.
- `checkpoints/`: saved weights from 3 seeds each for external-query pair learning, internal-observer-only pair learning, and delayed-recall learning (9 total).

## Files

- `delta_core.py` — full **new experimental core**
- `runtimes.py` — interchangeable example scheduling semantics
- `training.py` — application adapters and synthetic data
- `run_experiments.py` — multi-seed full experiment run, writes `results.json` and checkpoints
- `verify_checkpoints.py` — independently loads 9 saved models and tests newly sampled data
- `tests/test_core.py`, `tests/test_math_boundaries.py` — 28 current tests
- `reference_v4/dno_exposure.py`, `reference_v4/test_regression.py` — unchanged prior core reference and tests
- `reference_v0/dno.py`, `reference_v0/test_dno.py` — unchanged v0 reference and tests
- `results.json`, `training_run.log`, `checkpoint_verification.json`, `pytest_run.log`
- `REPORT_ZH.md`, `MATH_CONTRACT_ZH.md`, `QUESTION_ROUNDS_ZH.md`

## Run in a Python environment with PyTorch and pytest

```bash
python -m pytest -q tests
python -m pytest -q reference_v4/test_regression.py   # from reference_v4/ or with PYTHONPATH=reference_v4
python -m pytest -q reference_v0/test_dno.py          # from reference_v0/ or with PYTHONPATH=reference_v0
python verify_checkpoints.py
python run_experiments.py
```

Recommended from the package root:

```bash
PYTHONPATH=. pytest -q tests
(cd reference_v4 && PYTHONPATH=. pytest -q test_regression.py)
(cd reference_v0 && PYTHONPATH=. pytest -q test_dno.py)
PYTHONPATH=. python verify_checkpoints.py
PYTHONPATH=. python run_experiments.py
```

For a minimal application:

```python
import torch
from delta_core import DeltaCore
from runtimes import ReferenceBernoulliRuntime

core = DeltaCore(d=16)
state = core.introduce(core.blank(), torch.randn(4, 16))
state = core.evolve(state, 0.1)  # no external input needed
address = core.address(state)    # one learned, state-dependent source/target query
next_step = ReferenceBernoulliRuntime(core).advance(state, 0.1)
state = next_step.state
state.validate()
```

## Important mathematical limits

The code does **not** prove the Delta universal generative operator, exact dynamic reachability, arbitrary self-invention of mathematical primitives, learned open-ended unit individuation, guaranteed meaningful memory anchors, unconstrained scalability, or better energy efficiency than Transformers. Contact and rewriting are still finite computational primitives; an optional runtime still chooses a time discretization. Exact domain prohibitions require an application policy/mask. A no-exposure contact can occur in a random untrained model; that is not learned discovery or useful organization.

The `reference_v4` source SHA-256 used for verification is `41d5813f36b1e83ac1f7db1c0fa3f8d51a56bd6cc0f5e854b78b91a45299cabe`.
