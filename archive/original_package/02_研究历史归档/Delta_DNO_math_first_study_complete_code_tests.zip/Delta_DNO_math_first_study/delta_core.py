"""Delta-first DNO research kernel. NOT a universal proof of Delta mathematics.

A generic operator for finite current states:
  autonomous local flow -> learned addressing over the CURRENT units
  -> optionally executed single contact -> generic shared-law state rewrite.

No EVENT_KINDS table; no pairwise candidate enumeration; no globally competing
birth/death/contact/composition event catalogue. Unit introduction and retirement
are explicit environment interfaces (not endogenous discovery). Contacts may be
transient; a persistent relation is written only when the learned persistence
amplitude is nonzero. State stores no event history or special memory anchors.

Irreducible executable semantics remain: tensor dimensions, shared MLPs,
learned addressing, time discretization, generic writes, and ReLU support mass.
The optional Bernoulli contact sampler lives OUTSIDE the core in runtimes.py.
These are architectural assumptions, not general theorems and not fully
mutable primitive mathematics.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from typing import Mapping, Optional
import math

import torch
from torch import nn, Tensor
import torch.nn.functional as F


@dataclass(frozen=True)
class State:
    units: Tensor             # N,D
    boundaries: Tensor        # N,B
    laws: Tensor              # N,L — current effective local law
    clocks: Tensor            # N,1
    ids: tuple[int, ...]
    next_id: int
    edges: tuple[tuple[int, int], ...]  # directed STABLE unit IDs
    relations: Tensor         # E,R
    relation_laws: Tensor     # E,L
    relation_clocks: Tensor   # E,1
    relation_mass: Tensor     # E,1 — nonnegative current support
    observer: Tensor          # D — current observer perspective, not log
    t: float = 0.0

    def detach(self) -> 'State':
        keys = ('units','boundaries','laws','clocks','relations','relation_laws',
                'relation_clocks','relation_mass','observer')
        return replace(self, **{k:getattr(self,k).detach() for k in keys})

    def clone(self) -> 'State':
        keys = ('units','boundaries','laws','clocks','relations','relation_laws',
                'relation_clocks','relation_mass','observer')
        return replace(self, **{k:getattr(self,k).clone() for k in keys})

    def validate(self) -> None:
        n,d = self.units.shape
        e = len(self.edges)
        if (len(self.ids) != n or len(set(self.ids)) != n or
            self.boundaries.size(0)!=n or self.laws.size(0)!=n or self.clocks.shape!=(n,1) or
            self.relations.size(0)!=e or self.relation_laws.size(0)!=e or
            self.relation_clocks.shape!=(e,1) or self.relation_mass.shape!=(e,1)):
            raise ValueError('inconsistent current-state tensor shapes')
        if len(set(self.edges))!=e or any(a not in self.ids or b not in self.ids for a,b in self.edges):
            raise ValueError('invalid or duplicate relation identity')
        if self.observer.shape!=(d,):
            raise ValueError('observer dimension mismatch')
        if (self.relation_mass < 0).any():
            raise ValueError('negative relation support')
        for key in ('units','boundaries','laws','clocks','relations','relation_laws',
                    'relation_clocks','relation_mass','observer'):
            if not torch.isfinite(getattr(self,key)).all():
                raise ValueError(f'nonfinite {key}')


@dataclass(frozen=True)
class Address:
    source_logits: Tensor
    target_logits: Tensor
    source_probs: Tensor
    target_probs: Tensor
    rate: Tensor
    units_seen: int


class DeltaCore(nn.Module):
    def __init__(self, d: int=16, b: int=6, l: int=6, r: int=8, hidden: int=40):
        super().__init__()
        if min(d,b,l,r,hidden)<=0:
            raise ValueError('all dimensions positive')
        self.d,self.b,self.l,self.r,self.hidden=d,b,l,r,hidden
        self.seed_bound = nn.Linear(d,b)
        self.seed_law = nn.Linear(d,l)
        self.local_flow = self.mlp(d+b+l+1+d, d+b+l, hidden)
        self.rel_flow = self.mlp(r+l+1,r+l+1,hidden)
        self.observer_flow = self.mlp(d+d+d, d,hidden)
        self.unit_key = self.mlp(d+b+l+1, hidden,hidden)
        self.outgoing_relation_key = nn.Linear(r+l,hidden,bias=False)
        self.incoming_relation_key = nn.Linear(r+l,hidden,bias=False)
        self.source_query = self.mlp(d+hidden+d,hidden,hidden)
        self.target_query = self.mlp(d+hidden+d+hidden,hidden,hidden)
        self.contact_rate = self.mlp(d+hidden+d+hidden+hidden,1,hidden)
        self.rewrite = self.mlp(2*(d+b+l)+d+hidden, 2*(d+b+l)+r+l+1,hidden)
        self.obs_query = nn.Linear(d+d,hidden)
        self.obs_out = nn.Linear(hidden+d, d)

    @staticmethod
    def mlp(ni:int,no:int,nh:int)->nn.Sequential:
        return nn.Sequential(nn.Linear(ni,nh),nn.Tanh(),nn.Linear(nh,no))

    def blank(self, *, device=None)->State:
        if device is not None and torch.device(device)!=next(self.parameters()).device:
            raise ValueError('move model.to(device) first')
        z = next(self.parameters()).new_zeros
        return State(z((0,self.d)),z((0,self.b)),z((0,self.l)),z((0,1)),
                     (),0,(),z((0,self.r)),z((0,self.l)),z((0,1)),z((0,1)),
                     z((self.d,)),0.0)

    def introduce(self,s:State,features:Tensor)->State:
        """Environment exposes independent current units; no mandatory origin story."""
        if features.ndim==1:
            features=features[None,:]
        if features.ndim!=2 or features.shape[1]!=self.d:
            raise ValueError(f'features must be [N,{self.d}]')
        if features.device != s.units.device:
            raise ValueError('device mismatch')
        k=features.size(0)
        if not k:return s
        z=torch.zeros((k,1),dtype=features.dtype,device=features.device)
        ns=replace(s,units=torch.cat((s.units,features),0),
                boundaries=torch.cat((s.boundaries,torch.tanh(self.seed_bound(features))),0),
                laws=torch.cat((s.laws,torch.tanh(self.seed_law(features))),0),
                clocks=torch.cat((s.clocks,z),0),
                ids=s.ids+tuple(range(s.next_id,s.next_id+k)),next_id=s.next_id+k)
        return ns

    def retire(self,s:State,unit_id:int)->State:
        """Explicit environment exit; references are stable IDs, not row indices."""
        if unit_id not in s.ids:
            raise KeyError(unit_id)
        keep=[i for i,uid in enumerate(s.ids) if uid!=unit_id]
        nkeep=[e for e,(a,b) in enumerate(s.edges) if a!=unit_id and b!=unit_id]
        return replace(s,units=s.units[keep],boundaries=s.boundaries[keep],
                       laws=s.laws[keep],clocks=s.clocks[keep],
                       ids=tuple(s.ids[i] for i in keep),
                       edges=tuple(s.edges[j] for j in nkeep),
                       relations=s.relations[nkeep],relation_laws=s.relation_laws[nkeep],
                       relation_clocks=s.relation_clocks[nkeep],relation_mass=s.relation_mass[nkeep])

    def _input(self,s:State,external:Optional[Tensor])->Tensor:
        if external is None:return s.observer.new_zeros(self.d)
        if external.shape != (self.d,) or external.device!=s.units.device:
            raise ValueError(f'external must be [{self.d}] on model device')
        return external

    def _effective_unit(self,s:State)->Tensor:
        return torch.cat((s.units,s.boundaries,s.laws,s.clocks),-1)

    def _keys(self,s:State)->Tensor:
        """Current unit keys, conditioned by CURRENT incident relations, O(N+E).

        Evaluated only during observation/address/contact. No relation-to-unit
        messages in autonomous flow. A relation with zero mass adds no context.
        """
        k=self.unit_key(self._effective_unit(s))
        if not s.edges:return k.tanh()
        idx={identity:i for i,identity in enumerate(s.ids)}
        src=torch.tensor([idx[a] for a,b in s.edges],device=k.device)
        dst=torch.tensor([idx[b] for a,b in s.edges],device=k.device)
        rel=torch.cat((s.relations,s.relation_laws),-1)*s.relation_mass
        extra=torch.zeros_like(k)
        extra=extra.index_add(0,src,self.outgoing_relation_key(rel))
        extra=extra.index_add(0,dst,self.incoming_relation_key(rel))
        return torch.tanh(k+extra)

    def evolve(self,s:State,dt:float,*,external:Optional[Tensor]=None,
               local_cues:Optional[Mapping[int,Tensor]]=None)->State:
        """Simultaneous Euler local flow. No implicit relation -> unit messages."""
        if not math.isfinite(dt) or dt<0:raise ValueError('dt must be finite and nonnegative')
        if dt==0:return s
        x=self._input(s,external)
        n=s.units.size(0)
        if n:
            cues=torch.stack([local_cues.get(i,x) if local_cues is not None else x for i in s.ids])
            if cues.shape!=(n,self.d):raise ValueError('cue dimension')
            inp=torch.cat([s.units,s.boundaries,s.laws,s.clocks,cues],-1)
            du,db,dl=torch.split(torch.tanh(self.local_flow(inp)),(self.d,self.b,self.l),-1)
            units=s.units+dt*du; bounds=s.boundaries+dt*db; laws=s.laws+dt*dl
            times=s.clocks+s.clocks.new_full((n,1),dt)
        else:
            units,bounds,laws,times=s.units,s.boundaries,s.laws,s.clocks
        e=len(s.edges)
        if e:
            ri=torch.cat([s.relations,s.relation_laws,s.relation_clocks],-1)
            dr,dl,dm=torch.split(self.rel_flow(ri),(self.r,self.l,1),-1)
            rel=s.relations+dt*torch.tanh(dr)
            rel_l=s.relation_laws+dt*torch.tanh(dl)
            mass=F.relu(s.relation_mass+dt*torch.tanh(dm))
            rt=s.relation_clocks+s.relation_clocks.new_full((e,1),dt)
        else:
            rel,rel_l,mass,rt=s.relations,s.relation_laws,s.relation_mass,s.relation_clocks
        # Global observation exists, but has no backdoor into autonomous unit flow.
        summary=units.mean(0) if n else s.observer.new_zeros(self.d)
        o=s.observer+dt*torch.tanh(self.observer_flow(torch.cat([s.observer,summary,x])))
        return replace(s,units=units,boundaries=bounds,laws=laws,clocks=times,
                       relations=rel,relation_laws=rel_l,relation_clocks=rt,
                       relation_mass=mass,observer=o,t=s.t+dt)

    def address(self,s:State,*,external:Optional[Tensor]=None,
                allowed_source_ids:Optional[set[int]]=None,
                allowed_target_ids:Optional[set[int]]=None)->Address:
        """One learned source/target query over N current units: O(N), not O(N^2).

        An optional application policy may mask any IDs. No model is forced to
        use a particular domain policy. No target-pair candidate generator.
        """
        if not s.ids:raise ValueError('cannot address empty state')
        x=self._input(s,external)
        k=self._keys(s)  # [N,H]
        summary=k.mean(0)
        sq=self.source_query(torch.cat((s.observer,summary,x))).tanh()
        ss=(k*sq).sum(-1)/math.sqrt(self.hidden)
        if allowed_source_ids is not None:
            mask=torch.tensor([uid in allowed_source_ids for uid in s.ids],device=ss.device)
            if not bool(mask.any()):raise ValueError('empty source policy')
            ss=ss.masked_fill(~mask,-torch.inf)
        sp=ss.softmax(-1)
        source=(sp[:,None]*k).sum(0)
        tq=self.target_query(torch.cat((s.observer,summary,x,source))).tanh()
        ts=(k*tq).sum(-1)/math.sqrt(self.hidden)
        if allowed_target_ids is not None:
            mask=torch.tensor([uid in allowed_target_ids for uid in s.ids],device=ts.device)
            if not bool(mask.any()):raise ValueError('empty target policy')
            ts=ts.masked_fill(~mask,-torch.inf)
        tp=ts.softmax(-1)
        target=(tp[:,None]*k).sum(0)
        rate=F.softplus(self.contact_rate(torch.cat((s.observer,summary,x,source,target))))[0]
        return Address(ss,ts,sp,tp,rate,len(s.ids))

    def address_batch(self,features:Tensor,queries:Tensor,
                      observers:Optional[Tensor]=None)->tuple[Tensor,Tensor,Tensor]:
        """Exact shared addressing rule applied to a batch of independent states.

        Used by training adapters; no candidate pairs or relation labels are
        supplied. Features are unmodified environment-exposed units [B,N,D].
        Returns source distribution, target distribution, contact rates.
        """
        if features.ndim!=3 or features.shape[-1]!=self.d or queries.shape!=(features.size(0),self.d):
            raise ValueError('features [B,N,D], queries [B,D] required')
        b,n,_=features.shape
        if not n:raise ValueError('nonempty unit set required')
        o=features.new_zeros((b,self.d)) if observers is None else observers
        if o.shape!=(b,self.d):raise ValueError('observers [B,D] required')
        bound=torch.tanh(self.seed_bound(features))
        laws=torch.tanh(self.seed_law(features))
        clocks=features.new_zeros((b,n,1))
        k=self.unit_key(torch.cat((features,bound,laws,clocks),-1)).tanh()
        summary=k.mean(-2)
        sq=self.source_query(torch.cat((o,summary,queries),-1)).tanh()
        ss=(k*sq[:,None,:]).sum(-1)/math.sqrt(self.hidden)
        sp=ss.softmax(-1)
        source=(sp[...,None]*k).sum(-2)
        tq=self.target_query(torch.cat((o,summary,queries,source),-1)).tanh()
        ts=(k*tq[:,None,:]).sum(-1)/math.sqrt(self.hidden)
        tp=ts.softmax(-1)
        target=(tp[...,None]*k).sum(-2)
        rate=F.softplus(self.contact_rate(torch.cat((o,summary,queries,source,target),-1)))[...,0]
        return sp,tp,rate

    def soft_contact(self,s:State,*,external:Optional[Tensor]=None,
                     allowed_source_ids:Optional[set[int]]=None,
                     allowed_target_ids:Optional[set[int]]=None,
                     strength:float=1.0)->State:
        """A differentiable single-packet RELAXATION for training.

        Routes a weighted interaction through current source/target addressing.
        It intentionally does NOT construct a discrete relation edge. This is
        not the exact expectation of the nonlinear sampled contact operation.
        For actual discrete contact, use contact() and an optional runtime.
        """
        if strength<0 or not math.isfinite(strength):raise ValueError('invalid strength')
        a=self.address(s,external=external,allowed_source_ids=allowed_source_ids,
                       allowed_target_ids=allowed_target_ids)
        x=self._input(s,external)
        raw=torch.cat((s.units,s.boundaries,s.laws),-1)
        source=(a.source_probs[:,None]*raw).sum(0)
        target=(a.target_probs[:,None]*raw).sum(0)
        summary=self._keys(s).mean(0)
        rewrite=self.rewrite(torch.cat((source,target,x,summary)))
        q=self.d+self.b+self.l
        ds,dt,_,_,_=torch.split(rewrite,(q,q,self.r,self.l,1))
        shifted=raw+strength*(a.source_probs[:,None]*torch.tanh(ds)[None,:]+
                              a.target_probs[:,None]*torch.tanh(dt)[None,:])
        units,boundaries,laws=torch.split(shifted,(self.d,self.b,self.l),-1)
        return replace(s,units=units,boundaries=boundaries,laws=laws)

    def contact(self,s:State,source_id:int,target_id:int,*,external:Optional[Tensor]=None)->State:
        """A generic contact rewrite, not a taxonomy of birth/death/link events.

        An executed contact may be transient: relation support can be exactly
        zero (ReLU), so relation persistence is not compulsory. Same rewrite
        network is used for existing and new directed contacts.
        """
        if source_id not in s.ids or target_id not in s.ids:
            raise KeyError('contact references a nonexistent CURRENT unit ID')
        i=s.ids.index(source_id);j=s.ids.index(target_id)
        x=self._input(s,external)
        qi=self._effective_unit(s)
        k=self._keys(s)
        c=torch.cat((s.units[i],s.boundaries[i],s.laws[i],
                     s.units[j],s.boundaries[j],s.laws[j],x,k.mean(0)))
        delta=self.rewrite(c)
        q=self.d+self.b+self.l
        dx,dy,relation_delta,law_delta,mass_logit=torch.split(delta,(q,q,self.r,self.l,1))
        dx=torch.tanh(dx);dy=torch.tanh(dy)
        # index_add handles self-contact without overwriting the first rewrite.
        idx=torch.tensor((i,j),device=s.units.device)
        raw=torch.cat((s.units,s.boundaries,s.laws),-1)
        raw2=raw.index_add(0,idx,torch.stack((dx,dy)))
        units,bounds,laws=torch.split(raw2,(self.d,self.b,self.l),-1)
        persist=F.relu(mass_logit)[0]  # no nonzero persistence forced
        pair=(source_id,target_id)
        if pair in s.edges:
            ei=s.edges.index(pair)
            # existing relationship persists in current state even if not active
            rel=s.relations.index_add(0,torch.tensor([ei],device=s.units.device),
                                      torch.tanh(relation_delta)[None,:])
            rel_l=s.relation_laws.index_add(0,torch.tensor([ei],device=s.units.device),
                                           torch.tanh(law_delta)[None,:])
            mass=s.relation_mass.index_add(0,torch.tensor([ei],device=s.units.device),
                                           persist.reshape(1,1))
            return replace(s,units=units,boundaries=bounds,laws=laws,
                           relations=rel,relation_laws=rel_l,relation_mass=mass)
        if float(persist.detach())==0.0:
            return replace(s,units=units,boundaries=bounds,laws=laws)
        return replace(s,units=units,boundaries=bounds,laws=laws,
                       edges=s.edges+(pair,),
                       relations=torch.cat((s.relations,torch.tanh(relation_delta)[None,:]),0),
                       relation_laws=torch.cat((s.relation_laws,torch.tanh(law_delta)[None,:]),0),
                       relation_clocks=torch.cat((s.relation_clocks,s.relation_clocks.new_zeros((1,1))),0),
                       relation_mass=torch.cat((s.relation_mass,persist.reshape(1,1)),0))

    def observe(self,s:State,*,external:Optional[Tensor]=None)->Tensor:
        """Task-neutral differentiable readout influenced by current observer."""
        x=self._input(s,external)
        if not s.ids:return self.obs_out(torch.cat((self.obs_query(torch.cat((s.observer,x))).tanh(),x)))
        k=self._keys(s)
        q=self.obs_query(torch.cat((s.observer,x))).tanh()
        weights=torch.softmax((k*q).sum(-1)/math.sqrt(self.hidden),-1)
        pooled=(weights[:,None]*s.units).sum(0)
        return self.obs_out(torch.cat((q,pooled)))

    def compact(self,s:State)->State:
        """Discard exact-zero relation support, an optional representation GC.
        Not a periodic forgetting or learned time-to-live algorithm.
        """
        keep=[i for i,v in enumerate(s.relation_mass.detach().flatten()) if float(v)>0]
        return replace(s,edges=tuple(s.edges[i] for i in keep),
                       relations=s.relations[keep],relation_laws=s.relation_laws[keep],
                       relation_clocks=s.relation_clocks[keep],relation_mass=s.relation_mass[keep])
