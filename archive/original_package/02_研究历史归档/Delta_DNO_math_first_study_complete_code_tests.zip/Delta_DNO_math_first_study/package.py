"""Package a self-contained, SHA-256 checked research archive."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT.parent/(ROOT.name+'_complete_code_tests.zip')
EXCLUDE={'__pycache__','.pytest_cache'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and not set(p.relative_to(ROOT).parts)&EXCLUDE and p.name!='manifest.json')
items=[{'file':str(p.relative_to(ROOT)),
        'size':p.stat().st_size,
        'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest={'project':ROOT.name,'purpose':'math-first finite DNO study',
          'reference_v4_sha256':'41d5813f36b1e83ac1f7db1c0fa3f8d51a56bd6cc0f5e854b78b91a45299cabe',
          'files':items}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as out:
    for p in files+[ROOT/'manifest.json']:
        out.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT)}')
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    for entry in items:
        data=z.read(f'{ROOT.name}/{entry["file"]}')
        assert hashlib.sha256(data).hexdigest()==entry['sha256']
print('ARCHIVE:',ARCHIVE,'bytes:',ARCHIVE.stat().st_size,'files:',len(files)+1,'zip and hash checks passed')
