import torch, time
import torch.nn.functional as F
from delta_core import DeltaCore

torch.set_num_threads(1)
K=8;D=16

def batch(B=128,N=5,noise=.05,device='cpu'):
    keys=torch.rand(B,K).argsort(-1)[:,:N]
    vals=torch.randint(0,2,(B,N)).float()*2-1
    querypos=torch.randint(0,N,(B,))
    qrykey=keys[torch.arange(B),querypos]
    feat=torch.zeros(B,N,D)
    feat[:,:,:K]=F.one_hot(keys,K).float()
    feat[:,:,K]=vals
    feat += torch.randn_like(feat)*noise
    query=torch.zeros(B,D)
    query[:,:K]=F.one_hot(qrykey,K).float()
    labels=(vals[torch.arange(B),querypos]>0).float()
    return feat,query,labels,querypos


def evaluate(m,N=5,B=1000,ablation=None):
    with torch.no_grad():
        f,q,y,p=batch(B,N)
        if ablation=='no_query': q*=0
        if ablation=='shuffled_state': f=f[torch.randperm(B)]
        src,dst,rate=m.address_batch(f,q)
        logit=8*(dst*f[:,:,K]).sum(-1)
        pred=(logit>0).float()
        return (pred==y).float().mean().item(), (dst.argmax(-1)==p).float().mean().item(),rate.mean().item()

if __name__=='__main__':
    start=time.time()
    torch.manual_seed(101)
    m=DeltaCore(d=D,b=6,l=6,r=8,hidden=48)
    opt=torch.optim.Adam(m.parameters(),lr=.004)
    for step in range(601):
        f,q,y,_=batch()
        _,tp,rate=m.address_batch(f,q)
        logit=8*(tp*f[:,:,K]).sum(-1)
        loss=F.binary_cross_entropy_with_logits(logit,y)
        opt.zero_grad();loss.backward();opt.step()
        if step%100==0:
            print('step',step,'loss',round(loss.item(),4),'metrics',evaluate(m,5,512),'N7',evaluate(m,7,512),'time',round(time.time()-start,1),flush=True)
    for key in ('no_query','shuffled_state'):
        print(key,evaluate(m,5,2048,key))
