import torch, torch.nn.functional as F, time
from torch import nn
from delta_core import DeltaCore

torch.set_num_threads(1)

def sample(b=64,k=3):
  y=torch.randint(0,2,(b,))
  steps=[y]+[torch.randint(2,4,(b,)) for _ in range(k)]+[torch.full((b,),4,dtype=torch.long)]
  return torch.stack(steps,1),y

class Model(nn.Module):
 def __init__(self):
  super().__init__();self.core=DeltaCore(d=16,b=6,l=6,r=8,hidden=48)
  self.embedding=nn.Embedding(5,16)
  self.head=nn.Linear(16,2)
 def forward(self,seq):
  b,l=seq.shape
  s=self.core.introduce(self.core.blank(),self.embedding.weight[0].new_zeros((b,16)))
  x=self.embedding(seq)
  for t in range(l):
   cues={i:x[i,t] for i in range(b)}
   s=self.core.evolve(s,.65,local_cues=cues)
  return self.head(s.units)

def evaluate(m,k,b=512,ablation=None):
 with torch.no_grad():
  seq,y=sample(b,k)
  if ablation=='no_history':seq=seq[:,-1:]
  if ablation=='shuffle_first':seq[:,0]=seq[torch.randperm(b),0]
  scores=m(seq)
  return (scores.argmax(-1)==y).float().mean().item()

if __name__=='__main__':
 st=time.time();torch.manual_seed(41)
 m=Model();opt=torch.optim.Adam(m.parameters(),lr=.005)
 for i in range(501):
  seq,y=sample();scores=m(seq)
  loss=F.cross_entropy(scores,y)
  opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),3.);opt.step()
  if i%100==0:print(i,round(loss.item(),4),'eval',evaluate(m,3),evaluate(m,7),'time',round(time.time()-st,1),flush=True)
 for ab in ('no_history','shuffle_first'):
  print(ab,evaluate(m,3,512,ab))
