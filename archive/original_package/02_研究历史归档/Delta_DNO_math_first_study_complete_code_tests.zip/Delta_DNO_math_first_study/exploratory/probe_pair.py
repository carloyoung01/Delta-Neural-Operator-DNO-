import torch,torch.nn.functional as F,time
from delta_core import DeltaCore

torch.set_num_threads(1)
K=8;D=20

def batch(B=128,N=5):
 keys=torch.rand(B,K).argsort(-1)[:,:N]
 vals=torch.randn(B,N)
 src=torch.randint(0,N,(B,));dst=(src+torch.randint(1,N,(B,)))%N
 feature=torch.zeros(B,N,D)
 feature[:,:,:K]=F.one_hot(keys,K).float()
 feature[:,:,16]=vals
 feature+=.025*torch.randn_like(feature)
 q=torch.zeros(B,D)
 q[:,:K]=F.one_hot(keys[torch.arange(B),src],K).float()
 q[:,K:2*K]=F.one_hot(keys[torch.arange(B),dst],K).float()
 label=vals[torch.arange(B),src]-vals[torch.arange(B),dst]
 return feature,q,label,src,dst

def eval(m,N=5,B=1024,ab=None):
 with torch.no_grad():
  a,q,l,src,dst=batch(B,N)
  if ab=='zero_query':q*=0
  if ab=='shuffle_input':a=a[torch.randperm(B)]
  sp,tp,_=m.address_batch(a,q)
  pred=(sp*a[:,:,16]).sum(-1)-(tp*a[:,:,16]).sum(-1)
  return F.mse_loss(pred,l).item(),(sp.argmax(-1)==src).float().mean().item(),(tp.argmax(-1)==dst).float().mean().item()

if __name__=='__main__':
 torch.manual_seed(88);m=DeltaCore(d=D,b=6,l=6,r=8,hidden=48)
 opt=torch.optim.Adam(m.parameters(),lr=.004)
 st=time.time()
 for i in range(801):
  f,q,label,_,_=batch()
  sp,tp,_=m.address_batch(f,q)
  pred=(sp*f[:,:,16]).sum(-1)-(tp*f[:,:,16]).sum(-1)
  loss=F.mse_loss(pred,label)
  opt.zero_grad();loss.backward();opt.step()
  if i%100==0:print(i,round(loss.item(),4),eval(m,5,512),eval(m,7,512),'time',round(time.time()-st,1),flush=True)
 print('zero_query',eval(m,5,1024,'zero_query'));print('shuffle_input',eval(m,5,1024,'shuffle_input'))
