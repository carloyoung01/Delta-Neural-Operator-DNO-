"""Chinese labels are an APPLICATION ADAPTER, not learned language semantics.

甲/乙 are labels for symbol classes 0/1; 干扰甲/干扰乙 denote tokens 2/3,
提问 denotes token 4. This is a delayed-symbol experiment, NOT Chinese QA.
"""
from pathlib import Path
import torch
from training import SymbolTask,PAIR_DIM,make_pair_batch
from delta_core import DeltaCore
from dataclasses import replace

HERE=Path(__file__).resolve().parent

def symbols():
    saved=torch.load(HERE/'checkpoints/history_41.pt',weights_only=True,map_location='cpu')
    m=SymbolTask().eval();m.load_state_dict(saved['state_dict'])
    for start in (0,1):
        ids=torch.tensor([[start,2,3,2,4]],dtype=torch.long)
        text={0:'甲',1:'乙',2:'干扰甲',3:'干扰乙',4:'提问'}
        with torch.no_grad():prediction=m(ids).argmax(-1).item()
        print('输入:', ' '.join(text[i] for i in ids[0].tolist()), '→ 预测首项:', text[prediction])


def endogenous_pair():
    saved=torch.load(HERE/'checkpoints/internal_141.pt',weights_only=True,map_location='cpu')
    m=DeltaCore(**saved['config']).eval();m.load_state_dict(saved['state_dict'])
    torch.manual_seed(1234)
    f,q,_,source,target=make_pair_batch(1,5)
    with torch.no_grad():
        s=m.introduce(m.blank(),f[0])
        # A previous input has become part of CURRENT state.
        s=replace(s,observer=q[0])
        a=m.address(s,external=None)
        print('当前状态内生双端寻址：预期',int(source.item()),int(target.item()),
              '计算',a.source_probs.argmax().item(),a.target_probs.argmax().item())

if __name__=='__main__':
    symbols();endogenous_pair()
