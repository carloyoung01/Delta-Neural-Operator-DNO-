"""Run the reproducible math-first falsification/learning study, CPU-friendly."""
import json,hashlib,subprocess,sys,time,copy
from pathlib import Path
from dataclasses import replace
import torch
from delta_core import DeltaCore
from runtimes import ReferenceBernoulliRuntime
from training import train_pair,train_history,make_pair_batch

HERE=Path(__file__).resolve().parent
OLD=HERE/'reference_v4'/'dno_exposure.py'

def independent_checks():
    rows=[]
    for seed in range(32):
        torch.manual_seed(seed)
        m=DeltaCore(d=12,b=4,l=5,r=6,hidden=24)
        s=m.introduce(m.blank(),torch.randn(4,12))
        s.validate()
        # current boundary and law intervention
        b=m.evolve(replace(s,boundaries=s.boundaries+1),.2)
        l=m.evolve(replace(s,laws=s.laws+1),.2)
        control=m.evolve(s,.2)
        before=m.address(s).target_probs
        after=m.address(control).target_probs
        # Preserve an untouched, untrained model for the stochastic discovery
        # check. The intervention below must NOT leak into that experiment.
        sample_m=copy.deepcopy(m)
        # Ensure a current relation exists for a controlled counterfactual.
        with torch.no_grad():
            m.rewrite[-1].weight[-1].zero_();m.rewrite[-1].bias[-1]=1.
        with_rel=m.contact(s,0,2)
        without=replace(with_rel,edges=(),relations=with_rel.relations[:0],
            relation_laws=with_rel.relation_laws[:0],
            relation_clocks=with_rel.relation_clocks[:0],
            relation_mass=with_rel.relation_mass[:0])
        c1=m.evolve(with_rel,.2);c2=m.evolve(without,.2)
        rel_edit=replace(with_rel,relations=with_rel.relations+1.)
        rel_addr=float((m.address(with_rel).target_probs-m.address(rel_edit).target_probs).norm().detach())
        gen=torch.Generator().manual_seed(seed+9000)
        fresh=sample_m.introduce(sample_m.blank(),torch.randn(4,12))
        run=ReferenceBernoulliRuntime(sample_m).advance(fresh,2.,generator=gen)
        run.state.validate()
        rows.append({
          'seed':seed,'unit_boundary_effect':float((control.units-b.units).norm().detach()),
          'unit_law_effect':float((control.units-l.units).norm().detach()),
          'endogenous_address_change':float((before-after).norm().detach()),
          'relation_no_contact_unit_effect':float((c1.units-c2.units).norm().detach()),
          'relation_state_effect_on_next_address':rel_addr,
          'contact_executed_without_exposure':run.contact is not None,
          'new_relation_created_without_exposure':bool(run.state.edges),
          'contact_probability':run.contact_probability,
          'rate_logprob_grad_possible':bool(run.log_probability.requires_grad),
        })
    return {'raw':rows,'summary':{
        'seeds':len(rows),
        'boundary_effect_count':sum(v['unit_boundary_effect']>1e-8 for v in rows),
        'law_effect_count':sum(v['unit_law_effect']>1e-8 for v in rows),
        'address_changed_without_external_count':sum(v['endogenous_address_change']>1e-9 for v in rows),
        'relation_dormant_no_unit_message_count':sum(v['relation_no_contact_unit_effect']==0 for v in rows),
        'existing_relation_affects_address_count':sum(v['relation_state_effect_on_next_address']>1e-9 for v in rows),
        'no_exposure_contact_count':sum(v['contact_executed_without_exposure'] for v in rows),
        'no_exposure_persistent_relation_count':sum(v['new_relation_created_without_exposure'] for v in rows)}}


def sample_trained_contacts(m:DeltaCore,seed:int,trials:int=120,mode:str='external'):
    """Trained source/target from outcome-only task; runtime still stochastic."""
    torch.manual_seed(seed+10000)
    out={'trials':trials,'contact_events':0,'correct_source_on_contact':0,
         'correct_target_on_contact':0,'persisted_new_relations':0}
    runtime=ReferenceBernoulliRuntime(m)
    gen=torch.Generator().manual_seed(seed+30000)
    with torch.no_grad():
        for _ in range(trials):
            f,q,_,src,dst=make_pair_batch(1,5)
            s=m.introduce(m.blank(),f[0])
            if mode=='internal_observer':
                s=replace(s,observer=q[0].clone())
                inp=None
            else:
                inp=q[0]
            res=runtime.advance(s,2.,external=inp,generator=gen)
            if res.contact is not None:
                out['contact_events']+=1
                out['correct_source_on_contact']+=int(res.contact[0]==int(src.item()))
                out['correct_target_on_contact']+=int(res.contact[1]==int(dst.item()))
                out['persisted_new_relations']+=bool(res.state.edges)
    return out


def main():
    torch.set_num_threads(1)
    t0=time.time()
    seeds=[41,73,109]
    result={'metadata':{'date':'2026-11-16','torch':torch.__version__,
                        'principle':'math-contract-first; baseline frozen',
                        'reference_v4_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest()},
            'controlled_falsification':independent_checks(),'pair_outcome_only':[],
            'history_without_anchor_labels':[],
            'internal_state_only_pair':[]}
    (HERE/'checkpoints').mkdir(exist_ok=True)
    for seed in seeds:
        m,stat=train_pair(seed,steps=700)
        stat['sampled_contacts']=sample_trained_contacts(m,seed)
        result['pair_outcome_only'].append(stat)
        torch.save({'state_dict':m.state_dict(),'config':dict(d=20,b=6,l=6,r=8,hidden=48),
                    'seed':seed},HERE/'checkpoints'/f'pair_{seed}.pt')
        print('pair',seed,stat['after'],stat['sampled_contacts'],flush=True)
    for seed in [141,157,171]:
        m,stat=train_pair(seed,steps=650,mode='internal_observer')
        stat['sampled_contacts']=sample_trained_contacts(m,seed,mode='internal_observer')
        result['internal_state_only_pair'].append(stat)
        torch.save({'state_dict':m.state_dict(),'config':dict(d=20,b=6,l=6,r=8,hidden=48),
                    'seed':seed,'mode':'internal_observer'},
                   HERE/'checkpoints'/f'internal_{seed}.pt')
        print('internal',seed,stat['after'],stat['sampled_contacts'],flush=True)
    for seed in seeds:
        model,stat=train_history(seed,steps=300)
        result['history_without_anchor_labels'].append(stat)
        torch.save({'state_dict':model.state_dict(),'seed':seed},
                   HERE/'checkpoints'/f'history_{seed}.pt')
        print('history',seed,stat['after'],flush=True)
    result['metadata']['runtime_seconds']=round(time.time()-t0,2)
    (HERE/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('control summary:',result['controlled_falsification']['summary'])
    print('total seconds',round(time.time()-t0,2))

if __name__=='__main__':main()
