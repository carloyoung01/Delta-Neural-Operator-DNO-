"""Executable contract tests; run: python -m unittest discover -s tests -v"""
import unittest
import torch
import torch.nn.functional as F
from dno import DNO


class TestDNO(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        torch.manual_seed(121)

    def make_model(self):
        return DNO(vocab_size=19,slots=7,d_model=24,d_constraint=8,d_relation=8)

    def test_shape_and_finite(self):
        m=self.make_model(); x=torch.randint(0,19,(3,8))
        y,s=m(x,return_state=True)
        self.assertEqual(y.shape,(3,8,19))
        self.assertEqual(s.relations.shape,(3,7,5,8))
        for t in (y,s.h,s.boundary,s.relations,s.activity):
            self.assertTrue(torch.isfinite(t).all().item())

    def test_causal_prefix(self):
        m=self.make_model().eval()
        x=torch.randint(0,19,(2,9)); y=x.clone(); y[:,6:]=torch.randint(0,19,(2,3))
        with torch.no_grad():
            a=m(x); b=m(y)
        self.assertTrue(torch.allclose(a[:,:6],b[:,:6],atol=1e-6))

    def test_exact_continuation_from_state(self):
        m=self.make_model().eval(); x=torch.randint(0,19,(2,9))
        with torch.no_grad():
            whole,s=m(x,return_state=True)
            p,s1=m(x[:,:4],return_state=True)
            q,s2=m(x[:,4:],s1,return_state=True)
        self.assertTrue(torch.allclose(whole,torch.cat([p,q],dim=1),atol=1e-6))
        self.assertTrue(torch.allclose(s.h,s2.h,atol=1e-6))

    def test_all_trainable_families_receive_gradient(self):
        m=self.make_model(); x=torch.randint(0,19,(4,9)); y=m(x)
        loss=F.cross_entropy(y[:,:-1].reshape(-1,19),x[:,1:].reshape(-1))
        loss.backward()
        for key in ['embedding.weight','index_key.weight','autonomous.0.weight',
                    'pair_gate.0.weight','message.0.weight','relation_update.0.weight',
                    'boundary_update.0.weight','unit_gate.weight','readout.weight']:
            p=dict(m.named_parameters())[key]
            self.assertIsNotNone(p.grad,key)
            self.assertTrue(torch.isfinite(p.grad).all().item(),key)
            self.assertGreater(p.grad.abs().sum().item(),0.,key)

    def test_candidate_budget_and_changes(self):
        m=self.make_model(); s=m.initial_state(2)
        first=m.candidate_neighbors(s.h,s.boundary,0)
        later=m.candidate_neighbors(s.h,s.boundary,4)
        self.assertEqual(first.shape,(2,7,5))
        self.assertFalse(torch.equal(first,later))
        self.assertTrue(((first>=0)&(first<7)).all().item())

    def test_relation_state_perturbation_is_causal(self):
        m=self.make_model().eval(); x=torch.randint(0,19,(1,8))
        with torch.no_grad():
            _,state=m(x[:,:5],return_state=True)
            a=state.clone(); b=state.clone()
            b.relations=b.relations+0.7
            _,s1=m(x[:,5:],a,return_state=True)
            _,s2=m(x[:,5:],b,return_state=True)
        self.assertGreater((s1.h-s2.h).abs().max().item(),1e-8)

    def test_no_full_pairwise_materialization_by_contract(self):
        m=self.make_model(); s=m.initial_state(2)
        ids=m.candidate_neighbors(s.h,s.boundary,0)
        self.assertEqual(ids.numel(),2*m.slots*m.ports)
        self.assertLess(ids.numel(),2*m.slots*m.slots)

    def test_bounded_horizon_streaming(self):
        m=self.make_model().eval(); s=m.initial_state(1)
        with torch.no_grad():
            for i in range(500):
                o,s=m.step(torch.tensor([i%19]),s)
                if i%50==0:
                    for v in (o,s.h,s.boundary,s.relations,s.activity):
                        self.assertTrue(torch.isfinite(v).all().item())
        self.assertEqual(s.tick,500)

if __name__=='__main__': unittest.main()
