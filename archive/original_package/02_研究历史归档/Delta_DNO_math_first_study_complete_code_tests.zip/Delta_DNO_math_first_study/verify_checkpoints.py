"""Independent validation of saved checkpoints on freshly sampled data.

Does not rerun training or reuse training-batch examples.
"""
from pathlib import Path
import json
import torch
from delta_core import DeltaCore
from training import SymbolTask,evaluate_pair,evaluate_history

ROOT=Path(__file__).resolve().parent

def validate():
    torch.set_num_threads(1)
    records=[]
    for mode,seeds in [('external',[41,73,109]),('internal_observer',[141,157,171])]:
        for seed in seeds:
            ckname=f'pair_{seed}.pt' if mode=='external' else f'internal_{seed}.pt'
            payload=torch.load(ROOT/'checkpoints'/ckname,map_location='cpu',weights_only=True)
            m=DeltaCore(**payload['config']);m.load_state_dict(payload['state_dict']);m.eval()
            torch.manual_seed(seed+111111)
            # evaluate_pair defaults to external, but must use saved mode
            row=evaluate_pair(m,7,batch=1024,mode=mode)
            ablation=evaluate_pair(m,5,batch=1024,control='shuffled_state',mode=mode)
            assert row['source_accuracy']>.97 and row['target_accuracy']>.97, (seed,row)
            assert ablation['mse']>.8, (seed,ablation)
            records.append({'checkpoint':ckname,'mode':mode,'fresh_test':row,'control':ablation})
    for seed in [41,73,109]:
        data=torch.load(ROOT/'checkpoints'/f'history_{seed}.pt',map_location='cpu',weights_only=True)
        m=SymbolTask();m.load_state_dict(data['state_dict']);m.eval()
        torch.manual_seed(seed+222222)
        test=evaluate_history(m,14,batch=512)
        control=evaluate_history(m,3,batch=512,control='shuffle_first')
        assert test['accuracy']>.97, (seed,test)
        assert .35<control['accuracy']<.65, (seed,control)
        records.append({'checkpoint':f'history_{seed}.pt','fresh_test':test,'control':control})
    (ROOT/'checkpoint_verification.json').write_text(json.dumps(records,indent=2))
    print(f'{len(records)} checkpoint reloads and independent tests passed')
    return records

if __name__=='__main__':validate()
