"""OPTIONAL reference runtime, never a mandatory part of DeltaCore.

Use this ONLY when an application wishes to sample contacts using a
Bernoulli time grid. Other applications may choose external triggers,
other point processes, purely continuous expected interactions, etc.
"""
from dataclasses import dataclass
from typing import Mapping, Optional
import math
import torch
from torch import Tensor
from delta_core import State, Address, DeltaCore

@dataclass(frozen=True)
class Step:
    state: State
    contact: Optional[tuple[int,int]]
    contact_probability: float
    address: Optional[Address]
    log_probability: Tensor


class ReferenceBernoulliRuntime:
    def __init__(self, core:DeltaCore):
        self.core=core

    def advance(self,s:State,dt:float,*,external:Optional[Tensor]=None,
                local_cues:Optional[Mapping[int,Tensor]]=None,
                allowed_source_ids:Optional[set[int]]=None,
                allowed_target_ids:Optional[set[int]]=None,
                allow_contact:bool=True,
                generator:Optional[torch.Generator]=None)->Step:
        """Optional finite-grid Bernoulli contact execution.

        The sampled trajectory exposes a differentiable log-probability for
        REINFORCE; simply backpropagating ordinary task loss does not train
        discrete selection. This scheduler makes no universal time claim.
        """
        if dt<0 or not math.isfinite(dt):raise ValueError('invalid dt')
        # Inspect at current state; simultaneous current-state flow is independent.
        addr=None;pair=None;prob=0.0
        logp=s.observer.new_zeros(())
        if s.ids and dt>0 and allow_contact:
            try:
                addr=self.core.address(s,external=external,
                    allowed_source_ids=allowed_source_ids,
                    allowed_target_ids=allowed_target_ids)
            except ValueError as exc:
                if str(exc) not in ('empty source policy','empty target policy'):raise
            if addr is not None:
                p=-torch.expm1(-addr.rate*dt)
                prob=float(p.detach())
                if bool(torch.rand((),device=s.units.device,generator=generator)<p.detach()):
                    si=int(torch.multinomial(addr.source_probs.detach(),1,generator=generator))
                    ti=int(torch.multinomial(addr.target_probs.detach(),1,generator=generator))
                    pair=(s.ids[si],s.ids[ti])
                    logp=torch.log(p.clamp_min(1e-12))+torch.log(addr.source_probs[si])+torch.log(addr.target_probs[ti])
                else:
                    logp=torch.log1p(-p)
        next_s=self.core.evolve(s,dt,external=external,local_cues=local_cues)
        if pair is not None:
            next_s=self.core.contact(next_s,*pair,external=external)
        return Step(next_s,pair,prob,addr,logp)



class ExternalTriggerRuntime:
    """Alternative application clock: explicit contacts with NO stochastic clock.

    This is an example of an application-owned scheduler. It is not a domain
    constraint in DeltaCore and does not require any finite event kind table.
    """
    def __init__(self,core:DeltaCore):
        self.core=core

    def advance(self,s:State,dt:float,*,contacts=(),external:Optional[Tensor]=None,
                local_cues:Optional[Mapping[int,Tensor]]=None)->State:
        result=self.core.evolve(s,dt,external=external,local_cues=local_cues)
        for a,b in contacts:
            result=self.core.contact(result,a,b,external=external)
        return result
