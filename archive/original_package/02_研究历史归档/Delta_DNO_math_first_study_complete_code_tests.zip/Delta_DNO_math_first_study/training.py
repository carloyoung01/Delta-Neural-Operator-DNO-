"""Two synthetic applications; no domain vocabulary or targets inside DeltaCore.

A) Directed pair retrieval: train only on a scalar task outcome v(source)-v(target).
   Source/target indices are used to CREATE ground-truth outcomes, never given
   to the model as pair labels or losses.
B) Delayed symbolic recall: maintain only current state across input steps.
"""
import torch
from torch import nn, Tensor
import torch.nn.functional as F
from delta_core import DeltaCore

PAIR_KEYS=8
PAIR_DIM=20


def make_pair_batch(batch:int=128,n:int=5):
    keys=torch.rand(batch,PAIR_KEYS).argsort(-1)[:,:n]
    values=torch.randn(batch,n)
    source=torch.randint(0,n,(batch,))
    target=(source+torch.randint(1,n,(batch,)))%n
    features=torch.zeros(batch,n,PAIR_DIM)
    features[:,:,:PAIR_KEYS]=F.one_hot(keys,PAIR_KEYS).float()
    features[:,:,2*PAIR_KEYS]=values
    features+=torch.randn_like(features)*.025
    query=torch.zeros(batch,PAIR_DIM)
    query[:,:PAIR_KEYS]=F.one_hot(keys[torch.arange(batch),source],PAIR_KEYS).float()
    query[:,PAIR_KEYS:2*PAIR_KEYS]=F.one_hot(keys[torch.arange(batch),target],PAIR_KEYS).float()
    y=values[torch.arange(batch),source]-values[torch.arange(batch),target]
    return features,query,y,source,target


def pair_output(core:DeltaCore,features:Tensor,query:Tensor,mode:str='external'):
    if mode=='external':
        src,tgt,rate=core.address_batch(features,query)
    elif mode=='internal_observer':
        src,tgt,rate=core.address_batch(features,torch.zeros_like(query),observers=query)
    else:
        raise ValueError(mode)
    values=features[:,:,2*PAIR_KEYS]
    pred=(src*values).sum(-1)-(tgt*values).sum(-1)
    return pred,src,tgt,rate


@torch.no_grad()
def evaluate_pair(core:DeltaCore,n:int=5,batch:int=2048,control:str='normal',mode:str='external'):
    x,q,y,source,target=make_pair_batch(batch,n)
    if control=='no_query':q*=0
    elif control=='shuffled_state':x=x[torch.randperm(batch)]
    elif control!='normal':raise ValueError(control)
    pred,sp,tp,rate=pair_output(core,x,q,mode=mode)
    return {
      'mse':float(F.mse_loss(pred,y)),
      'source_accuracy':float((sp.argmax(-1)==source).float().mean()),
      'target_accuracy':float((tp.argmax(-1)==target).float().mean()),
      'mean_rate':float(rate.mean())}


def train_pair(seed:int,steps:int=700,batch:int=128,checkpoint_every:int=100,
               mode:str='external'):
    torch.manual_seed(seed)
    core=DeltaCore(d=PAIR_DIM,b=6,l=6,r=8,hidden=48)
    opt=torch.optim.Adam(core.parameters(),lr=.004)
    curve=[]
    initial=evaluate_pair(core,n=5,batch=1024,mode=mode)
    for step in range(1,steps+1):
        x,q,y,_,_=make_pair_batch(batch,5)
        pred,_,_,_=pair_output(core,x,q,mode=mode)
        loss=F.mse_loss(pred,y)
        opt.zero_grad();loss.backward();opt.step()
        if step%checkpoint_every==0:
            curve.append({'step':step,'train_loss':float(loss.detach()),
                          'validation':evaluate_pair(core,5,512,mode=mode)})
    evals={
      'N5':evaluate_pair(core,5,2048,mode=mode),
      'N7':evaluate_pair(core,7,2048,mode=mode),
      'no_query':evaluate_pair(core,5,2048,'no_query',mode=mode),
      'shuffled_state':evaluate_pair(core,5,2048,'shuffled_state',mode=mode)}
    return core,{'seed':seed,'mode':mode,'before':initial,'curve':curve,'after':evals}


class SymbolTask(nn.Module):
    """Optional application adapter: 5 input symbols -> 2 task labels."""
    def __init__(self):
        super().__init__()
        self.core=DeltaCore(d=16,b=6,l=6,r=8,hidden=48)
        self.symbol_embedding=nn.Embedding(5,16)
        self.classifier=nn.Linear(16,2)

    def forward(self,seq:Tensor):
        b,total=seq.shape
        z=self.symbol_embedding.weight.new_zeros((b,16))
        state=self.core.introduce(self.core.blank(),z)
        vectors=self.symbol_embedding(seq)
        for t in range(total):
            state=self.core.evolve(state,.65,
                 local_cues={uid:vectors[uid,t] for uid in state.ids})
        return self.classifier(state.units)


def make_history_batch(batch:int=64,interference:int=3):
    labels=torch.randint(0,2,(batch,))
    sequence=torch.stack([labels]+[torch.randint(2,4,(batch,)) for _ in range(interference)]+
                          [torch.full((batch,),4,dtype=torch.long)],1)
    return sequence,labels


@torch.no_grad()
def evaluate_history(model:SymbolTask,interference:int=3,batch:int=512,control:str='normal'):
    seq,y=make_history_batch(batch,interference)
    if control=='no_history':seq=seq[:,-1:]
    elif control=='shuffle_first':seq[:,0]=seq[torch.randperm(batch),0]
    elif control!='normal':raise ValueError(control)
    pred=model(seq)
    return {'accuracy':float((pred.argmax(-1)==y).float().mean()),
            'loss':float(F.cross_entropy(pred,y))}


def train_history(seed:int,steps:int=300,batch:int=64,checkpoint_every:int=60):
    torch.manual_seed(seed)
    model=SymbolTask()
    opt=torch.optim.Adam(model.parameters(),lr=.005)
    initial=evaluate_history(model,3,512)
    curve=[]
    for step in range(1,steps+1):
        s,y=make_history_batch(batch,3)
        logits=model(s)
        loss=F.cross_entropy(logits,y)
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),3.0);opt.step()
        if step%checkpoint_every==0:
            curve.append({'step':step,'train_loss':float(loss.detach()),
                          'validation':evaluate_history(model,3,256)})
    evals={
      'training_length_3':evaluate_history(model,3,512),
      'extended_7':evaluate_history(model,7,512),
      'extended_14':evaluate_history(model,14,512),
      'extended_30':evaluate_history(model,30,512),
      'no_history':evaluate_history(model,3,512,'no_history'),
      'shuffle_first':evaluate_history(model,3,512,'shuffle_first')}
    return model,{'seed':seed,'before':initial,'curve':curve,'after':evals}
