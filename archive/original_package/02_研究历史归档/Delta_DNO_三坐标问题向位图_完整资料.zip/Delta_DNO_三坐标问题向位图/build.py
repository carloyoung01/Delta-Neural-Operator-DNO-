import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np, json, pathlib
from matplotlib import font_manager
from matplotlib.lines import Line2D
root=pathlib.Path('/mnt/data/Delta_DNO_三坐标问题向位图')
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc') if pathlib.Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').exists() else None
plt.rcParams['font.family']=['Noto Sans CJK SC','Noto Sans CJK JP','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False
# coordinates deliberately qualitative; evidence 0 idea, 2 initial, 5 synthetic, 7 replicated synthetic, 9 broad real; risk 10 severe
items=[
(1,'存在与当前状态','已部分解决',7.0,7.6,4.0,'独立、共存、连续/离散如何共存？','以当前承载体与共享生成映射表达，并回归测试。','有限数值状态有效；不等于普适存在公理。'),
(2,'历史即当前有效状态','已部分解决',8.0,8.5,4.5,'没有事件日志是否丢失历史？','v0及封版延迟一位任务：训练后保持干扰前信息。','长期复杂历史仍有信息容量与污染风险。'),
(3,'关系持续改变','已部分解决',8.0,7.8,5.0,'关系只是连接还是能改变后续关系？','关系承载、更新与后续作用测试。','自然关系的自主语义仍未证明。'),
(4,'边界与局部规律','已部分解决',8.0,7.4,5.8,'边界如何不是固定阈值？','现有boundary/law随状态作用变化；消融表明其影响输出。','不能说获得通用的规律有效域。'),
(5,'关系存在不等于接触','已验证于合成测试',7.5,8.0,3.0,'仅存在的关系为何不应强制影响单元？','v3分离存在、自主演化与实际接触；隔离和干预测试。','真实世界的接触选择仍依赖训练与接口。'),
(6,'非强制观察与自身演化','已部分解决',7.5,7.5,5.0,'无输入时可否变化，观察可否缺席？','evolve与observe分离；无需全局强制观测。','如何选择观察及高成本感知尚未验证。'),
(7,'关系组合生出新承载体','已部分解决',8.5,7.0,5.8,'关系/结构如何继续组合成可作用对象？','compose产生承载体，继续进入后续计算。','生成对象语义、数量增长和稳定性未保证。'),
(8,'全对候选与事件过度定义','工程已处理',6.5,7.5,4.4,'N²两两候选与命名事件是否限制开放性？','v4及封版不强制全对枚举与事件表。','最坏情形仍可能出现复杂增长。'),
(9,'增删后的身份索引','已发现工程风险',5.5,5.0,7.2,'单元增删后旧位置索引指向错误身份。','v4审计发现；封版采用当前结构寻址并保留对照检查。','动态删除/重排跨模块身份一致性仍须测试。'),
(10,'小规模历史训练','已验证于合成测试',6.8,8.8,5.0,'是否必须增加独立记忆锚点？','v0、封版一位延迟任务训练成功；不添加记忆档案。','不能推广为无限历史或长文档记忆。'),
(11,'合成语言任务失败','未解决',6.5,8.0,8.2,'自适应版本在保留组合问答明显落后Transformer。','保留2500更新下0%对100%的负面结果；停止冒称已胜LLM。','真实语言泛化/规模成本仍无证据。'),
(12,'规律有效区间','已部分解决',8.8,7.6,5.8,'关系和边界是否需要分别人工定义？','冻结生成器从干预样本拟合条件规律和边界；与MLP对照。','通用自发发现与稳健外推尚未证实。'),
(13,'升维是视角而非固定机制','实验已澄清',8.3,6.8,5.3,'是否必须引入新坐标才能看见规律？','显式第三坐标可行，但固定非线性网络也学会交互。','把表达视角误加为强制模块的风险。'),
(14,'素数与黎曼类比','实验已澄清',5.0,6.5,4.8,'把一维提升至多尺度怎样帮助推理？','频率对照：素数频率不普遍优于整数频率。','固定频率基底会限制其他规律。'),
(15,'未来可区分性','已部分解决',8.2,7.1,6.1,'当前看似等价的结构未来可能分化吗？','有限干预签名与未见组合条件训练、对照。','无限未来等价不可判定、观测集有限。'),
(16,'递归反馈探针','已验证于受控仿真',8.6,7.6,5.9,'规律发现能否影响下一轮发现？','独立递归探针与验证集反馈实验成功；未改核心。','外部试验规定候选、观测和复杂度。'),
(17,'避免概念模块堆叠','已作工程决策',9.4,7.7,3.4,'测试通过为何反复出现“还要补模块”？','回归原封版共享生成核心；研究探针不并入底层。','极简不代表自动具备未实测的能力。'),
(18,'最小充分压缩','未解决',9.0,3.0,9.1,'“最小变化”是否能保留未来所有有效差异？','现有compact只释放零支撑；报告明确不能称全局最优。','不可逆信息丢失和长程污染。'),
(19,'无限分支与未知','未解决',9.8,2.2,9.6,'开放可能性如何在有限机器中实现？','保留数学开放性；propose只是有限计算机会。','未知无法被完整枚举/验证。'),
(20,'观察者与视角耦合','未解决',9.1,3.9,8.0,'谁选择观察，未观察的状态怎样定义？','存在非强制观察接口，但不证明自主最优视角。','选择偏差与反事实不可识别。'),
(21,'能耗与规模复杂度','未解决',7.8,2.2,9.0,'是否真的比attention更省能耗？','有稀疏关系/局部计算动机，未做可比硬件能耗。','增长、密集交互和调度可能抵消优势。'),
(22,'图像/视频/声音迁移','接口已验证',7.0,4.6,7.8,'跨模态单元是否比文本更适合？','同一核心四类数值输入运行；视频/声音是研究预测。','无真实识别/生成质量和强基线比较。'),
(23,'共享生成器与参数规则','已部分解决',8.4,7.0,6.3,'生成规则是否随作用变化？','law/boundary等有效状态改变且被读取。','固定参数θ没有自行改写算子形式。'),
(24,'交错共同演化','未解决',9.2,3.4,8.4,'AB共同历史能否产生不可归因于单方的结构？','概念上可由关系与生成承载体表述；缺独立因果实验。','归因与干预不可辨识。'),
(25,'权限与正式发布','外部阻塞',2.0,3.0,6.7,'GitHub账户切换及授权使上传受阻。','已创建本地正式代码包；代码发布与授权独立。','仓库写权限和远端发布不能从测试推出。'),
(26,'测试解释与版本收束','已作工程决策',9.6,8.3,3.6,'测试全通过为何仍不断“补齐”？','把合成通过、泛化、工程级证明分开；封版停止概念性叠加。','若未来发现实际缺陷仍需修复并回归。'),
(27,'隐私与自我训练污染','未解决',7.6,2.0,8.5,'用户行为流、群体先验和自生成数据如何安全？','仅在抽象层辨明风险，无隐私保证或抗模型坍缩实验。','数据泄露、偏见循环、状态污染。'),
]
colors={'已部分解决':'#4f9cba','已验证于合成测试':'#32a878','工程已处理':'#32a878','已发现工程风险':'#e49b3f','未解决':'#e25e70','实验已澄清':'#b69aea','已验证于受控仿真':'#32a878','已作工程决策':'#32a878','接口已验证':'#b69aea','外部阻塞':'#e49b3f'}
records=[]
for a in items:
    i,name,status,x,y,z,problem,response,risk=a
    records.append(dict(id=f'P{i:02}',name=name,status=status,结构层次_X=x,证据程度_Y=y,开放风险_Z=z,问题=problem,已尝试或解决=response,尚存风险=risk))
(root/'全部问题_坐标_解决与风险.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
# plot
fig=plt.figure(figsize=(18,11),facecolor='#0d1423')
ax=fig.add_axes([.04,.14,.63,.79],projection='3d',facecolor='#0d1423')
for axis in (ax.xaxis,ax.yaxis,ax.zaxis):
    axis._axinfo['grid']['color']=(.55,.62,.75,.18)
    axis._axinfo['tick']['color']=(.85,.91,.95,1)
ax.xaxis.pane.fill=False;ax.yaxis.pane.fill=False;ax.zaxis.pane.fill=False
for s in set(r['status'] for r in records):
    arr=[r for r in records if r['status']==s]
    ax.scatter([r['结构层次_X'] for r in arr],[r['证据程度_Y'] for r in arr],[r['开放风险_Z'] for r in arr],s=65,c=colors[s],edgecolors='white',linewidths=.5,depthshade=False)
for r in records:
    ax.text(r['结构层次_X']+.12,r['证据程度_Y']+.12,r['开放风险_Z']+.15,r['id'][1:],fontsize=8.6,color='white',weight='bold')
ax.set(xlim=(0,10.5),ylim=(0,10.5),zlim=(0,10.5))
ax.set_xlabel('X · 结构层次（局部 → 全局）',labelpad=14,color='#e9eef8',fontsize=12)
ax.set_ylabel('Y · 证据程度（假设 → 实测）',labelpad=15,color='#e9eef8',fontsize=12)
ax.set_zlabel('Z · 开放风险（低 → 高）',labelpad=14,color='#e9eef8',fontsize=12)
ax.tick_params(colors='#c9d4e6',labelsize=9)
ax.view_init(elev=22,azim=-59)
fig.text(.065,.957,'Delta / DNO · 全部问题的三坐标向位图',fontsize=22,weight='bold',color='#f6f8fb')
fig.text(.065,.922,'每一个编号是一项研究问题：位置代表逻辑层次、证据程度及尚存风险；不代表实际物理维度。',fontsize=11,color='#b5c6dd')
# right hand index
rightx=.685
fig.text(rightx,.89,'编号索引',fontsize=15,weight='bold',color='white')
for j,r in enumerate(records):
    col=j//14;rr=j%14;x=rightx+col*.158;y=.85-rr*.051
    if x>.985: break
    fig.text(x,y,r['id'][1:]+ '  '+r['name'],fontsize=9.25,color=colors[r['status']],verticalalignment='top')
legend_items=[('绿色：已在有限条件中验证','#32a878'),('蓝色：已有部分实现/证据','#4f9cba'),('紫色：实验澄清/接口验证','#b69aea'),('橙色：工程风险或发布阻碍','#e49b3f'),('红色：仍未解决的开放问题','#e25e70')]
for j,(t,c) in enumerate(legend_items):
    fig.text(.076+j*.18,.055,t,fontsize=10,color=c)
fig.text(.065,.012,'坐标是定性研究编码（0–10），不是准确率、成熟度评分或商业化指标；已解决只限定于特定测试范围。',fontsize=10,color='#c1cee0')
fig.savefig(root/'Delta_DNO_三坐标向位图.png',dpi=190,facecolor=fig.get_facecolor(),bbox_inches='tight')
fig.savefig(root/'Delta_DNO_三坐标向位图.svg',facecolor=fig.get_facecolor(),bbox_inches='tight')
plt.close(fig)
# detailed report
lines=['# Delta / DNO：全部问题—解决方式—遗留风险的三坐标向位图','', '> 这是对已讨论问题和归档研究的逻辑整理，不是新版本，也没有修改 DNO 核心。', '', '## 坐标与状态','', '- **X 结构层次**：从具体接口、单元到关系、整体生成与开放性。', '- **Y 证据程度**：从初步设想、有限代码验证到多种子合成训练。现无大规模真实世界能力证明。','- **Z 开放风险**：该问题尚待解决的不确定性和可能影响程度，数值越大代表风险越高。','', '**注意**：三轴坐标由研究整理者定性赋值，仅帮助理解问题间关系，不是经验测量值。也不等于“维度提升”的数学定理。','', '## 问题全表','', '| 编号 | 问题 | 当前证据状态 | X | Y | Z |','|---|---|---|---:|---:|---:|']
for r in records:
    lines.append(f"| {r['id']} | {r['name']} | {r['status']} | {r['结构层次_X']} | {r['证据程度_Y']} | {r['开放风险_Z']} |")
lines.extend(['','## 每一问题的产生、处理和仍存风险',''])
for r in records:
    lines.extend([f"### {r['id']} {r['name']} — {r['status']}", f"- 原问题：{r['问题']}",f"- 已采取的处理或实验：{r['已尝试或解决']}",f"- 仍需注意：{r['尚存风险']}",''])
lines.extend(['## 从三坐标图中得到的总体理解','','1. **高 X、高 Y、低 Z 的位置**：接近现阶段可以保留的最小可执行核心，而不是数学终极定理。','2. **高 X、低 Y、高 Z 的位置**：开放性、无限可能、最小充分压缩、跨历史因果归因等，是理论边界；不能因模块名字存在就标为已解决。','3. **低 X、中 Y、高 Z 的位置**：代码发布、身份索引等工程问题，不应重新塑造成 Delta 的抽象公理。','4. **中 X、中 Y、中高 Z 的位置**：维度、素数、反事实探针、跨模态数值接口，是理解或研究工具，不应自动并入冻结核心。','', '## 三坐标不是要求修改 DNO 的内部维度','','这张图是从外部观察 Delta/DNO 研究问题的多视角投影。图中的“问题→尝试→结果→风险”是研究文档的逻辑，不是 Delta 运行时必须遵循的事件次序。','', '## 主要证据来源','','- Delta_DNO_FORMAL_RELEASE/docs/01_完整研究记录_问题尝试训练结论.md','- Delta_DNO_FORMAL_RELEASE/docs/02_数学理解与代码对应.md','- Delta_DNO_FORMAL_RELEASE/docs/03_图像视频声音_单元表示预测与检验.md','- 已归档 v0/v1/v2/v3/v4/v5、数学压缩封版与后续独立探针报告。','', '注：关于 GitHub 授权、发布与隐私的条目属于对话中出现过的相关问题，不是 DNO 生成模型固有数学缺陷。'])
(root/'全部问题_解决过程_风险说明.md').write_text('\n'.join(lines),encoding='utf-8')
print('created',len(records),'items', [p.name for p in root.iterdir()])
