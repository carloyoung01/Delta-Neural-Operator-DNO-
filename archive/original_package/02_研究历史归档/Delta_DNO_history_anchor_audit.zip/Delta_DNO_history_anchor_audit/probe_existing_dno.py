"""Audit existing DNO v2 for persistent but not currently participating structures.

NO change to DNO itself, NO training, NO manual dormant gate.

This probe distinguishes:
 - structural persistence through continuous current-state evolution
 - nonzero relation-dependent causal influence while the relation exists
 - cue-by-relation interaction (not the same as selective/local memory recall)
 - actual stochastic persistence of a previously created directed edge

Tests use external fixed interventions to IDENTIFY causal influence, never to
make a dormant structure. The structural operation used to seed one relation is
an existing DNO operation; it does not indicate autonomous formation.
"""
from __future__ import annotations
import json, sys, math, statistics
from pathlib import Path
from dataclasses import replace

import torch
HERE = Path(__file__).resolve().parent
CANDIDATES = (HERE / 'reference_v2', HERE.parent / 'Delta_DNO_composition_alignment_v2')
SOURCE_FOLDER = next((p for p in CANDIDATES if (p / 'dno_compositional.py').is_file()), None)
if SOURCE_FOLDER is None:
    raise FileNotFoundError('Need the unchanged dno_compositional.py in reference_v2 or sibling Delta_DNO_composition_alignment_v2')
sys.path.insert(0, str(SOURCE_FOLDER))
from dno_compositional import EvolvingDNO, ResourceBoundary, _Proposal


def norm(x):
    return float(torch.linalg.vector_norm(x).detach().cpu())


def delete_one_relation(s):
    """Counterfactual *experimental* deletion, not a feature of active model."""
    assert len(s.edges) == 1
    empty = slice(0,0)
    return replace(s, edges=(), edge_operators=(),
                   relations=s.relations[empty], relation_laws=s.relation_laws[empty],
                   relation_times=s.relation_times[empty],
                   relation_tempos=s.relation_tempos[empty])


def establish(seed):
    torch.manual_seed(seed)
    m = EvolvingDNO(17, d_model=8, d_boundary=4, d_law=4,
                    d_relation=4, d_operator=4, d_hidden=24,
                    resources=ResourceBoundary(max_units=4, max_relations=6,
                        max_operators=8, max_events_per_advance=35))
    m.eval()
    with torch.no_grad():
        s = m.initial_state()
        vectors = [torch.randn(m.d) for _ in range(3)]
        for v in vectors:
            s = m.introduce_component(s, v)
        s, _ = m._apply_event(s, _Proposal(kind=2, source=0, target=1),
                              torch.zeros(m.d), stochastic=False)
    assert s.edges == ((0,1),)
    return m, s


def edge_causal_effect(m, s, x, dt=0.08):
    # Identical present tensors in both branches, only the relation omitted.
    with torch.no_grad():
        a = m._flow(s,x,dt)
        b = m._flow(delete_one_relation(s),x,dt)
        return norm(a.units-b.units), norm(m._readout(a,x)-m._readout(b,x))


def cue_interaction(m,s,cue,dt=0.08):
    """Difference-in-differences: is cue response modified by the edge?"""
    z = torch.zeros(m.d)
    with torch.no_grad():
        a0 = m._flow(s,z,dt)
        a1 = m._flow(s,cue,dt)
        without = delete_one_relation(s)
        b0 = m._flow(without,z,dt)
        b1 = m._flow(without,cue,dt)
        dd_h = (a1.units-a0.units)-(b1.units-b0.units)
        dd_y = ((m._readout(a1,cue)-m._readout(a0,z))-
                (m._readout(b1,cue)-m._readout(b0,z)))
        return norm(dd_h), norm(dd_y)


def grad_check(m,s):
    # Positive local derivative of currently existing relation to next units.
    # This can show continuous participation, not perfect functional recovery.
    r = s.relations.detach().clone().requires_grad_(True)
    q = replace(s, relations=r)
    y = m._flow(q, torch.zeros(m.d), 0.08).units
    grad = torch.autograd.grad(y.square().sum(),r,allow_unused=True)[0]
    return None if grad is None else norm(grad)


def main():
    torch.set_num_threads(1)
    audit=[]; survival=[]
    for seed in range(16):
        m,s = establish(seed)
        initial_rel = s.relations.detach().clone()
        initial_law = s.relation_laws.detach().clone()
        cue = torch.sin(torch.arange(1,m.d+1,dtype=s.units.dtype)*(seed+1)*0.51)
        # The continuous part of the EXACT original model, isolated from its
        # event scheduler. Thus NO claims about total lifetime survival.
        sample=[]
        for t in range(31):
            if t in (0,10,30):
                z = torch.zeros(m.d)
                effect, effect_y = edge_causal_effect(m,s,z)
                cue_effect, cue_y = cue_interaction(m,s,cue)
                sample.append({'step':t,'edge_effect_units_l2':effect,
                    'edge_effect_output_l2':effect_y,
                    'cue_x_edge_units_l2':cue_effect,
                    'cue_x_edge_output_l2':cue_y,
                    'edge_gradient_l2':grad_check(m,s) if t==30 else None,
                    'relation_state_change_from_start':norm(s.relations-initial_rel),
                    'relation_law_change_from_start':norm(s.relation_laws-initial_law),
                    'edges':len(s.edges),'physical_time':s.physical_time})
            if t<30:
                with torch.no_grad():
                    s = m._flow(s,torch.zeros(m.d),0.08).detach()
        audit.append({'seed':seed,'samples':sample})

        # Additional genuine stochastic event steps: absence of a deletion is
        # contingent, not a constant or a separate memory-preservation flag.
        _,s2 = establish(seed)
        total_events=0
        survived_steps=0
        for t in range(8):
            torch.manual_seed(7000+100*seed+t)
            with torch.no_grad():
                r = m.advance(s2, external=None, duration=0.015,
                        stochastic=True, resources=m.resources)
            s2 = r.state.detach(); total_events+=r.events_executed
            # A pair of current indices is not historical identity if a unit
            # was deleted/reindexed: this is not evidence of same relation.
            survived_steps += int((0,1) in s2.edges)
        edge_effect_after_no_events = None
        if total_events == 0 and s2.edges == ((0, 1),):
            edge_effect_after_no_events, _ = edge_causal_effect(
                m, s2, torch.zeros(m.d))
        survival.append({'seed':seed,'events':total_events,
            'edge_effect_after_no_events':edge_effect_after_no_events,
            'edges_after':len(s2.edges),
            'original_pair_current_at_end':(0,1) in s2.edges,
            'pair_present_snapshots':survived_steps,'units_after':s2.units.size(0)})

    idle=[a['samples'][i] for a in audit for i in range(3)]
    def stats(key):
        v=sorted(float(a[key]) for a in idle)
        return {'min':v[0], 'median':statistics.median(v), 'max':v[-1],
                'near_machine_zero_count_at_1e-10':sum(abs(x)<1e-10 for x in v),
                'n':len(v)}
    out={'experimental_scope':{
        'source_file':'Delta_DNO_composition_alignment_v2/dno_compositional.py',
        'original_modified':False, 'seeds':16, 'continuous_evolution_intervals':30,
        'dt':0.08, 'manual_relation_seeding':True, 'model_trained':False,
        'dormancy_switch_added':False,
        'experimental_edge_ablation_only':True,
        'cue_is_global_broadcast_in_original_model':True,
        'numerical_1e-10_is_only_display_precision_not_a_dormancy_threshold':True},
        'summary':{
            'continuous_flow_structure_persisted_all':all(all(v['edges']==1 for v in a['samples']) for a in audit),
            'idle_edge_influence':stats('edge_effect_units_l2'),
            'idle_edge_output_influence':stats('edge_effect_output_l2'),
            'cue_by_edge_interaction':stats('cue_x_edge_units_l2'),
            'cue_by_edge_output_interaction':stats('cue_x_edge_output_l2'),
            'relation_state_30_step_change':{'min':min(a['samples'][-1]['relation_state_change_from_start'] for a in audit), 'median':statistics.median(a['samples'][-1]['relation_state_change_from_start'] for a in audit), 'max':max(a['samples'][-1]['relation_state_change_from_start'] for a in audit)},
            'relation_law_30_step_change':{'min':min(a['samples'][-1]['relation_law_change_from_start'] for a in audit), 'median':statistics.median(a['samples'][-1]['relation_law_change_from_start'] for a in audit), 'max':max(a['samples'][-1]['relation_law_change_from_start'] for a in audit)},
            'gradient_30_steps':{'min':min(a['samples'][-1]['edge_gradient_l2'] for a in audit), 'median':statistics.median(a['samples'][-1]['edge_gradient_l2'] for a in audit), 'max':max(a['samples'][-1]['edge_gradient_l2'] for a in audit)},
            'stochastic_current_pair_exists_after_8_short_steps_count':sum(r['original_pair_current_at_end'] for r in survival),
            'stochastic_no_structure_event_runs':sum(r['events']==0 for r in survival),
            'stochastic_total_events':sum(r['events'] for r in survival),
            'edge_effects_in_no_event_runs':[r['edge_effect_after_no_events']
                for r in survival if r['edge_effect_after_no_events'] is not None],
        },'continuous_trials':audit,'stochastic_trials':survival}
    target=Path(__file__).with_name('audit_results.json')
    target.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(out['summary'],indent=2,ensure_ascii=False))
    print('written:',target)

if __name__ == '__main__':main()
