# Delta / DNO 历史锚定与非参与性：代码审查和实际验证

这是严格针对当前 DNO v2 原始源码的独立实验文件夹。**不修改原始代码**，也不声称已经出现自然记忆锚点。

- `reference_v2/dno_compositional.py`：现有 v2 的字节相同副本；SHA256 `12ba419e28eef14f8813320c79359a04568d4212cd194406b6956e3f5a800df1`。
- `probe_existing_dno.py`：16 种随机初始权重、连续演化和事件驱动反事实检查，固定种子可重复执行。
- `audit_results.json`：运行的完整数值记录。
- `研究结论_结构存在与条件再作用.md`：数学解释、代码条件、结果、严格限制、下一阶段最小修正方向。

```bash
python -m pip install torch
python probe_existing_dno.py
```

测试程序直接通过原始代码内部函数建立关系并检验因果作用。干预用于实验对照，不是 DNO 的新增功能。训练不在本次范围内。
