"""Independent measurement-noise stress test; no oracle-coordinate access."""
import json
from pathlib import Path
import torch
from run_experiments import setup, observe, mse
from effective_recursion import infer_and_commit


def main():
    torch.set_num_threads(1)
    rows=[]
    for seed in (11,17,29):
        core,s,teacher,uid=setup(seed)
        test=observe(core,teacher,uid,21,seed+3000,times=(.21,.46,.69,1.02))
        base=mse(core,s,uid,test)
        for noise in (.0,.01,.05,.1):
            train=observe(core,teacher,uid,12,seed+1000,noise=noise)
            valid=observe(core,teacher,uid,9,seed+2000,times=(.37,.63,.94),noise=noise)
            res=infer_and_commit(core,s,uid,train,valid)
            heldout=mse(core,res.state,uid,test)
            rows.append({'seed':seed,'measurement_noise_std':noise,
                         'accepted':res.accepted,'rank':res.selected_rank,
                         'base_test_mse':base,'adapted_test_mse':heldout,
                         'heldout_improvement':(base-heldout)/base})
    path=Path('evidence/robustness.json'); path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps({'explanation':'train and validation labels noisy; test clean and held out','rows':rows},indent=2)+'\n')
    for x in rows: print(x)

if __name__=='__main__':main()
