"""Finite, falsifiable interpretation of Delta's recursive effective-structure idea.

The frozen DNO in dno.py is NEVER modified by this module.

This is an *external experimental adapter* for state-conditioned multiview
probing, held-out intervention validation, minimum-complexity local state
revision, and subsequent re-probing. It does not prove universal discovery,
solve causal identifiability, or enumerate infinitely many possibilities.

No fixed named relation categories, semantic boundaries, past-event archive,
mandatory action, or expanded carrier dimension are introduced.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Sequence
import math

import torch
from torch import Tensor
from dno import DNO, State


@dataclass(frozen=True)
class Observation:
    """One measured future value from an actual intervention (not a hypothesis).

    The outcome is the carrier's *observable value only*. Hidden effective law
    and boundary coordinates of an environment are never passed as labels.
    """
    cue: Tensor
    dt: float
    outcome: Tensor


@dataclass(frozen=True)
class FitResult:
    state: State
    accepted: bool
    selected_rank: int
    steps: int
    train_mse_before: float
    train_mse_after: float
    validation_mse_before: float
    validation_mse_after: float
    update_norm: float
    view_difference: float


def _index(s: State, uid: int) -> int:
    if uid not in s.ids:
        raise KeyError(f'carrier {uid} not in current state')
    return s.ids.index(uid)


def _checked(core: DNO, s: State, uid: int) -> int:
    i = _index(s, uid)
    s.validate()
    if core.d != s.value.shape[1]:
        raise ValueError('frozen model/state dimension mismatch')
    if float(s.support[i].detach()) <= 0:
        raise ValueError('target carrier must be currently supported')
    return i


def current_views(s: State, uid: int) -> Tensor:
    """A complete orthonormal numerical frame induced by CURRENT state.

    The singular directions of the current carrier/observer fields are merely
    experimental perspectives, not a learned semantic category taxonomy.
    Degenerate singular subspaces are not uniquely identifiable.
    Shape [D,D], rows represent probe directions.
    """
    i = _index(s, uid)
    context = torch.stack((s.value[i], s.law[i], s.boundary[i], s.observer))
    _, _, vh = torch.linalg.svd(context, full_matrices=True)
    # Canonical sign convention for deterministic comparison only.
    pivots = vh.abs().argmax(dim=1)
    signs = torch.sign(vh[torch.arange(vh.shape[0], device=vh.device), pivots])
    return vh * signs[:, None]


def measured_outcome(core: DNO, s: State, uid: int, cue: Tensor, dt: float) -> Tensor:
    """Existing DNO evolve, with no new model rule, event, or hidden input."""
    i = _checked(core, s, uid)
    if not math.isfinite(dt) or dt <= 0:
        raise ValueError('dt must be finite positive')
    if cue.shape != (core.d,) or not bool(torch.isfinite(cue).all()):
        raise ValueError('cue must be finite [D]')
    out = core.evolve(s, dt, local={uid: cue})
    if uid not in out.ids:
        raise RuntimeError('target disappeared during intervention')
    return out.value[out.ids.index(uid)]


def _full_outcome(core: DNO, s: State, uid: int, cue: Tensor, dt: float) -> Tensor:
    """Research audit of effective state, not necessarily observable in nature."""
    out = core.evolve(s, dt, local={uid: cue})
    if uid not in out.ids:
        raise RuntimeError('carrier disappeared during probe')
    i = out.ids.index(uid)
    return torch.cat((out.value[i], out.boundary[i], out.law[i]))


def response_geometry(core: DNO, s: State, uid: int, *, dt: float = .2,
                      probe: float = .08, validation_probe: float = .04,
                      complexity_weight: float = .01) -> dict:
    """Infer the low-dimensional response *subspace*, with held-out amplitude.

    J(eps)[:,j] := [future(+eps * view_j)-future(-eps * view_j)] / (2 eps)
    SVD yields continuous effect modes. Compare the discovered span to a
    different probe amplitude; choose rank 0..D by validation residual + a
    stated rank penalty. No predefined boundary identity or relation type.

    This is internal-model stability, NOT external truth validation.
    """
    _checked(core, s, uid)
    if dt <= 0 or probe <= 0 or validation_probe <= 0 or complexity_weight < 0:
        raise ValueError('positive times and probes, nonnegative complexity required')
    q = current_views(s, uid)
    def response(h: float) -> Tensor:
        columns = []
        for v in q:
            yp = _full_outcome(core, s, uid, v*h, dt)
            ym = _full_outcome(core, s, uid, -v*h, dt)
            columns.append((yp-ym)/(2*h))
        return torch.stack(columns, dim=1)
    with torch.no_grad():
        a, b = response(probe), response(validation_probe)
        u, singular, _ = torch.linalg.svd(a, full_matrices=False)
        energy = float(torch.linalg.vector_norm(b).square())
        norms = []
        scores = []
        for rank in range(core.d+1):
            approx = u[:, :rank] @ (u[:, :rank].T @ b)
            error = float(((b-approx)**2).sum()) / max(energy, 1e-20)
            norms.append(error)
            scores.append(error + complexity_weight*rank/core.d)
        chosen = min(range(core.d+1), key=lambda r: scores[r])
        return {
            'rank': chosen,
            'singular_values': [float(v) for v in singular],
            'validation_relative_residual_by_rank': norms,
            'validation_penalized_score_by_rank': scores,
            'current_view_frame': q.clone(),
            'response_matrix': a.clone(),
        }


def _validate_observations(core: DNO, obs: Sequence[Observation]) -> None:
    if not obs:
        raise ValueError('at least one real intervention observation required')
    for item in obs:
        if item.cue.shape != (core.d,) or item.outcome.shape != (core.d,):
            raise ValueError('observation shape must be [D]')
        if not math.isfinite(item.dt) or item.dt <= 0:
            raise ValueError('observation dt must be finite positive')
        if not bool(torch.isfinite(item.cue).all()) or not bool(torch.isfinite(item.outcome).all()):
            raise ValueError('nonfinite observation')


def _theta(s: State, idx: int) -> Tensor:
    return torch.cat((s.law[idx], s.boundary[idx]))


def _with_theta(s: State, idx: int, theta: Tensor) -> State:
    d = s.value.shape[1]
    # No historical log; only current law/boundary for this one supported ID.
    law = s.law.clone()
    boundary = s.boundary.clone()
    law[idx] = theta[:d]
    boundary[idx] = theta[d:]
    return replace(s, law=law, boundary=boundary)


def _predictions(core: DNO, s: State, uid: int,
                 observations: Sequence[Observation]) -> Tensor:
    return torch.cat([measured_outcome(core, s, uid, z.cue, z.dt) for z in observations])


def _targets(observations: Sequence[Observation]) -> Tensor:
    return torch.cat([z.outcome for z in observations])


def infer_and_commit(core: DNO, s: State, uid: int,
                     train: Sequence[Observation],
                     validation: Sequence[Observation], *,
                     max_iterations: int = 2, complexity_weight: float = .002,
                     ridge: float = .0001,
                     step_scales: tuple[float, ...] = (.5, 1., 1.5)) -> FitResult:
    """Evidence-controlled recursive local effective-structure revision.

    1. Probe mapping from currently proposed local law+boundary to futures.
    2. SVD finds candidate representational dimensions from the Jacobian;
       never add a numbered semantic category or force a rank > 0.
    3. Fit data-supported correction on TRAIN interventions.
    4. Select rank and step using distinct VALIDATION interventions. Commit
       only if penalized held-out score improves over the unchanged state.
    5. The next call begins from this new state, rebuilding all perspectives.

    This is a finite local linearized inverse step. Its hyperparameters are
    explicit statistical budget choices, NOT universal Delta laws.
    Validation reuse across many iterations can overfit; an independent test
    split remains necessary for honest performance claims.
    """
    idx = _checked(core, s, uid)
    _validate_observations(core, train)
    _validate_observations(core, validation)
    if max_iterations < 0 or complexity_weight < 0 or ridge <= 0:
        raise ValueError('invalid inference budget')
    if not step_scales or any(not math.isfinite(x) or x <= 0 for x in step_scales):
        raise ValueError('step_scales must be positive finite values')
    # Read-only, frozen DNO; parameter gradients are not stepped.
    initial_view = current_views(s, uid).detach()
    initial_theta = _theta(s, idx).detach().clone()
    ytr, yva = _targets(train), _targets(validation)
    with torch.no_grad():
        tr_before = float(((_predictions(core, s, uid, train)-ytr)**2).mean())
        va_before = float(((_predictions(core, s, uid, validation)-yva)**2).mean())
    current = s
    accepted_any = False
    last_rank = 0
    iterations = 0
    for _ in range(max_iterations):
        center = _theta(current, idx).detach().clone().requires_grad_(True)
        def predict_in(theta: Tensor) -> Tensor:
            return _predictions(core, _with_theta(current, idx, theta), uid, train)
        # Jacobian of observable future outcomes w.r.t. current structure, not
        # w.r.t. a list of predeclared meanings or events.
        with torch.enable_grad():
            pred = predict_in(center)
            jac = torch.autograd.functional.jacobian(predict_in, center, vectorize=False)
        residual = (ytr-pred).detach()
        jac = jac.detach()
        # The singular frame is inferred from actual response changes.
        _, sig, vh = torch.linalg.svd(jac, full_matrices=False)
        dim = center.numel()
        reg = ridge * max(float(sig.max())**2, 1e-10)
        best_score = va_before if not accepted_any else float(((_predictions(core, current, uid, validation)-yva)**2).mean())
        best_state = None
        best_rank = 0
        n = len(validation)
        # rank 0 is always allowed (no discovered effective difference).
        for r in range(1, min(dim, vh.shape[0])+1):
            subspace = vh[:r].T
            a = jac @ subspace
            # Ridge solution along learned right-singular directions.
            aa = a.T @ a + reg * torch.eye(r, dtype=a.dtype, device=a.device)
            ab = a.T @ residual
            delta = subspace @ torch.linalg.solve(aa, ab)
            for scale in step_scales:
                candidate = _with_theta(current, idx, center.detach() + scale*delta)
                with torch.no_grad():
                    loss = float(((_predictions(core, candidate, uid, validation)-yva)**2).mean())
                # Relative complexity cost is defined w.r.t. the ORIGINAL
                # validation loss. This is a budget, not a physical threshold.
                penalty = complexity_weight * va_before * r / dim
                score = loss + penalty
                if score < best_score:
                    best_score = score
                    best_state = candidate
                    best_rank = r
        if best_state is None:
            break
        current = best_state
        accepted_any = True
        last_rank = best_rank
        iterations += 1
    with torch.no_grad():
        tr_after = float(((_predictions(core, current, uid, train)-ytr)**2).mean())
        va_after = float(((_predictions(core, current, uid, validation)-yva)**2).mean())
        update_norm = float(torch.linalg.vector_norm(_theta(current, idx)-initial_theta))
        new_view = current_views(current, uid)
        # Comparison of projection operators invariant to singular-vector signs;
        # here compare the top principal view only, which can have degeneracies.
        proj_change = float(torch.linalg.matrix_norm(
            torch.outer(initial_view[0], initial_view[0])-
            torch.outer(new_view[0], new_view[0])))
    current.validate()
    return FitResult(current, accepted_any, last_rank, iterations,
                     tr_before, tr_after, va_before, va_after,
                     update_norm, proj_change)


def discover_again(core: DNO, result: FitResult, uid: int, *,
                   dt: float = .2) -> dict:
    """Explicitly prove re-entry of newly effective structure into next probe."""
    return response_geometry(core, result.state, uid, dt=dt)


class RecursiveDNO:
    """Convenience API. Holds only an UNMODIFIED reference to the frozen core.

    No independent history, global event scheduler, relation taxonomy, or
    background discovery loop is created. Discovery requires actual evidence.
    All ordinary DNO actions remain under explicit caller control.
    """
    def __init__(self, core: DNO):
        self.core = core

    def infer(self, state: State, uid: int,
              train: Sequence[Observation], validation: Sequence[Observation],
              **kwargs) -> FitResult:
        return infer_and_commit(self.core, state, uid, train, validation, **kwargs)

    def perspectives(self, state: State, uid: int) -> Tensor:
        return current_views(state, uid)

    def study(self, state: State, uid: int, **kwargs) -> dict:
        return response_geometry(self.core, state, uid, **kwargs)

    def evolve(self, state: State, dt: float, **kwargs) -> State:
        return self.core.evolve(state, dt, **kwargs)

    def propose(self, state: State, **kwargs):
        return self.core.propose(state, **kwargs)

    def compose(self, state: State, source_id: int, target_id: int, **kwargs) -> State:
        return self.core.compose(state, source_id, target_id, **kwargs)


def empirical_effects(core: DNO, contexts: Sequence[State], uid: int,
                      cue: Tensor, readout: Tensor, *, dt: float = .2) -> Tensor:
    """One chosen intervention contrast across contexts; not a relation label.

    `readout` is an explicit measurement direction, not an intrinsic physical
    definition. A zero crossing is only meaningful relative to that choice.
    """
    if cue.shape != (core.d,) or readout.shape != (core.d,):
        raise ValueError('cue/readout must both have shape [D]')
    if not contexts:
        raise ValueError('at least one current-state context required')
    return torch.stack([
        torch.dot(measured_outcome(core,s,uid,cue,dt) -
                  measured_outcome(core,s,uid,-cue,dt),readout)
        for s in contexts])


def effect_partition(conditions: Tensor, signed_effects: Tensor) -> dict:
    """Infer observed sign domains and zero crossings, without a given cutoff.

    Piecewise-linear interpolation is a finite *estimate*. It neither defines
    all real boundaries nor assumes a physical law remains valid beyond the
    tested context interval. Exactly-zero response is a mathematical null, not
    a fixed ad-hoc magnitude threshold.
    """
    if conditions.ndim != 1 or signed_effects.ndim != 1 or conditions.shape != signed_effects.shape:
        raise ValueError('conditions/effects must be same-shaped 1D tensors')
    if conditions.numel() < 2 or not bool(torch.isfinite(conditions).all()) or not bool(torch.isfinite(signed_effects).all()):
        raise ValueError('require >=2 finite observations')
    if not bool((conditions[1:]>conditions[:-1]).all()):
        raise ValueError('conditions must be strictly increasing')
    x = conditions.detach().tolist()
    y = signed_effects.detach().tolist()
    roots = []
    for k in range(len(x)-1):
        a,b = y[k],y[k+1]
        if a == 0:
            roots.append(x[k])
        if a*b < 0:
            roots.append(x[k] - a*(x[k+1]-x[k])/(b-a))
    if y[-1] == 0:
        roots.append(x[-1])
    roots = sorted(set(roots))
    cuts = [x[0]] + [z for z in roots if x[0]<z<x[-1]] + [x[-1]]
    intervals = []
    for left,right in zip(cuts[:-1],cuts[1:]):
        mid=(left+right)/2
        seg=next((k for k in range(len(x)-1) if x[k]<=mid<=x[k+1]),len(x)-2)
        yy=y[seg]+(y[seg+1]-y[seg])*(mid-x[seg])/(x[seg+1]-x[seg])
        intervals.append({'left':left,'right':right,
                          'sign':1 if yy>0 else -1 if yy<0 else 0})
    return {'estimated_zero_crossings':roots,'observed_sign_intervals':intervals,
            'meaning':'conditional contrast on sampled interval; not an absolute boundary'}
