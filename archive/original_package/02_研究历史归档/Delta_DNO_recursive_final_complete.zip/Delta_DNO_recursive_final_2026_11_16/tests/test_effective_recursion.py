"""Falsifiable tests: no forced updates, split validation, recursion, invariants."""
import hashlib
from dataclasses import replace
from pathlib import Path
import sys

import pytest
import torch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dno import DNO
from effective_recursion import (Observation, RecursiveDNO, current_views,
    measured_outcome, response_geometry, infer_and_commit, discover_again)
from run_experiments import setup, observe, mse

# Keep manifest check independent from test's own declaration.
EXPECTED_REAL='fea8d9ea81c94dbf926b984b3c158f301afc71782f989c73b3c9bd02fac767b1'

@pytest.fixture(scope='module', autouse=True)
def threads():
    torch.set_num_threads(1)


def data(seed=11):
    core,s,teacher,uid=setup(seed)
    train=observe(core,teacher,uid,12,seed+1000)
    valid=observe(core,teacher,uid,9,seed+2000,times=(.37,.63,.94))
    test=observe(core,teacher,uid,21,seed+3000,times=(.21,.46,.69,1.02))
    return core,s,teacher,uid,train,valid,test


def test_dno_original_hash():
    core_bytes=Path(__file__).resolve().parents[1].joinpath('dno.py').read_bytes()
    assert hashlib.sha256(core_bytes).hexdigest()==EXPECTED_REAL


def test_frame_is_complete_orthonormal_and_state_dependent():
    core,s,t,uid,*_=data()
    a=current_views(s,uid)
    b=current_views(t,uid)
    eye=torch.eye(core.d)
    assert a.shape==(core.d,core.d)
    assert torch.allclose(a @ a.T,eye,atol=1e-5)
    assert torch.linalg.matrix_norm(a-b)>1e-4


def test_internal_response_svd_and_validation_amplitude():
    core,s,t,uid,*_=data()
    g=response_geometry(core,s,uid,dt=.2,probe=.08,validation_probe=.04)
    assert 0<=g['rank']<=core.d
    assert len(g['singular_values'])==core.d
    assert len(g['validation_relative_residual_by_rank'])==core.d+1
    assert g['validation_relative_residual_by_rank'][-1]<1e-6


def test_zero_effect_has_no_forced_rank():
    core,s,t,uid,*_=data()
    # All response derivatives w.r.t cue vanish if final generator output=0.
    with torch.no_grad():
        core.generator[-1].weight.zero_()
        core.generator[-1].bias.zero_()
    geom=response_geometry(core,s,uid)
    assert geom['rank']==0
    assert geom['response_matrix'].abs().max()==0


@pytest.mark.parametrize('seed',[11,17,29])
def test_real_changed_law_improves_unseen_interventions(seed):
    core,s,teacher,uid,train,valid,test=data(seed)
    params={k:v.clone() for k,v in core.state_dict().items()}
    before=mse(core,s,uid,test)
    res=infer_and_commit(core,s,uid,train,valid)
    after=mse(core,res.state,uid,test)
    assert res.accepted
    assert 0<res.selected_rank<2*core.d
    assert res.validation_mse_after<res.validation_mse_before
    assert after<before*.1
    assert res.update_norm>0
    assert res.view_difference>0
    res.state.validate()
    assert all(torch.equal(v,core.state_dict()[k]) for k,v in params.items())


def test_no_change_means_no_spurious_commit():
    core,s,t,uid,*_=data()
    tr=observe(core,s,uid,12,101)
    va=observe(core,s,uid,9,202)
    res=infer_and_commit(core,s,uid,tr,va)
    assert not res.accepted
    assert res.state is s
    assert res.selected_rank==0
    assert res.update_norm==0


def test_contradictory_holdout_rejects_false_discovery():
    core,s,t,uid,*_=data()
    tr=observe(core,t,uid,12,303)
    va=observe(core,s,uid,9,404)
    res=infer_and_commit(core,s,uid,tr,va)
    assert not res.accepted
    assert res.state is s


def test_preserves_identity_links_and_unaffected_carriers():
    core,s,t,uid,tr,va,_=data()
    s=replace(s,links=((s.ids[0],s.ids[1]),))
    res=infer_and_commit(core,s,uid,tr,va)
    after=res.state
    assert res.accepted
    assert after.ids==s.ids and after.links==s.links and after.next_id==s.next_id
    assert torch.equal(after.law[1:],s.law[1:])
    assert torch.equal(after.boundary[1:],s.boundary[1:])
    assert torch.equal(after.value,s.value)
    assert set(vars(after))==set(vars(s))
    assert not hasattr(after,'history')


def test_law_reentry_changes_next_future_and_next_discovery():
    core,s,t,uid,tr,va,_=data()
    res=infer_and_commit(core,s,uid,tr,va)
    next_probe=discover_again(core,res,uid)
    prior=response_geometry(core,s,uid)
    assert not torch.allclose(prior['response_matrix'],next_probe['response_matrix'],atol=1e-7)
    with torch.no_grad():
        next_s=core.evolve(res.state,.3)
        original_s=core.evolve(s,.3)
    assert (next_s.value-original_s.value).norm()>0
    assert (core.propose(res.state).source-core.propose(s).source).norm()>0


def test_no_forced_observe_or_event_and_interface_is_externally_callable():
    core,s,t,uid,tr,va,_=data()
    wrapper=RecursiveDNO(core)
    q=wrapper.perspectives(s,uid)
    assert q.shape==(core.d,core.d)
    base=wrapper.evolve(s,.2)
    assert base.ids==s.ids
    res=wrapper.infer(s,uid,tr,va)
    assert res.accepted
    assert wrapper.study(res.state,uid)['rank']>=0


def test_missing_observations_and_zero_iterations_are_honest():
    core,s,t,uid,tr,va,_=data()
    with pytest.raises(ValueError):infer_and_commit(core,s,uid,[],va)
    with pytest.raises(ValueError):infer_and_commit(core,s,uid,tr,[])
    with pytest.raises(ValueError):infer_and_commit(core,s,uid,tr,va,complexity_weight=-1)
    res=infer_and_commit(core,s,uid,tr,va,max_iterations=0)
    assert res.state is s and not res.accepted


def test_invalid_probes_rejected():
    core,s,t,uid,tr,va,_=data()
    with pytest.raises(ValueError):response_geometry(core,s,uid,validation_probe=0)
    with pytest.raises(ValueError):measured_outcome(core,s,uid,torch.zeros(core.d),-1)
    with pytest.raises(KeyError):infer_and_commit(core,s,50000,tr,va)


def test_second_regime_revises_from_current_state_without_old_archive():
    core,s,t,uid,tr,va,test=data(11)
    first=infer_and_commit(core,s,uid,tr,va)
    assert first.accepted
    # A different effective environment starts from the NEW current state;
    # neither first-round observations nor their event history are supplied.
    second_law=first.state.law.clone()
    second_boundary=first.state.boundary.clone()
    second_law[0] += torch.tensor([-.8,.6,-.9])
    second_boundary[0] += torch.tensor([.7,-.5,.45])
    second_teacher=replace(first.state,law=second_law,boundary=second_boundary)
    tr2=observe(core,second_teacher,uid,12,7111)
    va2=observe(core,second_teacher,uid,9,7222, times=(.37,.63,.94))
    te2=observe(core,second_teacher,uid,21,7333,times=(.21,.46,.69,1.02))
    before=mse(core,first.state,uid,te2)
    second=infer_and_commit(core,first.state,uid,tr2,va2)
    after=mse(core,second.state,uid,te2)
    assert second.accepted
    assert after<before*.15
    assert second.state.ids==first.state.ids
    assert set(vars(second.state))==set(vars(first.state))


def test_model_parameters_and_all_other_state_fields_stay_unchanged():
    core,s,t,uid,tr,va,_=data(17)
    before={k:v.detach().clone() for k,v in core.state_dict().items()}
    result=infer_and_commit(core,s,uid,tr,va)
    assert all(torch.equal(v,core.state_dict()[k]) for k,v in before.items())
    for field in ('value','support','age','observer'):
        assert torch.equal(getattr(s,field),getattr(result.state,field))
    assert result.state.next_id==s.next_id


def test_rejects_missing_support_and_nonfinite_measurements():
    core,s,t,uid,tr,va,_=data()
    with pytest.raises(ValueError):
        infer_and_commit(core,replace(s,support=torch.zeros_like(s.support)),uid,tr,va)
    corrupted=list(va)
    corrupted[0]=Observation(corrupted[0].cue,corrupted[0].dt,
                             torch.full_like(corrupted[0].outcome,float('nan')))
    with pytest.raises(ValueError):infer_and_commit(core,s,uid,tr,corrupted)


def test_boundary_is_inferred_from_effect_not_given_as_fixed_threshold():
    from effective_recursion import effect_partition
    z=torch.linspace(-1.,1.,21)
    # Environment oracle formula appears ONLY in the test. Its zero crossing
    # was not passed to the generic partition function.
    x=.35
    effect=.4*(x+z)
    got=effect_partition(z,effect)
    assert len(got['estimated_zero_crossings'])==1
    assert abs(got['estimated_zero_crossings'][0]+x)<1e-6
    assert [a['sign'] for a in got['observed_sign_intervals']]==[-1,1]


def test_conditional_response_field_is_continuous_in_context():
    from effective_recursion import empirical_effects, current_views
    core,s,t,uid,*_=data()
    ctx=[]
    for x in torch.linspace(-.3,.3,9):
        v=s.value.clone(); v[0,0]+=x
        ctx.append(replace(s,value=v))
    direction=current_views(s,uid)[0]
    eff=empirical_effects(core,ctx,uid,direction,direction)
    assert eff.shape==(9,)
    assert torch.isfinite(eff).all()
    assert (eff.max()-eff.min()).abs()>1e-6


def test_discovered_local_structure_changes_following_composition():
    core,s,t,uid,tr,va,_=data(11)
    res=infer_and_commit(core,s,uid,tr,va)
    assert res.accepted
    other=s.ids[1]
    with torch.no_grad():
        original=core.compose(s,uid,other,cue=torch.ones(core.d)*.25)
        revised=core.compose(res.state,uid,other,cue=torch.ones(core.d)*.25)
    # A possible child is governed by the ORIGINAL composition mechanism.
    # The test only checks the existing carriers, not a hardcoded child event.
    assert uid in original.ids and uid in revised.ids
    assert not torch.allclose(original.value[original.ids.index(uid)],
                              revised.value[revised.ids.index(uid)],atol=1e-7)
