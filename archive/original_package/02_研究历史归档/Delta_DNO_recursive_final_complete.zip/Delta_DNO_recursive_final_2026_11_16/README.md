# Delta DNO · Recursive Effective Structure (2026-11-16)

**状态：完整可执行研究版，非已证明的普适 Delta。原封版 DNO 未修改。**

## 项目内容

- `dno.py`：原冻结 DNO 的逐字节原件；原始 SHA-256 = `fea8d9ea81c94dbf926b984b3c158f301afc71782f989c73b3c9bd02fac767b1`。
- `effective_recursion.py`：**外部**多视角反事实、低秩有效差异、独立证据检验和递归写回。`RecursiveDNO` 只包装原核心，不复制其机制。
- `run_experiments.py`：用同一份原生成器建立只有当前局部规律不同的模拟环境；训练/验证/测试分开；三个随机初始化；无变化和矛盾证据负对照。
- `run_robustness.py`：不同观测噪声下的研究测试。
- `tests/test_final.py`：原冻结版32项测试，未修改。
- `tests/test_effective_recursion.py`：新增20项测试，涵盖原件哈希、SVD几何、拒绝虚假更新、两阶段递归、状态及参数隔离、条件性有效域数值推导等。
- `MATHEMATICS_ZH.md`：原抽象公式到有限计算的严谨映射。
- `REPORT_ZH.md`：实际结果及未实现事项。
- `evidence/`：程序实际生成的结果 JSON、测试记录、噪声应力测试。
- `reference/`：冻结数学约定、冻结范围、完整原始冻结发布包以及之前的独立探针原件。

## 依赖与运行

Python 3.11+，PyTorch CPU 版和 pytest 即可。实测环境 Python 3.13 / PyTorch 2.10.0+cpu / pytest 9.0.2。

```bash
pip install -r requirements.txt
python -m pytest -q
python run_experiments.py
python run_robustness.py
```

## 与真实环境对接

核心 API 传入的是**实测未来值**，不是预先标注的关系/规律名称：

```python
from dno import DNO
from effective_recursion import RecursiveDNO, Observation

core = DNO(d=3)
engine = RecursiveDNO(core)
state = core.introduce(core.blank(), values)  # values: [N, 3] Tensor
# train、validation 是不同作用条件下的 Observation 序列。
# 每条包含 cue: [3]、dt: 正数、outcome: [3]，必须来自真实或模拟实际作用结果。
result = engine.infer(state, state.ids[0], train, validation)
state = result.state  # 拒绝修正时，仍为原 state
state = engine.evolve(state, dt=0.1)  # 原核心继续演化
```

**不会强制观察或写回**：没有证据时保持原核心行为；实际应用中应采集独立测试条件防止反复使用验证集导致过拟合。

## 不应声称

- 不是黎曼猜想的实现，不使用素数特有频率。
- 没有证明“DNO 优于传统网络”、能耗更低或能够产生所有未知关系。
- `effect_partition` 估计的是条件性效果符号分界，不是通用的实体身份判别器。
- 多视角/SVD/验证是一套可否证的有限研究工具，不是 Delta 永久固定的规律。
