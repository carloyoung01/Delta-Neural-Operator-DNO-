"""Reproducible controlled experiments with a separate, simulated teacher.

The teacher has the SAME frozen DNO parameters but a different current
law/boundary for one carrier. Learning code never sees teacher coordinates,
only actual post-intervention value observations. A real sensor/environment
could supply Observation instead. This synthetic test is NOT a proof of
universal law discovery nor a fair comparison of total sensing cost.
"""
from __future__ import annotations
from dataclasses import replace, asdict
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
import torch

from dno import DNO
from effective_recursion import (Observation, current_views, measured_outcome,
                                 infer_and_commit, response_geometry, discover_again)


def setup(seed: int, d: int = 3, n: int = 3):
    torch.manual_seed(seed)
    core = DNO(d=d, hidden=24)
    # Freezing weights prevents the inference adapter from silently training
    # or replacing the already frozen shared generator.
    for p in core.parameters():
        p.requires_grad_(False)
    g = torch.Generator().manual_seed(314 + seed)
    s = core.introduce(core.blank(), torch.randn(n, d, generator=g)*.32).detach()
    uid = s.ids[0]
    b, l = s.boundary.clone(), s.law.clone()
    # ONLY the test environment knows these hidden current-state shifts.
    # Diverse values provide a nontrivial inverse identification problem.
    l[0] += torch.tensor([1.15,-.75,.85][:d])
    b[0] += torch.tensor([-.55,.9,-.65][:d])
    teacher = replace(s, law=l, boundary=b)
    return core, s, teacher, uid


def observe(core, teacher, uid, n: int, seed: int,
            *, times=(.28, .51, .83), noise: float = 0.) -> list[Observation]:
    gen = torch.Generator().manual_seed(seed)
    # Intervention distribution is independent of the hidden teacher state.
    frame = torch.eye(core.d)
    obs = []
    for j in range(n):
        z = torch.randn(core.d, generator=gen)
        z = z / z.norm().clamp_min(1e-9)
        v = frame.T @ z
        amp = .25 + .95*float(torch.rand((),generator=gen))
        cue = v*amp
        dt = times[j%len(times)]
        with torch.no_grad():
            y = measured_outcome(core, teacher, uid, cue, dt).detach()
            if noise:
                y = y + noise*torch.randn(y.shape,generator=gen)
        obs.append(Observation(cue, dt, y))
    return obs


def mse(core,s,uid,obs):
    with torch.no_grad():
        p = torch.cat([measured_outcome(core,s,uid,item.cue,item.dt) for item in obs])
        y = torch.cat([item.outcome for item in obs])
        return float(((p-y)**2).mean())


def single(seed=11, *, complexity=.002, max_iterations=2):
    core,s,teacher,uid=setup(seed)
    train=observe(core,teacher,uid,12,seed+1000)
    validation=observe(core,teacher,uid,9,seed+2000, times=(.37,.63,.94))
    test=observe(core,teacher,uid,21,seed+3000, times=(.21,.46,.69,1.02))
    before=mse(core,s,uid,test)
    geo0=response_geometry(core,s,uid,dt=.32)
    t0=time.monotonic()
    result=infer_and_commit(core,s,uid,train,validation,
                            max_iterations=max_iterations,
                            complexity_weight=complexity)
    elapsed=time.monotonic()-t0
    after=mse(core,result.state,uid,test)
    geo1=discover_again(core,result,uid,dt=.32)
    with torch.no_grad():
        p0=core.propose(s)
        p1=core.propose(result.state)
        address_shift=float(torch.linalg.vector_norm(p1.source-p0.source) +
                            torch.linalg.vector_norm(p1.target-p0.target))
    return {
        'seed':seed,'accepted':result.accepted,'rank':result.selected_rank,
        'iterations':result.steps,'train_before':result.train_mse_before,
        'train_after':result.train_mse_after,
        'validation_before':result.validation_mse_before,
        'validation_after':result.validation_mse_after,
        'test_before':before,'test_after':after,
        'test_relative_reduction':(before-after)/max(before,1e-30),
        'state_update_norm':result.update_norm,
        'view_projector_shift':result.view_difference,
        'address_shift':address_shift,
        'geometry_rank_before':geo0['rank'],
        'geometry_rank_after':geo1['rank'],
        'geometry_singular_before':geo0['singular_values'],
        'geometry_singular_after':geo1['singular_values'],
        'elapsed_s':elapsed,
    }


def negative_controls(seed=11):
    core,s,teacher,uid=setup(seed)
    z_train=observe(core,s,uid,12,seed+101)
    z_val=observe(core,s,uid,9,seed+202)
    clean=infer_and_commit(core,s,uid,z_train,z_val)
    # Train suggests different law, validation says the original state is true.
    wrong_train=observe(core,teacher,uid,12,seed+303)
    correct_val=observe(core,s,uid,9,seed+404)
    mismatch=infer_and_commit(core,s,uid,wrong_train,correct_val)
    return {
        'identical_world_rejected':not clean.accepted,
        'contradicted_world_rejected':not mismatch.accepted,
        'identical_world_update_norm':clean.update_norm,
        'contradicted_world_update_norm':mismatch.update_norm,
    }


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seeds',default='11,17,29')
    parser.add_argument('--output', default='evidence/results.json')
    args=parser.parse_args()
    torch.set_num_threads(1)
    seeds=[int(x) for x in args.seeds.split(',')]
    detail=[single(seed) for seed in seeds]
    controls=[{'seed':seed,**negative_controls(seed)} for seed in seeds]
    digest=hashlib.sha256(Path(__file__).with_name('dno.py').read_bytes()).hexdigest()
    result={
        'run':'external verified-recursion adapter vs no-update frozen DNO',
        'frozen_dno_sha256':digest,
        'torch_version':torch.__version__,
        'seeds':detail,'negative_controls':controls,
        'mean_test_mse_base':sum(x['test_before'] for x in detail)/len(detail),
        'mean_test_mse_adapter':sum(x['test_after'] for x in detail)/len(detail),
        'mean_test_relative_reduction':sum(x['test_relative_reduction'] for x in detail)/len(detail),
        'all_true_world_updates_accepted':all(x['accepted'] for x in detail),
        'all_null_controls_rejected':all(x['identical_world_rejected'] for x in controls),
        'all_contradiction_controls_rejected':all(x['contradicted_world_rejected'] for x in controls),
    }
    target=Path(args.output); target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
