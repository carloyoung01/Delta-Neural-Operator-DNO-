"""Optional application-layer exposure strategies; DNO core remains unchanged.

These strategies propose opportunities, not forced interactions or new edges.
All references are current live unit indices; no historical event archive.
"""
from dataclasses import dataclass
from typing import Mapping, Sequence
from dno_exposure import DeltaState
import torch


def directed_two_hop(state: DeltaState) -> set[tuple[int,int]]:
    """Potential contact exposed by A->B->C, without scanning all unit pairs."""
    outgoing: dict[int,set[int]] = {}
    for a,b in state.edges:
        outgoing.setdefault(a,set()).add(b)
    existing=set(state.edges)
    return {(a,c) for a,b in state.edges for c in outgoing.get(b,())
            if a!=c and (a,c) not in existing}


def shared_local_signal(state: DeltaState, cues: Mapping[int,torch.Tensor]) -> set[tuple[int,int]]:
    """Environment explicitly presents a common local field to multiple live IDs.

    Nonzero cue presence, not a learned similarity metric, is the exposure source.
    All ordered pairs among simultaneously addressed units are exposed.
    """
    ids={uid:i for i,uid in enumerate(state.unit_ids)}
    active=[ids[uid] for uid,x in cues.items() if uid in ids and bool(torch.any(x!=0))]
    return {(i,j) for i in active for j in active if i!=j}


@dataclass
class OptionalRestriction:
    """Example application-specific contraction; NOT a universal DNO rule."""
    allowed_unit_ids: frozenset[int]

    def __call__(self, state: DeltaState, pairs: set[tuple[int,int]]) -> set[tuple[int,int]]:
        return {(i,j) for i,j in pairs if state.unit_ids[i] in self.allowed_unit_ids
                and state.unit_ids[j] in self.allowed_unit_ids}


def discover(state: DeltaState, *, use_paths=True, cues=None, extra_pairs=(),
             restriction=None) -> tuple[tuple[int,int],...]:
    pairs=set(extra_pairs)
    if use_paths:
        pairs.update(directed_two_hop(state))
    if cues:
        pairs.update(shared_local_signal(state,cues))
    if restriction is not None:
        pairs=restriction(state,pairs)
    return tuple(sorted(pairs))


def advance_with_discovery(model, state, *, use_paths=True, local_cues=None,
                           extra_pairs=(), restriction=None, **kwargs):
    # One-step snapshot exposure. For topology changes *within* a long advance,
    # caller should use short steps or a dynamically invoked exposure provider.
    pairs=discover(state,use_paths=use_paths,cues=local_cues,
                   extra_pairs=extra_pairs,restriction=restriction)
    return model.advance(state,local_cues=local_cues,exposed_pairs=pairs,**kwargs)

from dno_exposure import EvolvingDNO

class LocallyDiscoveringDNO(EvolvingDNO):
    """Recomputes current opportunities at EVERY event scheduler iteration.

    This is an experimental opt-in subclass, not a change to the universal core.
    A domain-specific restriction may be attached or omitted.
    """
    def __init__(self,*args,restriction=None,use_paths=True,**kwargs):
        super().__init__(*args,**kwargs)
        self.discovery_restriction=restriction
        self.discovery_use_paths=use_paths
        self._current_cues=None
        self._extra_id_pairs=()

    def _proposals(self,state,rb,exposed_pairs=()):
        index={uid:i for i,uid in enumerate(state.unit_ids)}
        pairs=[]
        for a,b in self._extra_id_pairs:
            if a in index and b in index and a!=b:
                pairs.append((index[a],index[b]))
        pairs.extend(exposed_pairs)
        visible=discover(state,use_paths=self.discovery_use_paths,
                         cues=self._current_cues,extra_pairs=pairs,
                         restriction=self.discovery_restriction)
        return super()._proposals(state,rb,visible)

    def advance(self,state,*,local_cues=None,exposed_unit_id_pairs=(),**kwargs):
        # Restores previous configuration even when a scheduler error occurs.
        prev_cues,prev_pairs=self._current_cues,self._extra_id_pairs
        self._current_cues=local_cues
        self._extra_id_pairs=tuple(exposed_unit_id_pairs)
        try:
            return super().advance(state,local_cues=local_cues,**kwargs)
        finally:
            self._current_cues,self._extra_id_pairs=prev_cues,prev_pairs
