import json, time
from dataclasses import replace
import torch
from dno_exposure import EvolvingDNO, ResourceBoundary, _Proposal
from local_discovery import directed_two_hop, shared_local_signal, discover, OptionalRestriction, advance_with_discovery

torch.manual_seed(251)
m=EvolvingDNO(32,d_model=8,d_boundary=4,d_law=4,d_relation=4,d_operator=4,d_hidden=16)
rb=ResourceBoundary(max_units=20,max_relations=50,max_operators=12,max_events_per_advance=10)
x=torch.zeros(m.d)
def state(n):
 s=m.initial_state()
 for _ in range(n): s=m.introduce_component(s,torch.randn(m.d))
 return s
def link(s,i,j): return m._apply_event(s,_Proposal(2,source=i,target=j),x,False)[0]
def new_pairs(s,exposure):
 return {(q.source,q.target) for q in m._proposals(s,rb,exposure) if q.kind==2}

results={}
# H1: current relation composition exposes new pair, without full scan.
s=link(link(state(5),0,1),1,2)
p=directed_two_hop(s)
assert p=={(0,2)} and new_pairs(s,p)=={(0,2)}
assert (0,2) not in new_pairs(s,())
s_after=link(s,0,2)
assert (0,2) in s_after.edges
results['H1_path_composition']={'exposed':sorted(map(list,p)),'new_edge_executable':True,'no_all_pairs':True}
# H2: orientation and graph changes change exposure, without any historical log.
s_rev=link(link(state(5),1,0),1,2)
assert (0,2) not in directed_two_hop(s_rev)
s_lost=m._apply_event(s,_Proposal(3,edge=1),x,False)[0]
assert (0,2) not in directed_two_hop(s_lost)
results['H2_direction_and_current_state']={'reverse_path_exposes_0_2':False,'removed_path_exposes_0_2':False}
# H3: external shared signal exposes pair of previously unrelated components.
s0=state(5)
uid0,uid3=s0.unit_ids[0],s0.unit_ids[3]
cues={uid0:torch.ones(m.d),uid3:torch.ones(m.d)}
p3=shared_local_signal(s0,cues)
assert p3=={(0,3),(3,0)} and new_pairs(s0,p3)==p3
assert not shared_local_signal(s0,{uid0:torch.ones(m.d)})
results['H3_environment_cue']={'exposed':sorted(map(list,p3)),'no_cue_exposure':0}
# H4: optional restriction contracts candidates, leaves core and existing relations untouched.
restriction=OptionalRestriction(frozenset({uid0}))
assert not discover(s0,use_paths=False,cues=cues,restriction=restriction)
assert discover(s0,use_paths=False,cues=cues)==tuple(sorted(p3))
results['H4_optional_contraction']={'without_module':2,'with_module':0,'core_unmodified':True}
# H5: continuous internal evolution changes shared learned event intensities, without external input.
s=link(link(state(5),0,1),1,2)
proposal=_Proposal(2,source=0,target=2)
rate0=float(m._event_rates(s,x,[proposal])[0])
s1=m._flow(s,x,0.4)
rate1=float(m._event_rates(s1,x,[proposal])[0])
assert abs(rate1-rate0)>1e-8
assert directed_two_hop(s1)=={(0,2)}
results['H5_internal_evolution']={'rate_before':rate0,'rate_after':rate1,'rate_changed':abs(rate1-rate0),'path_still_exposed':True}
# H6: end-to-end scheduler accepts discovered pairs; not forcing event.
r=advance_with_discovery(m,s,use_paths=True,duration=0.03,stochastic=False,resources=rb)
assert r.state.counts[0]>0
results['H6_scheduler']={'executed':True,'events':r.events_executed,'truncated':r.truncated}
# Scaling: sparse chain vs all-pairs. Enumerated candidate work is O(E*degree), not globally O(N^2).
scale=[]
for n in [10,40,160]:
 z=state(n)
 # use dataclass replacement for graph-only path detection; no need to allocate edge feature arrays
 z=replace(z,edges=tuple((i,i+1) for i in range(n-1)))
 t=time.perf_counter(); q=directed_two_hop(z); elapsed=time.perf_counter()-t
 assert len(q)==n-2
 scale.append({'units':n,'existing_edges':n-1,'path_candidates':len(q),'all_directed_pairs':n*(n-1),'elapsed_ms':round(elapsed*1000,3)})
results['scaling']=scale
print(json.dumps(results,indent=2,ensure_ascii=False))
with open('/mnt/data/DNO_v5_multi_hypothesis_probe/results.json','w') as f:json.dump(results,f,indent=2,ensure_ascii=False)
# H7: scheduler recomputes discovery after topology changes, rather than caching stale indices.
from local_discovery import LocallyDiscoveringDNO
live=LocallyDiscoveringDNO(32,d_model=8,d_boundary=4,d_law=4,d_relation=4,d_operator=4,d_hidden=16)
state7=live.initial_state()
for _ in range(3): state7=live.introduce_component(state7,torch.randn(live.d))
zero=torch.zeros(live.d)
state7=live._apply_event(state7,_Proposal(2,source=0,target=1),zero,False)[0]
state7=live._apply_event(state7,_Proposal(2,source=1,target=2),zero,False)[0]
assert any(q.kind==2 and (q.source,q.target)==(0,2) for q in live._proposals(state7,rb))
state7=live._apply_event(state7,_Proposal(1,source=1),zero,False)[0]
assert not any(q.kind==2 and (q.source,q.target)==(0,2) for q in live._proposals(state7,rb))
results['H7_dynamic_refresh']={'after_removing_intermediate_unit':'stale candidate disappears','passed':True}
with open('/mnt/data/DNO_v5_multi_hypothesis_probe/results.json','w') as f:json.dump(results,f,indent=2,ensure_ascii=False)
