import json, torch
from dno_exposure import EvolvingDNO, ResourceBoundary

torch.manual_seed(71)
m=EvolvingDNO(32,d_model=8,d_boundary=4,d_law=4,d_relation=4,d_operator=4,d_hidden=16)
s=m.initial_state()
for _ in range(6): s=m.introduce_component(s,torch.randn(m.d))
rb=ResourceBoundary(max_units=6,max_relations=10,max_operators=8,max_events_per_advance=12)
base=m._proposals(s,rb)
exposed=m._proposals(s,rb,[(0,1),(2,3)])
assert not any(q.kind in (2,6) for q in base)
assert {(q.source,q.target) for q in exposed if q.kind==2}=={(0,1),(2,3)}
assert all(q.kind!=2 or (q.source,q.target) in {(0,1),(2,3)} for q in exposed)
assert len(exposed)<6*5
# Add an existing relation using the original event executor; then remove exposure.
q=next(q for q in exposed if q.kind==2 and (q.source,q.target)==(0,1))
s2,_=m._apply_event(s,q,torch.zeros(m.d),False)
assert (0,1) in s2.edges
p2=m._proposals(s2,rb)
assert any(q.kind==7 and q.edge==s2.edges.index((0,1)) for q in p2)
assert not any(q.kind==2 for q in p2)
# A retained relation remains eligible for participation without new environmental exposure.
r=m.advance(s2,duration=0.02,stochastic=False,resources=rb)
assert r.state.counts[0]>=1
# Show exact difference in event proposal counts and no implicit all-pairs enumeration.
results={'units':6,'old_directed_pair_candidates':30,'new_unexposed_pair_candidates':0,'new_exposed_pair_candidates':2,'base_total_proposals':len(base),'exposed_total_proposals':len(exposed),'retained_relation_participation_candidate':True,'advance_executed':True,'event_count':r.events_executed,'truncated':r.truncated}
print(json.dumps(results,indent=2))
open('/mnt/data/DNO_v4_exposure_probe/results.json','w').write(json.dumps(results,indent=2))
