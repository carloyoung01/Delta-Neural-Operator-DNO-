# DNO v5 — optional local contact discovery hypotheses

Run from this folder with PyTorch and pytest installed:

```bash
python test_hypotheses.py
python test_stochastic.py
python -m pytest -q test_regression.py test_exposure.py
```

- `dno_exposure.py`: unchanged v4 core reference.
- `local_discovery.py`: optional graph-path, common-local-signal, and domain-contraction strategies; includes a dynamic scheduler adapter.
- `test_hypotheses.py`: H1-H7 controlled experiments.
- `test_stochastic.py`: 80 stochastic scheduler trajectories.
- `results.json`, `stochastic_results.json`: actual results.
- `REPORT_ZH.md`: full interpretation and limitations.

This is an experimental mechanism, not proof of autonomous learning or universal relation discovery.
