import json,torch
from dno_exposure import EvolvingDNO,ResourceBoundary,_Proposal
from local_discovery import discover,LocallyDiscoveringDNO
m=LocallyDiscoveringDNO(32,d_model=8,d_boundary=4,d_law=4,d_relation=4,d_operator=4,d_hidden=16)
torch.manual_seed(909)
s=m.initial_state(); x=torch.zeros(m.d)
for _ in range(3): s=m.introduce_component(s,torch.randn(m.d))
for i,j in [(0,1),(1,2)]:s=m._apply_event(s,_Proposal(2,source=i,target=j),x,False)[0]
rb=ResourceBoundary(max_units=3,max_relations=3,max_operators=4,max_events_per_advance=30)
assert discover(s)==((0,2),)
count=0; all_events=0
for seed in range(80):
 torch.manual_seed(seed)
 r=m.advance(s,duration=.45,stochastic=True,resources=rb)
 count+=(0,2) in r.state.edges
 all_events+=r.events_executed
assert count>0
out={'runs':80,'new_edge_survived_at_end':count,'total_events':all_events,'meaning':'event-driven stochastic, not learned discovery; final-edge count misses transient openings'}
print(json.dumps(out,indent=2))
open('/mnt/data/DNO_v5_multi_hypothesis_probe/stochastic_results.json','w').write(json.dumps(out,indent=2))
