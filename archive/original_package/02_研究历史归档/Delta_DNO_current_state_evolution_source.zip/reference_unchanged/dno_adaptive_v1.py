"""Adaptive Delta Neural Operator research candidate. Batch=1 reference implementation.

Unlike DNO v0 this does NOT assume a fixed number of units or K ports per unit.
It uses sparse variable-size directed edges, current effective state, and optional
new composition nodes from a finite primitive grammar. Hardware resource guards
are configurable, not mathematical constants. No claims of arbitrary primitives,
semantic understanding, or globally optimal contact discovery.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from typing import Optional
import math
import torch
from torch import nn, Tensor
import torch.nn.functional as F

# DAG nodes: ('x',), ('tanh',), ('neg',), ('square',), ('add',p,q),
# ('mul',p,q), ('chain',p,q). The first four are finite primitive rules.
BASE_PROGRAMS=(('x',), ('tanh',), ('neg',), ('square',))

@dataclass(frozen=True)
class AdaptiveState:
    h: Tensor              # [N,D], current unit state, variable N
    boundary: Tensor       # [N,C], effective local boundary
    activity: Tensor       # [N,1], activity
    edges: tuple[tuple[int,int], ...]   # currently active directed contacts
    relations: Tensor      # [E,R], effective contact state
    edge_ops: tuple[int, ...]   # indices to currently effective operator DAG
    programs: tuple[tuple, ...] # current operator DAG (not event log)
    tick: int = 0
    births: int = 0
    dissolved_edges: int = 0
    compositions: int = 0

    def detach(self):
        return replace(self, h=self.h.detach(), boundary=self.boundary.detach(),
                       activity=self.activity.detach(), relations=self.relations.detach())
    def clone(self):
        return replace(self, h=self.h.clone(), boundary=self.boundary.clone(),
                       activity=self.activity.clone(), relations=self.relations.clone())

class AdaptiveDNO(nn.Module):
    def __init__(self, vocab_size: int, d_model: int=24, d_constraint: int=8,
                 d_relation: int=8, *, grow_units: bool=True, evolve_contacts: bool=True,
                 compose_ops: bool=True, relation_to_relation: bool=True,
                 max_live_units: Optional[int]=16, max_live_edges: Optional[int]=64,
                 max_operator_nodes: Optional[int]=32, max_program_depth: int=7,
                 birth_threshold: float=.34, contact_threshold:float=.37,
                 compose_threshold:float=.36, contact_creations_per_step:int=2):
        super().__init__()
        if d_model<4 or d_constraint<1 or d_relation<1:
            raise ValueError('dimension too small')
        if min(birth_threshold,contact_threshold,compose_threshold)<0:
            raise ValueError('thresholds must be nonnegative')
        if contact_creations_per_step<0:
            raise ValueError('contact creation budget must be nonnegative')
        self.vocab_size=vocab_size
        self.d=d_model;self.c=d_constraint;self.r=d_relation
        self.grow_units=grow_units;self.evolve_contacts=evolve_contacts
        self.compose_ops=compose_ops;self.relation_to_relation=relation_to_relation
        self.max_live_units=max_live_units;self.max_live_edges=max_live_edges
        self.max_operator_nodes=max_operator_nodes;self.max_program_depth=max_program_depth
        self.birth_threshold=birth_threshold;self.contact_threshold=contact_threshold
        self.compose_threshold=compose_threshold
        self.contact_creations_per_step=contact_creations_per_step
        self.embedding=nn.Embedding(vocab_size,d_model)
        self.inj=nn.Linear(d_model,d_model)
        self.split=nn.Linear(2*d_model,d_model)
        self.birth_gate=nn.Linear(2*d_model+1,1)
        self.individual=nn.Sequential(nn.Linear(d_model+d_constraint,d_model),nn.Tanh(),nn.Linear(d_model,d_model))
        self.index=nn.Linear(d_model+d_constraint,1)
        feat=2*d_model+2*d_constraint+d_relation
        self.contact_gate=nn.Sequential(nn.Linear(feat,d_model),nn.Tanh(),nn.Linear(d_model,1))
        self.message=nn.Sequential(nn.Linear(feat,d_model),nn.Tanh(),nn.Linear(d_model,d_model))
        self.op_mix=nn.Linear(feat,4)
        self.operator_gate=nn.Linear(feat,1)
        self.operator_kind=nn.Linear(feat,3)
        self.relation_update=nn.Sequential(nn.Linear(feat+2*d_relation,d_model),nn.Tanh(),nn.Linear(d_model,d_relation))
        self.boundary_update=nn.Sequential(nn.Linear(d_model+d_constraint+d_model,d_model),nn.Tanh(),nn.Linear(d_model,d_constraint))
        self.unit_gate=nn.Linear(2*d_model+d_constraint,d_model)
        self.activity_update=nn.Linear(d_model+d_constraint+1,1)
        self.output_norm=nn.LayerNorm(2*d_model)
        self.readout=nn.Linear(2*d_model,vocab_size)
        self.register_buffer('_zero',torch.tensor(0.),persistent=False)

    def initial_state(self) -> AdaptiveState:
        device=self.embedding.weight.device;dtype=self.embedding.weight.dtype
        return AdaptiveState(torch.zeros(1,self.d,device=device,dtype=dtype),
           torch.zeros(1,self.c,device=device,dtype=dtype),
           torch.zeros(1,1,device=device,dtype=dtype),(),
           torch.zeros(0,self.r,device=device,dtype=dtype),(),BASE_PROGRAMS)

    @staticmethod
    def depth(p:tuple, bank:tuple[tuple,...])->int:
        if len(p)==1:return 1
        return 1+max(AdaptiveDNO.depth(bank[i],bank) for i in p[1:])

    @staticmethod
    def eval_programs(bank:tuple[tuple,...], x:Tensor)->Tensor:
        """[P,E,D]; all nodes evaluated on a shared batch of edge messages.
        DAG order is topological. Newly made operators change actual messages.
        """
        out=[]
        for node in bank:
            t=node[0]
            if t=='x':z=x
            elif t=='tanh':z=torch.tanh(x)
            elif t=='neg':z=-x
            elif t=='square':z=x*x
            elif t=='add':z=.5*(out[node[1]]+out[node[2]])
            elif t=='mul':z=out[node[1]]*out[node[2]]
            elif t=='chain':z=torch.tanh(out[node[1]]+out[node[2]])
            else:raise ValueError(f'invalid operator {node}')
            out.append(torch.clamp(z,-4,4))
        return torch.stack(out) # [P,E,D]

    def _candidates(self, h:Tensor,c:Tensor,edges:tuple,tick:int)->list[tuple[int,int]]:
        n=h.size(0)
        if n<2:return []
        idx=self.index(torch.cat([h,c],-1)).squeeze(-1)
        order=torch.argsort(idx,stable=True).tolist()
        pairs=set(edges)
        # sort neighbor gives non-similarity topological encounter opportunity;
        # reverse edge deliberately exists as a distinct directed relation.
        for k,i in enumerate(order):
            j=order[(k+1)%n]
            if i!=j:pairs.add((i,j))
        # time-rotating probe, no per-unit K cap.
        i=tick%n;j=(i+1+(tick//max(n,1))%(n-1))%n
        if i!=j:pairs.add((i,j))
        return sorted(pairs)

    def _readout(self,h:Tensor,a:Tensor,carrier:int)->Tensor:
        summary=(h*a).sum(0)/(a.sum()+1e-6)
        return self.readout(self.output_norm(torch.cat([h[carrier],summary],dim=-1)))

    def step(self,token:Optional[Tensor|int],state:AdaptiveState, *,diagnostics:bool=False):
        if token is not None:
            if not torch.is_tensor(token):token=torch.tensor(token,dtype=torch.long,device=state.h.device)
            if token.ndim!=0:raise ValueError('one scalar token per step; reference batch=1')
            emb=self.inj(self.embedding(token.long()))
        else:
            emb=None
        h,c,a=state.h,state.boundary,state.activity
        n=h.shape[0];birth=False;old_edges=state.edges
        # Current-state encounter selection, not rotating positional slot injection.
        if emb is not None:
            scores=F.cosine_similarity(h,emb.unsqueeze(0).expand_as(h),dim=-1,eps=1e-6)
            carrier=int(torch.argmax(scores.detach()))
            mismatch=(1-scores.max()).clamp(0,2)
            b_features=torch.cat([h[carrier],emb,mismatch.unsqueeze(0)],-1)
            prob=torch.sigmoid(self.birth_gate(b_features)).squeeze()
            birth_score=prob*(mismatch+.12)
            injection=F.one_hot(torch.tensor(carrier,device=h.device),n).to(h.dtype).unsqueeze(-1)
            h=h+injection*emb.unsqueeze(0)*(1-.15*prob)
            space=self.max_live_units is None or n<self.max_live_units
            if self.grow_units and space and bool((birth_score>self.birth_threshold).detach()):
                child=torch.tanh(self.split(torch.cat([h[carrier],emb],-1)))*prob
                h=torch.cat([h,child.unsqueeze(0)],0)
                c=torch.cat([c,c[carrier:carrier+1]*.4],0)
                a=torch.cat([a,torch.sigmoid(birth_score).reshape(1,1)*.1],0)
                carrier=n; n+=1;birth=True
        else:
            carrier=int(torch.argmax(a.detach().flatten()))
            birth_score=h.new_zeros(())
        intrinsic=self.individual(torch.cat([h,c],-1))
        candidates=self._candidates(h,c,old_edges,state.tick) if self.evolve_contacts else list(old_edges)
        e_map={pair:i for i,pair in enumerate(state.edges)}
        next_edges=list(old_edges)
        next_ops=list(state.edge_ops)
        # Structure proposals use present-state gate; discrete selection is an
        # explicit non-differentiable branch, not pretend differentiable NAS.
        if self.evolve_contacts and len(candidates)>0:
            proposals=[]
            for s,t in candidates:
                if (s,t) in e_map:continue
                zeros=h.new_zeros(self.r)
                feat=torch.cat([h[s],h[t],c[s],c[t],zeros])
                g=self.contact_gate(feat).sigmoid().squeeze()
                proposals.append((float(g.detach()),(s,t)))
            proposals.sort(key=lambda q:(-q[0],q[1]))
            for g,pair in proposals:
                if g<=self.contact_threshold:break
                if self.max_live_edges is not None and len(next_edges)>=self.max_live_edges:break
                if sum(1 for q in next_edges if q not in e_map)>=self.contact_creations_per_step:break
                next_edges.append(pair);next_ops.append(0)
        # Growth is possible without a fixed per-unit port budget; E varies.
        E=len(next_edges)
        if E:
            old_rel=torch.stack([state.relations[e_map[p]] if p in e_map else h.new_zeros(self.r)
                                 for p in next_edges],0)
            src=torch.tensor([x[0] for x in next_edges],device=h.device,dtype=torch.long)
            dst=torch.tensor([x[1] for x in next_edges],device=h.device,dtype=torch.long)
            feature=torch.cat([h[src],h[dst],c[src],c[dst],old_rel],-1)
            gate=self.contact_gate(feature).sigmoid()
            raw=torch.tanh(self.message(feature))*gate
            # Learned mixed primitive operator and CURRENT compositional DAG.
            primitive=torch.stack([raw,torch.tanh(raw),-raw,raw*raw],dim=1)
            w=F.softmax(self.op_mix(feature),dim=-1)
            mix=(primitive*w.unsqueeze(-1)).sum(1)
            bank=state.programs
            if self.compose_ops and len(next_ops):
                pvals=self.eval_programs(bank,raw)
                current=pvals[torch.tensor(next_ops,device=h.device),torch.arange(E,device=h.device)]
                mix=.7*mix+.3*current
            old_context=h.new_zeros(n,self.r)
            counts=h.new_zeros(n,1)
            old_context=old_context.index_add(0,src,old_rel)
            counts=counts.index_add(0,src,torch.ones(E,1,device=h.device))
            old_context=old_context/(counts+1)
            rfeatures=torch.cat([feature,old_context[src],old_context[dst]],-1)
            if not self.relation_to_relation:
                rfeatures=torch.cat([feature,torch.zeros_like(old_context[src]),torch.zeros_like(old_context[dst])],-1)
            r_new=torch.tanh(.965*old_rel+.075*self.relation_update(rfeatures))
            m=h.new_zeros(n,self.d).index_add(0,src,mix)
            dgr=h.new_zeros(n,1).index_add(0,src,torch.ones(E,1,device=h.device))
            m=m/(dgr+1)
            # Topology change depends on current contact and operator gate.
            new_bank=list(bank)
            if self.compose_ops and (self.max_operator_nodes is None or len(new_bank)<self.max_operator_nodes):
                op_strength=(self.operator_gate(feature).sigmoid()*gate).squeeze(-1)
                oi=int(torch.argmax(op_strength.detach()))
                if bool((op_strength[oi]>self.compose_threshold).detach()):
                    left=next_ops[oi]
                    choices=self.operator_kind(feature[oi])
                    kind=('add','mul','chain')[int(torch.argmax(choices.detach()))]
                    right=int(torch.argmax(self.op_mix(feature[oi]).detach()))
                    candidate=(kind,left,right)
                    # depth guard is only a runtime safeguard, not a Delta axiom.
                    if self.depth(candidate,tuple(new_bank))<=self.max_program_depth:
                        new_bank.append(candidate)
                        next_ops[oi]=len(new_bank)-1
            else:new_bank=list(bank)
            # Reuse only live nodes in the current computation. Unreferenced
            # nodes can be reclaimed, so programs are not a log of all mutations.
            bank=tuple(new_bank)
            dissolved=0
            if state.tick>0 and state.tick%31==0:
                weak=[i for i in range(E) if float(gate[i].detach())<.30 and
                      float(r_new[i].detach().abs().max())<.08]
                if weak:
                    keep=[i for i in range(E) if i not in weak]
                    dissolved=len(weak)
                    next_edges=[next_edges[i] for i in keep]
                    next_ops=[next_ops[i] for i in keep]
                    r_new=r_new[keep]
            if dissolved or len(bank)>4:
                needed=set(range(4))
                def visit(i):
                    if i in needed:return
                    needed.add(i)
                    for x in bank[i][1:]:visit(x)
                for i in next_ops:visit(i)
                indices=sorted(needed);remap={j:i for i,j in enumerate(indices)}
                bank=tuple((p[0],*(remap[i] for i in p[1:])) for j in indices for p in [bank[j]])
                next_ops=[remap[i] for i in next_ops]
        else:
            m=torch.zeros_like(h)
            r_new=h.new_zeros((0,self.r));bank=state.programs
            dissolved=0
        c_next=torch.tanh(.98*c+.07*self.boundary_update(torch.cat([h,c,m],-1)))
        update=torch.tanh(h+.12*intrinsic+.23*m)
        ug=torch.sigmoid(self.unit_gate(torch.cat([h,c,m],-1)))
        h_next=(1-.24*ug)*h+.24*ug*update
        a_next=.95*a+.05*torch.sigmoid(self.activity_update(torch.cat([h_next,c_next,a],-1)))
        new=AdaptiveState(h_next,c_next,a_next,tuple(next_edges),r_new,tuple(next_ops),bank,
                          state.tick+1,state.births+int(birth),state.dissolved_edges+dissolved,
                          state.compositions+max(0,len(new_bank)-len(state.programs)) if E else state.compositions)
        output=self._readout(h_next,a_next,carrier)
        if diagnostics:
            return output,new,{'n':n,'edges':len(next_edges),'operators':len(bank),
                 'birth':birth,'birth_score':float(birth_score.detach()),'dissolved':dissolved}
        return output,new

    def forward(self,tokens:Tensor,state:Optional[AdaptiveState]=None,return_state:bool=False):
        if tokens.ndim==2:
            if tokens.shape[0]!=1:raise ValueError('adaptive reference implementation supports batch=1')
            tokens=tokens[0]
        if tokens.ndim!=1:raise ValueError('tokens must be [T] or [1,T]')
        if state is None:state=self.initial_state()
        out=[]
        for token in tokens:
            y,state=self.step(token,state)
            out.append(y)
        z=torch.stack(out).unsqueeze(0)
        return (z,state) if return_state else z

    @torch.no_grad()
    def generate(self,tokens:Tensor,steps:int=12)->Tensor:
        if tokens.ndim==1:tokens=tokens.unsqueeze(0)
        logits,state=self.forward(tokens,return_state=True)
        output=tokens
        for _ in range(steps):
            nxt=logits[0,-1].argmax().view(1,1)
            output=torch.cat([output,nxt],1)
            logits,state=self.step(nxt.squeeze(),state)
            logits=logits.view(1,1,-1)
        return output

    def resources(self,state:AdaptiveState)->dict:
        counts=[0]*state.h.shape[0]
        for i,j in state.edges:counts[i]+=1
        return {'active_units':state.h.shape[0],'active_edges':len(state.edges),
          'max_outdegree':max(counts,default=0),'operator_nodes':len(state.programs),
          'unit_births':state.births,'edge_dissolutions':state.dissolved_edges,
          'operator_compositions_created':state.compositions}


def parameter_count(model:nn.Module)->int:
    return sum(p.numel() for p in model.parameters())
