from pathlib import Path
import difflib,hashlib,json,subprocess,sys
root=Path('/mnt/data');out=root/'DNO_full_version_audit'
paths={'v0':root/'DNO_research_v0/dno.py','v1':root/'DNO_adaptive_research_v1/dno_adaptive.py','evolution':root/'DNO_current_state_evolution/dno_evolving.py','v2':root/'Delta_DNO_composition_alignment_v2/dno_compositional.py','v3':root/'Delta_DNO_conditional_participation_v3/dno_conditional.py','v4':root/'DNO_v4_exposure_probe/dno_exposure.py','v5_core':root/'DNO_v5_multi_hypothesis_probe/dno_exposure.py','v5_optional':root/'DNO_v5_multi_hypothesis_probe/local_discovery.py'}
rows=[]
for name,p in paths.items():
 t=p.read_text();rows.append({'version':name,'file':str(p),'lines':len(t.splitlines()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
diffs=[]
for a,b in [('evolution','v2'),('v2','v3'),('v3','v4'),('v4','v5_core')]:
 x=paths[a].read_text().splitlines();y=paths[b].read_text().splitlines();ops=difflib.SequenceMatcher(None,x,y,autojunk=False).get_opcodes();diffs.append({'from':a,'to':b,'same_line_ratio':round(difflib.SequenceMatcher(None,x,y,autojunk=False).ratio(),4),'added_or_replaced_lines':sum(j2-j1 for tag,i1,i2,j1,j2 in ops if tag in ('insert','replace')),'removed_or_replaced_lines':sum(i2-i1 for tag,i1,i2,j1,j2 in ops if tag in ('delete','replace')),'exact_identical':x==y});(out/f'{a}_to_{b}.patch').write_text('\n'.join(difflib.unified_diff(x,y,fromfile=a,tofile=b,lineterm=''))+'\n')
res={'files':rows,'adjacent_core_diffs':diffs,'tests':{'v0':'8 passed','v1':'8 passed','v2':'4 passed','v3':'18 passed','v5_regression':'18 passed'},'v0_modern_api_absent':['advance','introduce_component','_proposals','_flow','_interact'],'note':'v0 modern test incompatibility is not a failed conceptual test; requires equivalent behavioral tests'}
(out/'audit.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps(diffs,indent=2))
