import sys,json,torch
sys.path.insert(0,'/mnt/data/DNO_research_v0')
from dno import DNO
torch.set_num_threads(1);torch.manual_seed(41)
m=DNO(16,slots=7,d_model=8,d_constraint=4,d_relation=4)
s=m.initial_state(1)
with torch.no_grad():
 _,s=m.step(torch.tensor([2]),s)
 _,s=m.step(torch.tensor([3]),s)
 z=s.clone();z.boundary[:,0,:]+=0.5
 _,a=m.step(torch.tensor([4]),s)
 _,b=m.step(torch.tensor([4]),z)
 z2=s.clone();z2.relations+=0.7
 _,c=m.step(torch.tensor([4]),z2)
 _,d=m.step(torch.tensor([4]),s)
 _,e=m.step(torch.tensor([5]),s)
 r={'boundary_to_next_units_l2':float((a.h-b.h).norm()),'relation_to_next_units_l2':float((c.h-d.h).norm()),'input_token_to_next_units_l2':float((d.h-e.h).norm()),'current_state_recursion':a.tick==s.tick+1,'fixed_slots':a.h.shape[1],'fixed_ports':a.relations.shape[2]}
print(json.dumps(r,indent=2));open('/mnt/data/DNO_full_version_audit/v0_probe_results.json','w').write(json.dumps(r,indent=2))
