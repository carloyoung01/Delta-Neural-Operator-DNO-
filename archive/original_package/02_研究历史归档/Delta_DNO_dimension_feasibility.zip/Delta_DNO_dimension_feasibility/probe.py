"""Independent feasibility probe; does not modify frozen DNO."""
import json, torch
from torch import nn
from pathlib import Path

torch.set_num_threads(1)
class Linear2(nn.Module):
    def __init__(self):
        super().__init__(); self.readout=nn.Linear(2,1)
    def forward(self,x):return self.readout(x)
class FixedNonlinear(nn.Module):
    def __init__(self):
        super().__init__();self.net=nn.Sequential(nn.Linear(2,12),nn.Tanh(),nn.Linear(12,1))
    def forward(self,x):return self.net(x)
class DynamicRepresentation(nn.Module):
    """Effective third coordinate is generated from current 2D state and fed back.
    Note: max physical width is fixed, not truly unbounded dimensional growth.
    """
    def __init__(self):
        super().__init__();self.discover=nn.Sequential(nn.Linear(2,12),nn.Tanh(),nn.Linear(12,1));self.readout=nn.Linear(3,1,bias=True);self.feedback=nn.Linear(3,2,bias=False)
    def lift(self,x):return torch.cat((x,self.discover(x)),dim=-1)
    def forward(self,x):return self.readout(self.lift(x))
    def next_state(self,x,step=.1):return x+step*self.feedback(self.lift(x))

def train(cls,seed):
    torch.manual_seed(seed);m=cls(); opt=torch.optim.Adam(m.parameters(),lr=.025)
    grid=torch.linspace(-1,1,15); a,b=torch.meshgrid(grid,grid,indexing='ij'); x=torch.stack((a.flatten(),b.flatten()),-1); y=(x[:,0]*x[:,1]).unsqueeze(-1)
    for _ in range(650):
        opt.zero_grad();loss=(m(x)-y).square().mean();loss.backward();opt.step()
    testgrid=torch.linspace(-.97,.97,19); a,b=torch.meshgrid(testgrid,testgrid,indexing='ij');xt=torch.stack((a.flatten(),b.flatten()),-1);yt=(xt[:,0]*xt[:,1]).unsqueeze(-1)
    with torch.no_grad(): err=(m(xt)-yt).square().mean().item()
    return m,err

def main():
    result={'experiment':'interaction x*y, 2D to learned effective third coordinate','seeds':{},'notes':[]}
    for seed in (3,17,29):
        baseline,eb=train(Linear2,seed);fixed,ef=train(FixedNonlinear,seed);dynamic,ed=train(DynamicRepresentation,seed)
        x=torch.tensor([[.4,.7],[-.4,.7]])
        with torch.no_grad():
            original=dynamic.next_state(x)
            saved=dynamic.discover.forward
            # causal ablation: set newly generated coordinate to zero only for next-state calculation
            z=dynamic.lift(x);z[:,-1]=0
            ablated=x+.1*dynamic.feedback(z)
            delta=(original-ablated).abs().max().item()
        result['seeds'][str(seed)]={'linear_mse':eb,'fixed_nonlinear_mse':ef,'lifted_mse':ed,'lifted_feedback_ablation_max_difference':delta}
    result['notes']=['All models train on identical x*y data; nonlinear control tests whether lift is necessary.','New coordinate is learned but the maximum width (3) and architecture are engineered.','Feedback path is causally connected, but the task trains output only, not the quality of feedback.','This is a feasibility test, not proof of autonomous dimensionality selection.']
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
