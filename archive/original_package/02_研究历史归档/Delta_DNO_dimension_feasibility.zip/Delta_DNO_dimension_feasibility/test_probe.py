import json
from pathlib import Path
import torch
from probe import DynamicRepresentation,Linear2,FixedNonlinear

def test_shapes():
    m=DynamicRepresentation();x=torch.randn(5,2)
    assert m.lift(x).shape==(5,3)
    assert m.next_state(x).shape==(5,2)
    assert m(x).shape==(5,1)

def test_gradients():
    m=DynamicRepresentation();x=torch.randn(5,2)
    m(x).square().mean().backward()
    assert all(p.grad is not None for p in m.discover.parameters())

def test_frozen_width():
    m=DynamicRepresentation()
    assert m.lift(torch.randn(4,2)).shape[1]==3

def test_results_exist():
    r=json.loads(Path(__file__).with_name('results.json').read_text())
    assert len(r['seeds'])==3
    assert all(v['lifted_feedback_ablation_max_difference']>0 for v in r['seeds'].values())
